import bpy 
from bpy.types import Menu
from . icons.icons import load_icons

class HardOpsCustomMenu(bpy.types.Menu):
    bl_label = "HardOps v0056"
    bl_idname = "HardOps_CustomMenu"
    
    def draw(self, context):

        layout = self.layout
        icons = load_icons()
        
        is_bevel = False
        is_bool = False
        is_bevel_3 = False
        is_solidify = False
        
        for mode in bpy.context.object.modifiers :
            if mode.type == 'BEVEL' :
                is_bevel = True
            if mode.type == "BEVEL":
                if mode.material == 3:
                    is_bevel_3 = True
            if mode.type == 'BOOLEAN' :
                is_bool = True
            if mode.type == 'SOLIDIFY':
                is_solidify = True
        
        if bpy.context.object.mode == "EDIT":
            #print("EDIT MODE!")
            
            MakeSharpE = icons.get("MakeSharpE")
            layout.operator("bevelandsharp1.objects", text = "Make SSharp", icon_value=MakeSharpE.icon_id)
            
            ClearSharps = icons.get("ClearSharps")
            layout.operator("clean1.objects", text = "Clean SSharps", icon_value=ClearSharps.icon_id)
            
            layout.separator()
            
            #AdjustBevel = icons.get("AdjustBevel")
            #layout.operator("bwidth.modal_operator", text = "(B)Width", icon_value=AdjustBevel.icon_id)
            
            layout.separator() 
            
            Diagonal = icons.get("Diagonal")
            layout.menu(eMeshtools.bl_idname, text = "MeshTools", icon_value=Diagonal.icon_id)
            
            layout.separator()
            
            Xslap = icons.get("Xslap")
            layout.operator("ehalfslap.object", text = "(X+) Symmetrize", icon_value=Xslap.icon_id)
            
            layout.separator()
            
            if context.object.data.show_edge_crease == False:
                layout.operator("object.showoverlays", text="Show Overlays", icon='RESTRICT_VIEW_ON')  
            else :
                layout.operator("object.hide_overlays", text="Hide Overlays", icon='RESTRICT_VIEW_OFF')
                
            layout.separator()
              
            Diagonal = icons.get("Diagonal")
            layout.menu("insert.objects", text="Insert", icon_value=Diagonal.icon_id)
            
            Gui = icons.get("Gui")
            layout.menu("vpmenu.submenu", text="Settings", icon_value=Gui.icon_id)
                                                                                              
                               
        else:
            #print("OBJECT/OTHER MODE!")
            
            #AR's Smart Sharpen Menu
            if is_bevel == True and is_bool == True and is_bevel_3 == True:
                Frame = icons.get("Frame")
                layout.operator("sstep.objects", text = "(S) Step", icon_value=Frame.icon_id)
            elif is_bevel == True and is_bool == True and is_bevel_3 == False:
                CSharpen = icons.get("CSharpen")
                layout.operator("csharpen.objects", text = "(C) Sharpen", icon_value=CSharpen.icon_id)
            elif is_bevel == True and is_bool == False and is_bevel_3 == False:
                Ssharpen = icons.get("Ssharpen")
                layout.operator("ssharpen.objects", text = "(S) Sharpen", icon_value=Ssharpen.icon_id)
            elif is_bevel == True and is_bool == False and is_bevel_3 == True:
                Frame = icons.get("Frame")
                layout.operator("sstep.objects", text = "(S) Step", icon_value=Frame.icon_id)
            elif is_bevel == True and is_bool == False and is_bevel_3 == True:
                Frame = icons.get("Frame")
                layout.operator("sstep.objects", text = "(S) Step", icon_value=Frame.icon_id)
            else:
                CSharpen = icons.get("CSharpen")
                layout.operator("csharpen.objects", text = "(C) Sharpen", icon_value=CSharpen.icon_id)
            
            #Adjust Bevel
            if is_bevel == True:
                AdjustBevel = icons.get("AdjustBevel")
                layout.operator("bwidth.modal_operator", text = "(B)Width", icon_value=AdjustBevel.icon_id)
                
            else:  
                Frame = icons.get("Frame")
                layout.operator("tthick.modal_operator", text = "(T)Thick", icon_value=Frame.icon_id)
            
            if is_bool == True:
                #reBool
                ReBool = icons.get("ReBool")
                layout.operator("reverse.boolean", text = "(Re)Bool", icon_value = ReBool.icon_id)
                
            layout.separator()
            
            #AR's Menu
            CSharpen = icons.get("CSharpen")
            layout.menu(arSub.bl_idname, text = "Operations", icon_value=CSharpen.icon_id)
            
            #Classic Sharp Menu
            #CSharpen = icons.get("CSharpen")
            #layout.menu(SharpSub.bl_idname, icon_value=CSharpen.icon_id)  
            
            layout.separator()
                        
            Diagonal = icons.get("Diagonal")
            layout.menu(Meshtools.bl_idname, text = "MeshTools", icon_value=Diagonal.icon_id)
            
            #layout.separator()
            
            Diagonal = icons.get("Diagonal")
            layout.menu("insert.objects", text="Insert", icon_value=Diagonal.icon_id)
            
            layout.separator()
            
            Gui = icons.get("Gui")
            layout.menu("vpmenu.submenu", text="Settings", icon_value=Gui.icon_id)



#############################
#SubMenus
#############################

class arSub(bpy.types.Menu):
    bl_label = 'AR Protomenu'
    bl_idname = 'protomenu.submenu'    

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        is_bevel = False
        is_bool = False
        is_bevel_3 = False
        is_solidify = False

        for mode in bpy.context.object.modifiers :
            if mode.type == 'BEVEL' :
                is_bevel = True
            if mode.type == "BEVEL":
                if mode.material == 3:
                    is_bevel_3 = True
            if mode.type == 'BOOLEAN' :
                is_bool = True
            if mode.type == 'SOLIDIFY':
                is_solidify = True
        """
        if is_bevel == True and is_bool == True and is_bevel_3 == True:
            Frame = icons.get("Frame")
            layout.operator("sstep.objects", text = "(S) Step", icon_value=Frame.icon_id)
        elif is_bevel == True and is_bool == True and is_bevel_3 == False:
            CSharpen = icons.get("CSharpen")
            layout.operator("csharpen.objects", text = "(C) Sharpen", icon_value=CSharpen.icon_id)
        elif is_bevel == True and is_bool == False and is_bevel_3 == False:
            Ssharpen = icons.get("Ssharpen")
            layout.operator("ssharpen.objects", text = "(S) Sharpen", icon_value=Ssharpen.icon_id)
        elif is_bevel == True and is_bool == False and is_bevel_3 == True:
            Frame = icons.get("Frame")
            layout.operator("sstep.objects", text = "(S) Step", icon_value=Frame.icon_id)
        elif is_bevel == True and is_bool == False and is_bevel_3 == True:
            Frame = icons.get("Frame")
            layout.operator("sstep.objects", text = "(S) Step", icon_value=Frame.icon_id)
        else:
            CSharpen = icons.get("CSharpen")
            layout.operator("csharpen.objects", text = "(C) Sharpen", icon_value=CSharpen.icon_id)"""
            
        Ssharpen = icons.get("Ssharpen")
        layout.operator("ssharpen.objects", text = "(S) Sharpen", icon_value=Ssharpen.icon_id)  

        CSharpen = icons.get("CSharpen")
        layout.operator("csharpen.objects", text = "(C) Sharpen", icon_value=CSharpen.icon_id)  
        
#        CSharpen = icons.get("CSharpen")
#        pie.operator("ssharpen.objects", text = "SubSharpen", icon_value=CSharpen.icon_id)
            
        """
        #Adjust Bevel
        if is_bevel == True:
            AdjustBevel = icons.get("AdjustBevel")
            layout.operator("bwidth.modal_operator", text = "(B)Width", icon_value=AdjustBevel.icon_id)
            
        else:  
            Frame = icons.get("Frame")
            layout.operator("tthick.modal_operator", text = "(T)Thick", icon_value=Frame.icon_id) 

        """
        layout.separator() 
        
        #cStep
        Frame = icons.get("Frame")
        layout.operator("cstep.objects", text = "(C) Step", icon_value=Frame.icon_id)
        
        layout.separator() 
        
        #muti-C and S? - needs to only show up when multiple objects are selected
        if len(context.selected_objects) > 1:
            #multi-C
            CSharpen = icons.get("CSharpen")
            layout.operator("multi.csharp", text = "(C)Multi", icon_value=CSharpen.icon_id)
            #multi-S
            Ssharpen = icons.get("Ssharpen")
            layout.operator("multi.ssharp", text = "(S)Multi", icon_value=Ssharpen.icon_id) 
            ClearSharps = icons.get("ClearSharps")
            layout.operator("multi.clear", text = "Multi Clear", icon_value=ClearSharps.icon_id)
            layout.separator()                  
            
        #clearSharps
        ClearSharps = icons.get("ClearSharps")
        layout.operator("clean.objects", text = "Clear S/C/Sharps", icon_value=ClearSharps.icon_id)
        
#Insert Object
class Insert_Objects(bpy.types.Menu):
    bl_idname = "insert.objects"
    bl_label = "Insert Objects"
 
    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        wm = context.window_manager
 
        layout.template_icon_view(wm, "Hard_Ops_previews")
 
        Diagonal = icons.get("Diagonal")
        layout.prop(context.window_manager, "choose_primitive", text="", expand=False, icon_value=Diagonal.icon_id) 
 
        if len(context.selected_objects) > 1:
            layout.operator("object.to_selection", text="Obj to selection", icon="MOD_MULTIRES")
            layout.operator("make.link", text = "Link Objects", icon='CONSTRAINT' )
            layout.operator("unlink.objects", text = "Unlink Objects", icon='UNLINKED' )



# Material
class MaterialListMenu(bpy.types.Menu): # menu appelé par le pie
    bl_idname = "object.material_list_menu"
    bl_label = "Material_list"

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        
        if len(bpy.data.materials): # "len" retourne le nombre d'occurence donc, si il y a des materiaux dans les datas:
            for mat in bpy.data.materials:  
                name = mat.name
                try:
                    icon_val = layout.icon(mat) # récupère l'icon du materiau
                except:
                    icon_val = 1
                    print ("WARNING [Mat Panel]: Could not get icon value for %s" % name)

                op = col.operator("object.apply_material", text=name, icon_value=icon_val) # opérateur qui apparait dans le menu pour chaque matériau présent dans les datas materials
                op.mat_to_assign = name # on "stock" le nom du matériau dans la variable "mat_to_assign" declarée dans la class opérateur "ApplyMaterial"
        else:
            layout.label("No data materials")        


class SharpSub(bpy.types.Menu):
    bl_label = 'C/S/T Sharp'
    bl_idname = 'sharpmenu.submenu1'

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        Ssharpen = icons.get("Ssharpen")
        layout.operator("ssharpen.objects", text = "(S) Sharpen", icon_value=Ssharpen.icon_id)
        
        CSharpen = icons.get("CSharpen")
        layout.operator("csharpen.objects", text = "(C) Sharpen", icon_value=CSharpen.icon_id)
        """
        #C sharpen normal
        is_bevel = False
        is_bool = False
        for mode in bpy.context.object.modifiers :
            if mode.type == 'BEVEL' :
                is_bevel = True
            if mode.type == 'BOOLEAN' :
                is_bool = True   
        
        #If I Have          
        if is_bevel == True and is_bool == False :
            CSharpen = icons.get("CSharpen")
            layout.operator("ssharpen.objects", text = "(C) Sharpen", icon_value=CSharpen.icon_id)
            
        elif is_bool and is_bevel == True :
            CSharpen = icons.get("CSharpen")
            layout.operator("csharpen.objects", text = "(C) Sharpen", icon_value=CSharpen.icon_id)   
        
        #If I don't have    
        else :
            CSharpen = icons.get("CSharpen")                
            layout.operator("csharpen.objects", text = "(C) Sharpen", icon_value=CSharpen.icon_id)
        
        #C sharpen smooth
        is_bevel = False
        is_bool = False
        for mode in bpy.context.object.modifiers :
            if mode.type == 'BEVEL' :
                is_bevel = True
            if mode.type == 'BOOLEAN' :
                is_bool = True   
        
        #If I Have          
        if is_bevel == True and is_bool == False :
            CSharpen = icons.get("CSharpen")
            layout.operator("ssharpen.objects", text = "(C) Sharpen Smooth", icon_value=CSharpen.icon_id)
            
        elif is_bool and is_bevel == True :
            CSharpen = icons.get("CSharpen")
            layout.operator("object.smoothsharp", text = "(C) Sharpen Smooth", icon_value=CSharpen.icon_id)   
        
        #If I don't have    
        else :
            CSharpen = icons.get("CSharpen")                
            layout.operator("object.smoothsharp", text = "(C) Sharpen Smooth", icon_value=CSharpen.icon_id)
        """
        
        Frame = icons.get("Frame")
        layout.operator("cstep.objects", text = "(C) Step", icon_value=Frame.icon_id)
        
        Tsharpen = icons.get("Tsharpen")
        layout.operator("solidify.objects", text = "(T) Sharpen", icon_value=Tsharpen.icon_id)
        
        ClearSharps = icons.get("ClearSharps")
        layout.operator("clean.objects", text = "Clear S/C/Sharps", icon_value=ClearSharps.icon_id)

class ButtonsVPSub(bpy.types.Menu):
    bl_label = 'GUI'
    bl_idname = 'vpmenu.submenu'

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        icons = load_icons()
        
        if context.object.draw_type == 'WIRE':
            layout.operator("object.solid_all", text="Solid Mode", icon='MESH_CUBE')
        else :
            layout.operator("showwire.objects", text = "Wire Mode", icon='OUTLINER_OB_LATTICE')
            
        layout.separator()
        
        m_check = context.window_manager.m_check
        
        layout.separator()
        
        NGui = icons.get("NGui")
        layout.operator("ui.reg", text = "Normal", icon_value=NGui.icon_id)
        
        RGui = icons.get("RGui")
        layout.operator("ui.red", text = "Matcap", icon_value=RGui.icon_id)
        
        QGui = icons.get("QGui")
        layout.operator("ui.clean", text = "Minimal", icon_value=QGui.icon_id)
        
        layout.separator()
        
        RenderSet1 = icons.get("RenderSet1")
        layout.operator("render.setup", text = "Render (1)", icon_value=RenderSet1.icon_id)
        
        SetFrame = icons.get("SetFrame")
        layout.operator("setframe.end", text =  "Frame Range", icon_value=SetFrame.icon_id)
        
        layout.separator()
        
        
        if bpy.context.object and bpy.context.object.type == 'MESH':
            
            if m_check.meshcheck_enabled:
                layout.operator("object.remove_materials", text="Hidde Ngons/Tris", icon='RESTRICT_VIEW_OFF')
            else:
                layout.operator("object.add_materials", text="Display Ngons/Tris", icon='COLOR') 
            
            layout.operator("data.facetype_select", text="Ngons Select").face_type = "5"
            layout.operator("data.facetype_select", text="Tris Select").face_type = "3"        

class ButtonsVPSub(bpy.types.Menu):
    bl_label = 'GUI'
    bl_idname = 'vpmenu.submenu1'

    def draw(self, context):
        layout = self.layout
        icons = load_icons()

        NGui = icons.get("NGui")
        layout.operator("ui.reg", text = "Normal", icon_value=NGui.icon_id)
        
        RGui = icons.get("RGui")
        layout.operator("ui.red", text = "Matcap", icon_value=RGui.icon_id)
        
        QGui = icons.get("QGui")
        layout.operator("ui.clean", text = "Minimal", icon_value=QGui.icon_id)
        
class ImpSettings(bpy.types.Menu):
    bl_label = 'Set'
    bl_idname = 'renplay.Submenu'

    def draw(self, context):
        layout = self.layout
        icons = load_icons()

        layout.separator()
        
        row = layout.split(align=True)
        if context.object.draw_type == 'WIRE':
            row.operator("object.solid_all", text="Solid Mode", icon='MESH_CUBE')
        else :
            row.operator("showwire.objects(realagain=True)", text = "Wire Mode", icon='OUTLINER_OB_LATTICE')
            
        layout.separator()
        
        RenderSet1 = icons.get("RenderSet1")
        layout.operator("render.setup", text = "Render (1)", icon_value=RenderSet1.icon_id)
        
        SetFrame = icons.get("SetFrame")
        layout.operator("setframe.end", text =  "Frame Range", icon_value=SetFrame.icon_id)
        
class Meshtools(bpy.types.Menu):
    bl_label = 'Mesh_Tools'
    bl_idname = 'view3d.mstool_submenu'

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        ATwist360 = icons.get("ATwist360")
        layout.operator("array.twist", text = "Twist 360", icon_value=ATwist360.icon_id)
        
        layout.separator()
        
        Xslap = icons.get("Xslap")
        layout.operator("halfslap.object", text = "(X) - Symmetrize", icon_value=Xslap.icon_id)
        
        Yslap = icons.get("Yslap")
        layout.operator("yhalfslap.object", text = "(Y) - Symmetrize", icon_value=Yslap.icon_id)
        
        Zslap = icons.get("Zslap")
        layout.operator("zhalfslap.object", text = "(Z) - Symmetrize", icon_value=Zslap.icon_id)
        
        layout.separator()
        
        PUnwrap = icons.get("PUnwrap")
        layout.operator("object.runwrap", text = "(P) Unwrap", icon_value=PUnwrap.icon_id)
        
        layout.separator()
        
        SCleanRecenter = icons.get("SCleanRecenter")
        layout.operator("clean.recenter", text = "(S) Clean Recenter", icon_value=SCleanRecenter.icon_id)
        
        Applyall = icons.get("Applyall")
        layout.operator("stomp2.object", text = "ApplyAll (-L)", icon_value=Applyall.icon_id)
        
        
class eMeshtools(bpy.types.Menu):
    bl_label = 'EMesh_Tools'
    bl_idname = 'view3d.emstool_submenu'

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        CircleSetup = icons.get("CircleSetup")
        layout.operator("circle.setup", text = "Circle", icon_value=CircleSetup.icon_id)
        
        NthCircle = icons.get("NthCircle")
        layout.operator("nth.circle", text = "Circle (Nth)", icon_value=NthCircle.icon_id)
        
        layout.separator()
        
        FaceGrate = icons.get("FaceGrate")
        layout.operator("fgrate.op", text = "Grate (Face)", icon_value=FaceGrate.icon_id)
        
        FaceKnurl = icons.get("FaceKnurl")
        layout.operator("fknurl.op", text = "Knurl (Face)", icon_value=FaceKnurl.icon_id)
        
        layout.separator()
        
        EdgeRingPanel = icons.get("EdgeRingPanel")
        layout.operator("quick.panel", text = "Grate (Face)", icon_value=EdgeRingPanel.icon_id)
        
        FacePanel = icons.get("FacePanel")
        layout.operator("entrench.selection", text = "Panel (Edge)/(Face)", icon_value=FacePanel.icon_id)
        
        layout.separator()
        
        PUnwrap = icons.get("PUnwrap")
        layout.operator("object.runwrap", text = "(P) Unwrap", icon_value=PUnwrap.icon_id)


#class INFO_MT_mesh_deesinserts_add(bpy.types.Menu):
#    bl_idname = "INFO_MT_mesh_D3I_add"
#    bl_label = "DeesInserts"

#    def draw(self, context):
#        layout = self.layout
#        
#        layout.operator("mesh.wing", text="Wing")
#        layout.operator("mesh.tee", text="Tee")
#        layout.operator("mesh.insertjam", text="InsertJam")
#        layout.operator("mesh.hex_nut", text="Hex_Nut")
#        layout.operator("mesh.flange_cap", text="Flange_Cap")
#        layout.operator("mesh.flange", text="Flange")
#        layout.operator("mesh.cap", text="Cap")
#        layout.operator("mesh.torx", text="Torx")
#        layout.operator("mesh.square", text="Square")
#        layout.operator("mesh.span_head", text="Span_Head")
#        layout.operator("mesh.phps_rnd_2", text="Phps_Rnd_2")
#        layout.operator("mesh.phps_rnd", text="Phps_Rnd")
#        layout.operator("mesh.phps_hex", text="Phps_Hex")
#        layout.operator("mesh.phps_flat", text="Phps_Flat")
#        layout.operator("mesh.phps_cntrsnk", text="Phps_CntrSnk")
#        layout.operator("mesh.knurl_head", text="Knurl_Head")
#        layout.operator("mesh.hex_socket", text="Hex_Socket")
#        layout.operator("mesh.hex_raised", text="Hex_Raised")
#        layout.operator("mesh.hex_flat", text="Hex_Flat")
#        layout.operator("mesh.hex", text="Hex")
#        layout.operator("mesh.flat_rnd", text="FLAT_RND")
#        layout.operator("mesh.button", text="Button")
