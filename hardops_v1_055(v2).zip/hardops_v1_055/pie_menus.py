# -*- coding: utf-8 -*-

import bpy 
from bpy.types import Menu
from . icons.icons import load_icons


class HardOpsCustomPieMenu(bpy.types.Menu):
    bl_label = "HardOps v0055"
    bl_idname = "HardOps_Pie_Menu"
    
    def draw(self, context):
        
        layout = self.layout
        pie = layout.menu_pie()
        
        icons = load_icons()
        WM = bpy.context.window_manager
        is_bevel = False
        is_bool = False
        is_bevel_3 = False
        is_solidify = False
         
        for mode in bpy.context.object.modifiers :
            if mode.type == 'BEVEL' :
                is_bevel = True
            if mode.type == "BEVEL":
                if mode.material == 3:
                    is_bevel_3 = True
            if mode.type == 'BOOLEAN' :
                is_bool = True
            if mode.type == 'SOLIDIFY':
                is_solidify = True
        
        if bpy.context.object.mode == "EDIT":
            #print("EDIT MODE!")
            #4 - LEFT
            ClearSharps = icons.get("ClearSharps")
            pie.operator("clean1.objects", text = "Clean SSharps", icon_value=ClearSharps.icon_id)
            #6 - RIGHT 
            MakeSharpE = icons.get("MakeSharpE")
            pie.operator("bevelandsharp1.objects", text = "Make SSharp", icon_value=MakeSharpE.icon_id)
            #2 - BOTTOM
            box = pie.split().column()
            row = box.split(align=True)
            row.template_icon_view(WM, "Hard_Ops_previews")
            row = box.split(align=True)
            row.prop(context.window_manager, "choose_primitive", text="")
            if len(context.selected_objects) > 1:
                row = box.split(align=True)
                row.operator("object.to_selection", text="Obj to selection", icon="MOD_MULTIRES")
                row = box.split(align=True)
                row.operator("make.link", text = "Link Objects", icon='CONSTRAINT' )
                row = box.split(align=True)
                row.operator("unlink.objects", text = "Unlink Objects", icon='UNLINKED' )
    
    
            
            #8 - TOP 
            box = pie.split().column()
            row = box.split(align=True)
            Xslap = icons.get("Xslap")
            row.menu("object.symetrize", icon_value=Xslap.icon_id)
            
            row = box.row(align=True)
            row = box.split(align=True)
            Xslap = icons.get("Xslap")
            row.operator("symetrize.xpositive", text="(X-)", icon_value=Xslap.icon_id)
            Xslap = icons.get("Xslap")
            row.operator("symetrize.xnegative", text = "(X+)", icon_value=Xslap.icon_id)
            
            #7 - TOP - LEFT 
            if context.object.data.show_edge_crease == False:
                pie.operator("object.showoverlays", text="Show Overlays", icon='RESTRICT_VIEW_ON')  
            else :
                pie.operator("object.hide_overlays", text="Hide Overlays", icon='RESTRICT_VIEW_OFF')
            #9 - TOP - RIGHT
            AdjustBevel = icons.get("AdjustBevel")
            pie.operator("bwidth.modal_operator", text = "(B)Width", icon_value=AdjustBevel.icon_id)
            #1 - BOTTOM - LEFT
            if context.object.draw_type == 'WIRE':
                pie.operator("object.solid_all", text="Solid Mode", icon='MESH_CUBE')
            else :
                pie.operator("showwire.objects", text = "Wire Mode", icon='OUTLINER_OB_LATTICE')
            #3 - BOTTOM - RIGHT   
            m_check = context.window_manager.m_check
            box = pie.split().column()
            row = box.row(align=True)
            Diagonal = icons.get("Diagonal")
            row.menu("emstool.submenu", text="Mesh Tools", icon_value=Diagonal.icon_id)
            row = box.split(align=True)
            if bpy.context.object and bpy.context.object.type == 'MESH':
                if m_check.meshcheck_enabled:
                    row.operator("object.remove_materials", text="Hidde color", icon='RESTRICT_VIEW_OFF')
                else:
                    row.operator("object.add_materials", text="Display color", icon='COLOR') 
                row = box.row(align=True)
                row.operator("data.facetype_select", text="Ngons").face_type = "5"
                row.operator("data.facetype_select", text="Tris").face_type = "3"
            
            row = box.row(align=True)
            row = box.split(align=True) 
            Gui = icons.get("Gui")
            row.menu("vpmenu.submenu", text="Set", icon_value=Gui.icon_id)
                              
        else:
            #print("OBJECT/OTHER MODE!")

            #4 - LEFT
            is_bevel = False
            is_bool = False
            for mode in bpy.context.object.modifiers :
                if mode.type == 'BEVEL' :
                    is_bevel = True
                if mode.type == 'BOOLEAN' :
                    is_bool = True   
            
            #If I Have          
            if is_bevel == True and is_bool == False :
                CSharpen = icons.get("CSharpen")
                pie.operator("ssharpen.objects", text = "SubSharpen", icon_value=CSharpen.icon_id)
                
            elif is_bool and is_bevel == True :
                CSharpen = icons.get("CSharpen")
                pie.operator("object.smoothsharp", text = "SubSharpen", icon_value=CSharpen.icon_id)   
            
            #If I don't have    
            else :
                CSharpen = icons.get("CSharpen")                
                pie.operator("object.smoothsharp", text = "SubSharpen", icon_value=CSharpen.icon_id)
            
            
            
            #6 - RIGHT
           
            is_bevel = False
            is_bool = False
            for mode in bpy.context.object.modifiers :
                if mode.type == 'BEVEL' :
                    is_bevel = True
                if mode.type == 'BOOLEAN' :
                    is_bool = True   
            
            #If I Have          
            if is_bevel == True and is_bool == False :
                CSharpen = icons.get("CSharpen")
                pie.operator("ssharpen.objects", text = "(C)Sharpen", icon_value=CSharpen.icon_id)
                
            elif is_bool and is_bevel == True :
                CSharpen = icons.get("CSharpen")
                pie.operator("csharpen.objects", text = "(C)Sharpen", icon_value=CSharpen.icon_id)   
            
            #If I don't have    
            else :
                CSharpen = icons.get("CSharpen")                
                pie.operator("csharpen.objects", text = "(C) Sharpen", icon_value=CSharpen.icon_id)

            #2 - BOTTOM

            box = pie.split().column()
            row = box.split(align=True)
            Tsharpen = icons.get("Tsharpen")
            row.operator("solidify.objects", text = "(T) Sharpen", icon_value=Tsharpen.icon_id)
            
            if len(context.selected_objects) == 2:
                row = box.row(align=True)
                row = box.split(align=True)
                
                CSharpen = icons.get("CSharpen")
                row.operator("multi.csharp", text = "(C)Multi", icon_value=CSharpen.icon_id)
            
            if is_bool == True:
                row = box.row(align=True)
                row = box.split(align=True)
                ReBool = icons.get("ReBool")
                row.operator("reverse.boolean", text = "(Re)Bool", icon_value = ReBool.icon_id) 
            
                row = box.row(align=True)
                row = box.split(align=True)
                Frame = icons.get("Frame")
                row.operator("cstep.objects", text = "(C) Step", icon_value=Frame.icon_id)
                
            if is_bevel == True and is_bool == True and is_bevel_3 == True:
                row = box.row(align=True)
                row = box.split(align=True)
                Frame = icons.get("Frame")
                row.operator("sstep.objects", text = "(S) Step", icon_value=Frame.icon_id)
            
            #8 - TOP
            pie.operator("screen.redo_last", text="F6", icon='SCRIPTWIN')
            #7 - TOP - LEFT 
            ClearSharps = icons.get("ClearSharps")
            pie.operator("clean.objects", text = "Clear S/C/Sharps", icon_value=ClearSharps.icon_id)
            #9 - TOP - RIGHT 
            if is_bevel == True:
                AdjustBevel = icons.get("AdjustBevel")
                pie.operator("bwidth.modal_operator", text = "(B)Width", icon_value=AdjustBevel.icon_id)
             
            else:  
                Frame = icons.get("Frame")
                pie.operator("tthick.modal_operator", text = "(T)Thick", icon_value=Frame.icon_id) 
            
#            AdjustBevel = icons.get("AdjustBevel")
#            pie.operator("bwidth.modal_operator", text = "(B)Width", icon_value=AdjustBevel.icon_id)
            #1 - BOTTOM - LEFT
            Ssharpen = icons.get("Ssharpen")
            pie.operator("ssharpen.objects", text = "(S) Sharpen", icon_value=Ssharpen.icon_id)
          #3 - BOTTOM - RIGHT  
            box = pie.split().column()
            row = box.split(align=True)
            Diagonal = icons.get("Diagonal")
            row.menu("mstool.submenu", text="Mesh Tools", icon_value=Diagonal.icon_id)
            
            row = box.row(align=True)
            row = box.split(align=True) 
            Gui = icons.get("Gui")
            row.menu("vpmenu.submenu", text="Set", icon_value=Gui.icon_id)
            
            row = box.row(align=True)
            row = box.split(align=True) 
            Diagonal = icons.get("Diagonal")
            row.menu("insert.objects", text ="Insert", icon_value=Diagonal.icon_id)
            
                        
############################
##SubMenus
############################

#Material list
class MaterialListMenu(bpy.types.Menu): # menu appelé par le pie
    bl_idname = "object.material_list_menu"
    bl_label = "Material_list"
 
    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
 
        if len(bpy.data.materials): # "len" retourne le nombre d'occurence donc, si il y a des materiaux dans les datas:
            for mat in bpy.data.materials:  
                name = mat.name
                try:
                    icon_val = layout.icon(mat) # récupère l'icon du materiau
                except:
                    icon_val = 1
                    print ("WARNING [Mat Panel]: Could not get icon value for %s" % name)
 
                op = col.operator("object.apply_material", text=name, icon_value=icon_val) # opérateur qui apparait dans le menu pour chaque matériau présent dans les datas materials
                op.mat_to_assign = name # on "stock" le nom du matériau dans la variable "mat_to_assign" declarée dans la class opérateur "ApplyMaterial"
        else:
            layout.label("No data materials")

#Insert Object
class Insert_Objects(bpy.types.Menu):
    bl_idname = "insert.objects"
    bl_label = "Insert Objects"
 
    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        wm = context.window_manager
 
        layout.template_icon_view(wm, "Hard_Ops_previews")
 
        Diagonal = icons.get("Diagonal")
        layout.prop(context.window_manager, "choose_primitive", text="", expand=False, icon_value=Diagonal.icon_id) 

        if len(context.selected_objects) > 1:
            layout.operator("object.to_selection", text="Obj to selection", icon="MOD_MULTIRES")
            layout.operator("make.link", text = "Link Objects", icon='CONSTRAINT' )
            layout.operator("unlink.objects", text = "Unlink Objects", icon='UNLINKED' )

        

class Symetrize(bpy.types.Menu):
    bl_idname = "object.symetrize"
    bl_label = "Symetrize"
    
    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        Yslap = icons.get("Yslap")
        layout.operator("symetrize.ypositive", text = "(Y-) - Symetrize", icon_value=Yslap.icon_id)
        Yslap = icons.get("Yslap")
        layout.operator("symetrize.ynegative", text = "(Y+) - Symetrize", icon_value=Yslap.icon_id)
        Zslap = icons.get("Zslap")
        layout.operator("symetrize.zpositive", text = "(Z-) - Symetrize", icon_value=Zslap.icon_id)
        Zslap = icons.get("Zslap")
        layout.operator("symetrize.znegative", text = "(Z+) - Symetrize", icon_value=Zslap.icon_id)
        

class SharpSub(bpy.types.Menu):
    bl_label = 'C/S/T Sharp'
    bl_idname = 'sharpmenu.submenu'

    def draw(self, context):
        
        layout = self.layout
#        pie = layout.menu_pie()
        icons = load_icons()
        
        Ssharpen = icons.get("Ssharpen")
        layout.operator("ssharpen.objects", text = "(S) Sharpen", icon_value=Ssharpen.icon_id)
        
        CSharpen = icons.get("CSharpen")
        layout.operator("csharpen.objects", text = "(C) Sharpen", icon_value=CSharpen.icon_id)
        
        Frame = icons.get("Frame")
        layout.operator("cstep.objects", text = "(C) Step", icon_value=Frame.icon_id)
        
        Tsharpen = icons.get("Tsharpen")
        layout.operator("solidify.objects", text = "(T) Sharpen", icon_value=Tsharpen.icon_id)
        
        ClearSharps = icons.get("ClearSharps")
        layout.operator("clean.objects", text = "Clear S/C/Sharps", icon_value=ClearSharps.icon_id)
        
        m_check = context.window_manager.m_check
        
        if bpy.context.object and bpy.context.object.type == 'MESH':

            
            if m_check.meshcheck_enabled:
                layout.operator("object.remove_materials", text="Hidde color", icon='RESTRICT_VIEW_OFF')
            else:
                layout.operator("object.add_materials", text="Display color", icon='COLOR') 
            
            layout.operator("data.facetype_select", text="Ngons").face_type = "5"
            layout.operator("data.facetype_select", text="Tris").face_type = "3"


class ButtonsVPSub(bpy.types.Menu):
    bl_label = 'GUI'
    bl_idname = 'vpmenu.submenu'

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        icons = load_icons()
        
        if context.object.draw_type == 'WIRE':
            layout.operator("object.solid_all", text="Solid Mode", icon='MESH_CUBE')
        else :
            layout.operator("showwire.objects", text = "Wire Mode", icon='OUTLINER_OB_LATTICE')
            
        layout.separator()    
        
        NGui = icons.get("NGui")
        layout.operator("ui.reg", text = "Normal", icon_value=NGui.icon_id)
        
        RGui = icons.get("RGui")
        layout.operator("ui.red", text = "Matcap", icon_value=RGui.icon_id)
        
        QGui = icons.get("QGui")
        layout.operator("ui.clean", text = "Minimal", icon_value=QGui.icon_id)
        
        layout.menu("object.material_list_menu", icon='MATERIAL_DATA')
        
        layout.separator()
        
        RenderSet1 = icons.get("RenderSet1")
        layout.operator("render.setup", text = "Render (1)", icon_value=RenderSet1.icon_id)
        
        SetFrame = icons.get("SetFrame")
        layout.operator("setframe.end", text =  "Frame Range", icon_value=SetFrame.icon_id)
        
        layout.separator()
       
        m_check = context.window_manager.m_check
        
        if bpy.context.object and bpy.context.object.type == 'MESH':

            
            if m_check.meshcheck_enabled:
                layout.operator("object.remove_materials", text="Hidde color", icon='RESTRICT_VIEW_OFF')
            else:
                layout.operator("object.add_materials", text="Display color", icon='COLOR') 
            
            layout.operator("data.facetype_select", text="Ngons").face_type = "5"
            layout.operator("data.facetype_select", text="Tris").face_type = "3"
            
               
class Meshtools(bpy.types.Menu):
    bl_label = 'Mesh Tools'
    bl_idname = 'mstool.submenu'

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        ATwist360 = icons.get("ATwist360")
        layout.operator("array.twist", text = "Twist 360", icon_value=ATwist360.icon_id)
        
        layout.separator()
        
        Xslap = icons.get("Xslap")
        layout.operator("halfslap.object", text = "(X) - Symmetrize", icon_value=Xslap.icon_id)
        
        Yslap = icons.get("Yslap")
        layout.operator("yhalfslap.object", text = "(Y) - Symmetrize", icon_value=Yslap.icon_id)
        
        Zslap = icons.get("Zslap")
        layout.operator("zhalfslap.object", text = "(Z) - Symmetrize", icon_value=Zslap.icon_id)
        layout.separator()
        
        PUnwrap = icons.get("PUnwrap")
        layout.operator("object.runwrap", text = "(P) Unwrap", icon_value=PUnwrap.icon_id)
        
        layout.separator()
        
        SCleanRecenter = icons.get("SCleanRecenter")
        layout.operator("clean.recenter", text = "(S) Clean Recenter", icon_value=SCleanRecenter.icon_id)
        
        Applyall = icons.get("Applyall")
        layout.operator("stomp2.object", text = "ApplyAll (-L)", icon_value=Applyall.icon_id)
        
        
        
        
      
class eMeshtools(bpy.types.Menu):
    bl_label = 'Mesh Tools'
    bl_idname = 'emstool.submenu'

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        CircleSetup = icons.get("CircleSetup")
        layout.operator("circle.setup", text = "Circle", icon_value=CircleSetup.icon_id)
        
        NthCircle = icons.get("NthCircle")
        layout.operator("nth.circle", text = "Circle (Nth)", icon_value=NthCircle.icon_id)
        
        FaceGrate = icons.get("FaceGrate")
        layout.operator("fgrate.op", text = "Grate (Face)", icon_value=FaceGrate.icon_id)
        
        FaceKnurl = icons.get("FaceKnurl")
        layout.operator("fknurl.op", text = "Knurl (Face)", icon_value=FaceKnurl.icon_id)
        
        EdgeRingPanel = icons.get("EdgeRingPanel")
        layout.operator("quick.panel", text = "Grate (Face)", icon_value=EdgeRingPanel.icon_id)
        
        FacePanel = icons.get("FacePanel")
        layout.operator("entrench.selection", text = "Panel (Edge)/(Face)", icon_value=FacePanel.icon_id)
        
        PUnwrap = icons.get("PUnwrap")
        layout.operator("object.runwrap", text = "(P) Unwrap", icon_value=PUnwrap.icon_id)

        