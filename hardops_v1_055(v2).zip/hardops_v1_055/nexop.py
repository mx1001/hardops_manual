# -*- coding: utf-8 -*-

import bpy
import bmesh
from bpy.props import *
from math import pi, radians

#############################
#MODAL Thickness 
#############################

class tthickOperator(bpy.types.Operator):
    """Sets Thickness With A Modal"""
    bl_idname = "tthick.modal_operator"
    bl_label = "Thickness Modal Operator"
    bl_options = {'REGISTER', 'UNDO'}
    
    first_mouse_x = IntProperty()
    first_value = FloatProperty()
    angle = FloatProperty()

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            delta = self.first_mouse_x - event.mouse_x
            try :
                context.object.modifiers["Solidify"]
            except:
                bpy.context.object.modifiers.new("Solidify", "SOLIDIFY")
                bpy.context.object.modifiers["Solidify"].use_quality_normals = True
                bpy.context.object.modifiers["Solidify"].use_even_offset = True
            
                print("Added solidify modifier")
                
            try:
                context.object.modifiers["Solidify"].thickness = self.first_value + delta * 0.0008
            #context.object.location.x = self.first_value + delta * 0.01        
            except: 
                print("could not find first solidify modifier! adding...")
                bpy.context.object.modifiers.new("Solidify", "SOLIDIFY")
                bpy.context.object.modifiers["Solidify"].use_quality_normals = True
                bpy.context.object.modifiers["Solidify"].use_even_offset = True

                print("Added solidify modifier")
            

        elif event.type == 'LEFTMOUSE':
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            #context.object.location.x = self.first_value
            context.object.modifiers["Solidify"].thickness = self.first_value
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.object:
            self.first_mouse_x = event.mouse_x
            #self.first_value = context.object.location.x
            try:
                self.first_value = context.object.modifiers["Solidify"].thickness
            except:
                print("could not find second solidify... adding")
                bpy.context.object.modifiers.new("Solidify", "SOLIDIFY")
                bpy.context.object.modifiers["Solidify"].use_quality_normals = True
                bpy.context.object.modifiers["Solidify"].use_even_offset = True
                print("Added solidify modifier")

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

    def execute(self, context):
        bpy.ops.tthick.modal_operator('INVOKE_DEFAULT')
        return {'CANCELLED'}
        
#############################
#Multi-CSharp
#############################

class multicsharpOperator(bpy.types.Operator):
    """Multi CSharp"""
    bl_idname = "multi.csharp"
    bl_label = "Multi Object Csharp"

    @classmethod
    def poll(cls, context):
        
        obj_type = context.object.type
        return(obj_type in {'MESH'})
        return context.active_object is not None

    def execute(self, context):
        
        
        sel = bpy.context.selected_objects
        active = bpy.context.scene.objects.active.name
        
        for ob in sel:
                ob = ob.name
                bpy.context.scene.objects.active = bpy.data.objects[ob] 
                
                #print(context.selected_objects)
                bpy.ops.csharpen.objects(bevelwidth=0.01)   
            
        return {'FINISHED'}
    
#############################
#Multi-SSharp
#############################

class multissharpOperator(bpy.types.Operator):
    """Multi SSharp"""
    bl_idname = "multi.ssharp"
    bl_label = "Multi Object Ssharp"

    @classmethod
    def poll(cls, context):
        
        obj_type = context.object.type
        return(obj_type in {'MESH'})
        return context.active_object is not None

    def execute(self, context):
        
        
        sel = bpy.context.selected_objects
        active = bpy.context.scene.objects.active.name
        
        for ob in sel:
                ob = ob.name
                bpy.context.scene.objects.active = bpy.data.objects[ob] 
                
                #print(context.selected_objects)
                bpy.ops.ssharpen.objects(ssharpangle=30, alternatemode=False)    
            
        return {'FINISHED'}
    
#############################
#Multi-Clear
#############################

class multiClearOperator(bpy.types.Operator):
    """Multi Clear"""
    bl_idname = "multi.clear"
    bl_label = "Multi Ssharp Clear"

    @classmethod
    def poll(cls, context):
        
        obj_type = context.object.type
        return(obj_type in {'MESH'})
        return context.active_object is not None

    def execute(self, context):
        
        
        sel = bpy.context.selected_objects
        active = bpy.context.scene.objects.active.name
        
        for ob in sel:
                ob = ob.name
                bpy.context.scene.objects.active = bpy.data.objects[ob] 
                
                #print(context.selected_objects)
                bpy.ops.clean.objects()   
            
        return {'FINISHED'}


#Place Object
class placeobjectOperator(bpy.types.Operator):
    "Object Placer"
    bl_idname = "object.placer"
    bl_label = "Object Placer"
    
    @classmethod
    def poll(cls, context):
        
        obj_type = context.object.type
        return(obj_type in {'MESH'})
        return context.active_object is not None

    def execute(self, context):
        
        create_object_to_selection(cube)
            
        return {'FINISHED'}

#Unlink Object    
class UnLink_Objects(bpy.types.Operator):
    bl_idname = "unlink.objects"
    bl_label = "UnLink_Objects"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    
    
    
    def execute(self, context):
        
        bpy.ops.object.make_single_user(type='SELECTED_OBJECTS', object=True, obdata=True, material=False, texture=False, animation=False)
        return {"FINISHED"}


#Apply Material            
class ApplyMaterial(bpy.types.Operator):
    bl_idname = "object.apply_material"
    bl_label = "Apply material"
 
    mat_to_assign = bpy.props.StringProperty(default="")
 
    def execute(self, context):
 
        if context.object.mode == 'EDIT':
            obj = context.object
            bm = bmesh.from_edit_mesh(obj.data)
 
            selected_face = [f for f in bm.faces if f.select]  # si des faces sont sélectionnées, elles sont stockées dans la liste "selected_faces"          
 
            mat_name = [mat.name for mat in bpy.context.object.material_slots if len(bpy.context.object.material_slots)] # pour tout les material_slots, on stock les noms des mat de chaque slots dans la liste "mat_name"
 
            if self.mat_to_assign in mat_name: # on test si le nom du mat sélectionné dans le menu est présent dans la liste "mat_name" (donc, si un des slots possède le materiau du même nom). Si oui:
                context.object.active_material_index = mat_name.index(self.mat_to_assign) # on definit le slot portant le nom du comme comme étant le slot actif
                bpy.ops.object.material_slot_assign() # on assigne le matériau à la sélection
            else: # sinon
                bpy.ops.object.material_slot_add() # on ajout un slot
                bpy.context.object.active_material = bpy.data.materials[self.mat_to_assign] # on lui assigne le materiau choisi
                bpy.ops.object.material_slot_assign() # on assigne le matériau à la sélection
 
            return {'FINISHED'}
 
        elif context.object.mode == 'OBJECT':
 
            obj_list = [obj.name for obj in context.selected_objects]
 
            for obj in obj_list:
                bpy.ops.object.select_all(action='DESELECT')
                bpy.data.objects[obj].select = True                
                bpy.context.scene.objects.active = bpy.data.objects[obj]
                bpy.context.object.active_material_index = 0
 
                if self.mat_to_assign == bpy.data.materials:
                    bpy.context.active_object.active_material = bpy.data.materials[mat_name]
 
                else:
                    if not len(bpy.context.object.material_slots):
                        bpy.ops.object.material_slot_add()
 
                    bpy.context.active_object.active_material = bpy.data.materials[self.mat_to_assign]
 
            for obj in obj_list:
                bpy.data.objects[obj].select = True
 
            return {'FINISHED'}    
