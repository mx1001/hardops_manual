import bpy
import os
from os import listdir
from os.path import isfile, join
from . add_object_to_selection import add_from_dess_insert

Hard_Ops_preview_collections = {}

def enumPreviewsFromDirectoryItems(self, context):
    """EnumProperty callback"""
    enum_items = []
 
    if context is None:
        return enum_items
   
    directory = join(os.path.dirname(__file__), "icons", "dSet1")
    # Get the preview collection (defined in register func).
    pcoll = Hard_Ops_preview_collections["main"]
 
    if directory == pcoll.Hard_Ops_previews_dir:
        return pcoll.Hard_Ops_previews
 
    # print("Scanning directory: %s" % directory)
 
    if directory and os.path.exists(directory):
        # Scan the directory for png files
        image_paths = []
        for fn in os.listdir(directory):
            if fn.lower().endswith(".png"):
                image_paths.append(fn)
 
        for i, name in enumerate(image_paths):
            # generates a thumbnail preview for a file.
            filepath = os.path.join(directory, name)
            thumb = pcoll.load(filepath, filepath, 'IMAGE')
            enum_items.append((name, name, "", thumb.icon_id, i))
 
    pcoll.Hard_Ops_previews = enum_items
    pcoll.Hard_Ops_previews_dir = directory
 
    return pcoll.Hard_Ops_previews
 
 
def register_Hard_Ops_pcoll():  
    from bpy.types import WindowManager
    from bpy.props import (
            EnumProperty,
            BoolProperty)
 
    WindowManager.Hard_Ops_previews = EnumProperty(
            items=enumPreviewsFromDirectoryItems,
            update=add_from_dess_insert)
 
    import bpy.utils.previews
    wm = bpy.context.window_manager
    pcoll = bpy.utils.previews.new()
    pcoll.Hard_Ops_previews_dir = ""
    pcoll.Hard_Ops_previews = ()
 
    Hard_Ops_preview_collections["main"] = pcoll
 
 
def unregister_Hard_Ops_pcoll():
    from bpy.types import WindowManager
 
    del WindowManager.Hard_Ops_previews
 
    for pcoll in Hard_Ops_preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    Hard_Ops_preview_collections.clear()
