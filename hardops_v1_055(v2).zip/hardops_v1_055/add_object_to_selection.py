import bpy
import bmesh
from mathutils import Vector   
 
 
def deesinsert_choise(object):
    if object == "Wing.png":
        bpy.ops.mesh.wing()
    elif object == "Torx.png":
        bpy.ops.mesh.torx()
    elif object == "Tee.png":
        bpy.ops.mesh.tee()
    elif object == "Square.png":
        bpy.ops.mesh.square()
    elif object == "Span_Head.png":
        bpy.ops.mesh.span_head()
    elif object == "Phps_Rnd_2.png":
        bpy.ops.mesh.phps_rnd_2()
    elif object == "Phps_Rnd.png":
        bpy.ops.mesh.phps_rnd()
    elif object == "Phps_Hex.png":
        bpy.ops.mesh.phps_hex()
    elif object == "Phps_Flat.png":
        bpy.ops.mesh.phps_flat()
    elif object == "Phps_CntrSnk.png":
        bpy.ops.mesh.phps_cntrsnk()
    elif object == "Knurl_Head.png":
        bpy.ops.mesh.knurl_head()
    elif object == "InsertJam.png":
        bpy.ops.mesh.insertjam()
    elif object == "Hex_Socket.png":
        bpy.ops.mesh.hex_socket()
    elif object == "Hex_Raised.png":
        bpy.ops.mesh.hex_raised()
    elif object == "Hex_Nut.png":
        bpy.ops.mesh.hex_nut()
    elif object == "Hex_Flat.png":
        bpy.ops.mesh.hex_flat()
    elif object == "Hex.png":
        bpy.ops.mesh.hex()
    elif object == "FLAT_RND.png":
        bpy.ops.mesh.flat_rnd()
    elif object == "Flange_Cap.png":
        bpy.ops.mesh.flange_cap()
    elif object == "Flange.png":
        bpy.ops.mesh.flange()
    elif object == "Cap.png":
        bpy.ops.mesh.cap()
    elif object == "Button.png":
        bpy.ops.mesh.button()
    

def add_from_dess_insert(self, context):
    wm = context.window_manager
    object = wm.Hard_Ops_previews
    obj_list = []    
    second_obj = ""
    
    if context.object.mode == 'OBJECT':
        deesinsert_choise(object)
        
    elif context.object.mode == 'EDIT':        
        bpy.ops.object.mode_set(mode='OBJECT')  
        ref_obj = bpy.context.active_object
        if len(context.selected_objects) == 2:
            obj1, obj2 = context.selected_objects
            second_obj = obj1 if obj2 == ref_obj else obj2
        
            bpy.data.objects[second_obj.name].select=False

        bpy.ops.object.duplicate_move()
        bpy.context.active_object.name = "Dummy"
        obj = context.active_object
        bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')    
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        
        copy_cursor = bpy.context.scene.cursor_location.copy()  
        
        bm = bmesh.new()
        bm.from_mesh(obj.data)
     
     
        selected_faces = [f for f in bm.faces if f.select]
     
        for face in selected_faces:
     
            face_location = face.calc_center_median()
     
            loc_world_space = obj.matrix_world * Vector(face_location)
     
            z = Vector((0,0,1))
     
            angle = face.normal.angle(z)
     
            axis = z.cross(face.normal)
            bpy.context.scene.cursor_location = loc_world_space

            deesinsert_choise(object)
            
     
            bpy.ops.transform.rotate(value=angle, axis=axis)
            obj_list.append(context.object.name)
     
        bm.to_mesh(obj.data)
     
        bm.free()
        
        bpy.context.scene.cursor_location = copy_cursor
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.scene.objects.active = bpy.data.objects["Dummy"]         
        bpy.data.objects["Dummy"].select = True
        bpy.ops.object.delete(use_global=False)
        
        bpy.context.scene.objects.active = bpy.data.objects[obj_list[0]]
        
        for obj in obj_list:
            bpy.data.objects[obj].select=True
            bpy.ops.make.link()  # custom link called from operators module
        
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.scene.objects.active = bpy.data.objects[ref_obj.name]
        if second_obj:
            bpy.data.objects[second_obj.name].select=True   
        bpy.data.objects[ref_obj.name].select=True
     
        bpy.ops.object.mode_set(mode='EDIT')
        del(obj_list[:])
 
 
 
class SelectedToSelection(bpy.types.Operator):
    bl_idname = "object.to_selection"
    bl_label = "To selection"
 
    def execute(self, context):
        
        obj_list = []
        bpy.ops.object.mode_set(mode='OBJECT')
        ref_obj = bpy.context.active_object

        obj1, obj2 = context.selected_objects
        second_obj = obj1 if obj2 == ref_obj else obj2                                 
        
        obj_list.append(second_obj.name)
        bpy.data.objects[second_obj.name].select = False 
        bpy.ops.object.duplicate_move()
        bpy.context.active_object.name = "Dummy"
        obj = context.active_object
        bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')    
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        
        
        copy_cursor = bpy.context.scene.cursor_location.copy()     
 
        bm = bmesh.new()
        bm.from_mesh(obj.data)
 
 
        selected_faces = [f for f in bm.faces if f.select]
 
        for face in selected_faces:
 
            face_location = face.calc_center_median()
 
            loc_world_space = obj.matrix_world * Vector(face_location)
 
            z = Vector((0,0,1))
 
            angle = face.normal.angle(z)
 
            axis = z.cross(face.normal)
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.scene.objects.active = bpy.data.objects[second_obj.name]
            bpy.data.objects[second_obj.name].select=True
            bpy.ops.object.duplicate()
            bpy.context.scene.cursor_location = loc_world_space
            bpy.ops.view3d.snap_selected_to_cursor()
 
            bpy.ops.transform.rotate(value=angle, axis=axis)
            obj_list.append(context.object.name)
 
        bm.to_mesh(obj.data)
 
        bm.free()
 
        bpy.context.scene.cursor_location = copy_cursor
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.scene.objects.active = bpy.data.objects["Dummy"]         
        bpy.data.objects["Dummy"].select = True
        bpy.ops.object.delete(use_global=False)
        
        bpy.context.scene.objects.active = bpy.data.objects[obj_list[0]]
         
        for obj in obj_list:
            bpy.data.objects[obj].select=True
            bpy.ops.make.link()  # custom link called from operators module
         
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.scene.objects.active = bpy.data.objects[ref_obj.name]
        bpy.data.objects[second_obj.name].select=True
        bpy.data.objects[ref_obj.name].select=True
         
        bpy.ops.object.mode_set(mode='EDIT')        
        del(obj_list[:])
        
 
        return {'FINISHED'}

def add_primitive():
    
    #Primitives
    if bpy.context.window_manager.choose_primitive == 'cube':
        bpy.ops.mesh.primitive_cube_add(radius=1)

    #Cylinders
    elif bpy.context.window_manager.choose_primitive == "cylinder_8":
        bpy.ops.mesh.primitive_cylinder_add(vertices=8, radius=1, depth=2)
    
    elif bpy.context.window_manager.choose_primitive == 'placeholder':
        bpy.ops.mesh.primitive_cylinder_add(vertices=16, radius=1, depth=2) 
    
    elif bpy.context.window_manager.choose_primitive == 'cylinder_24':
        bpy.ops.mesh.primitive_cylinder_add(vertices=24, radius=1, depth=2)        
          
    elif bpy.context.window_manager.choose_primitive == "cylinder_32":
        bpy.ops.mesh.primitive_cylinder_add(vertices=32, radius=1, depth=2)  
    
    elif bpy.context.window_manager.choose_primitive == "cylinder_64":
        bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=1, depth=2)
     
def create_object_to_selection(self, context):
    
    if not bpy.context.object:
        add_primitive()
#        bpy.ops.object.orientationvariable(variable="LOCAL")

        
        
    elif context.object.mode == 'EDIT':
        #Duplicate the mesh, apply his transform and perform the code to add object on it
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.duplicate_move()
        bpy.context.active_object.name = "Dummy"
        bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')    
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        
        list_insert_meshes = [] 
        obj = bpy.context.active_object
        saved_location = bpy.context.scene.cursor_location.copy()
        
        bm = bmesh.new()
        bm.from_mesh(obj.data) 
            
        selected_faces = [f for f in bm.faces if f.select]

        for face in selected_faces:            
            face_location = face.calc_center_median()
            loc_world_space = obj.matrix_world * Vector(face_location)                                                    
            z = Vector((0,0,1))                
            angle = face.normal.angle(z)                    
            axis = z.cross(face.normal)
                            
            bpy.context.scene.cursor_location = loc_world_space 
            
            add_primitive() 
          
            bpy.ops.transform.rotate(value=angle, axis=axis)
            
            list_insert_meshes.append(context.active_object.name)
                            
        bm.to_mesh(obj.data)                
        bm.free()        
        bpy.context.scene.cursor_location = saved_location      
        
        #Deselect all the objects, select the dummy object and delete it
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.scene.objects.active = bpy.data.objects["Dummy"]

        bpy.context.object.select = True
        bpy.ops.object.delete(use_global=False)
        
        #Select inserted meshes
        for obj in list_insert_meshes:
            bpy.context.scene.objects.active = bpy.data.objects[obj]
            bpy.data.objects[obj].select=True
            if len(list_insert_meshes) > 1: 
                bpy.ops.object.make_links_data(type='OBDATA') #Make link            
            
            
            #for the next code with selections
#            is_modifier = False
#                for mode in bpy.context.object.modifiers : #copy modifiers
#                    if mode.type == True :
#                        is_modifier = True
#                if is_modifier == True :  
#                
#                    bpy.ops.object.make_links_data(type='MODIFIERS')
#                else :
#                    pass    


            
        del(list_insert_meshes[:])
#        bpy.ops.object.orientationvariable(variable="LOCAL")

                
    else:
        saved_location = bpy.context.scene.cursor_location.copy()
        bpy.ops.view3d.snap_cursor_to_selected()
        
        add_primitive()
        
        bpy.context.scene.cursor_location = saved_location
#        bpy.ops.object.orientationvariable(variable="LOCAL")