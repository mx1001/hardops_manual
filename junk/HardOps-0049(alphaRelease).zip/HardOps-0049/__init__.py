bl_info = {
	"name": "Hard Ops",
	"author": "MX, IS, RF JM, AR, BF. PL and you",
	"version": (0, 0, 4, 9),
	"blender": (2, 7, 6),
	"description": "Hard Ops - Hard Surface Tactical Operations",
	"category": "3D View"}


import bpy.utils.previews
icons_dict = bpy.utils.previews.new()
#added this
custom_icons = bpy.utils.previews.new()

import os
import bpy
import bmesh
from bpy.props import *
from math import pi, radians
import bpy.utils.previews

class customMenu(bpy.types.Menu):
    bl_label = "HardOps Ver:0049iE"
    bl_idname = "customMenu"
    
    def draw(self, context):
        #CustomIcons Stuff
        global custom_icons
       
        layout = self.layout
        
        #icons = load_icons()
        
        if bpy.context.object.mode == "EDIT":
            #print("EDIT MODE!")
            layout.operator("bevelandsharp1.objects", text = "Make SSharp", icon_value=custom_icons["MakeSharpE"].icon_id)
            layout.operator("clean1.objects", text = "Clean SSharps", icon_value=custom_icons["CleansharpsE"].icon_id)
            layout.operator("ehalfslap.object", text = "QuickX", icon_value=custom_icons["Xslap"].icon_id)
            layout.separator()
            layout.menu(eMeshtools.bl_idname, icon_value=custom_icons["Frame"].icon_id  )
            layout.separator()
            #layout.menu("display.components", icon='COLOR')
                               
        else:
            #print("OBJECT/OTHER MODE!")
            #layout.operator("custom.icon", text = "CustomIcon", )
            layout.separator()
            layout.menu(SharpSub.bl_idname, icon_value=custom_icons["CST"].icon_id)
            layout.separator()
            layout.operator("bwidth.modal_operator", text = "Set Bevel", icon_value=custom_icons["AdjustBevel"].icon_id) 
            layout.separator()
            layout.operator("reverse.boolean", text = "ReBool", icon_value=custom_icons["ReBool"].icon_id) 
            layout.separator()
            layout.menu(Meshtools.bl_idname, icon_value=custom_icons["Diagonal"].icon_id)
            layout.separator()
            layout.menu(ImpSettings.bl_idname, icon_value=custom_icons["Frame"].icon_id)
            layout.separator()
            layout.menu(ButtonsVPSub.bl_idname, icon_value=custom_icons["Gui"].icon_id)
            layout.separator()
            
custom_icons = None
print ('Menu Tiem!')

#############################
#SubMenus
#############################

class SharpSub(bpy.types.Menu):
    bl_label = 'C/S/T Sharp'
    bl_idname = 'view3d.sharpmenu_submenu'

    def draw(self, context):
        layout = self.layout
        
        layout.operator("ssharpen.objects", text = "SSharpen", icon_value=custom_icons["Ssharpen"].icon_id)
        layout.separator()
        layout.operator("csharpen.objects", text = "CSharpen", icon_value=custom_icons["CSharpen"].icon_id)
        layout.separator()
        layout.operator("cstep.objects", text = "CStep", icon_value=custom_icons["Frame"].icon_id)
        layout.separator()
        layout.operator("solidify.objects", text = "TSharpen", icon_value=custom_icons["Tsharpen"].icon_id)
        layout.separator()
        layout.operator("bwidth.modal_operator", text = "Bevel Width", icon_value=custom_icons["AdjustBevel"].icon_id)
        layout.separator()
        layout.operator("reverse.boolean", text = "RevBoolean", icon_value=custom_icons["ReBool"].icon_id)  
        layout.separator()
        layout.operator("clean.objects", text = "Clear S/C/Sharps", icon_value=custom_icons["ClearSharps"].icon_id)
        

class ButtonsVPSub(bpy.types.Menu):
    bl_label = 'GUI'
    bl_idname = 'view3d.vpmenu_submenu'

    def draw(self, context):
        layout = self.layout

        #layout.label("ViewportChoices")
        layout.operator("ui.reg", text = "Normal GUI", icon_value=custom_icons["NGui"].icon_id)
        layout.operator("ui.red", text = "Red Mode GUI", icon_value=custom_icons["RGui"].icon_id)
        layout.operator("ui.clean", text = "Quiet GUI", icon_value=custom_icons["QGui"].icon_id)
        
class ImpSettings(bpy.types.Menu):
    bl_label = 'Render/FrameRange'
    bl_idname = 'view3d.renplay_submenu'

    def draw(self, context):
        layout = self.layout

        #layout.label("ViewportChoices")
        layout.operator("render.setup", text = "RenderSet1", icon_value=custom_icons["RenderSet1"].icon_id)
        layout.separator()
        layout.operator("setframe.end", text =  "Set FrameEnd", icon_value=custom_icons["SetFrame"].icon_id)
        
class Meshtools(bpy.types.Menu):
    bl_label = 'MeshTools'
    bl_idname = 'view3d.mstool_submenu'

    def draw(self, context):
        layout = self.layout
        layout.operator("array.twist", text = "ATwist360", icon_value=custom_icons["ATwist360"].icon_id)
        layout.separator()
        layout.operator("reverse.boolean", text = "ReBool", icon_value=custom_icons["ReBool"].icon_id)     
        layout.separator()
        layout.operator("showwire.objects", text = "BBox Off - Show Wire", icon_value=custom_icons["Bboxoff"].icon_id)
        layout.separator()
        layout.operator("halfslap.object", text = "X-Slap", icon_value=custom_icons["Xslap"].icon_id)
        layout.operator("yhalfslap.object", text = "Y-Slap", icon_value=custom_icons["Yslap"].icon_id)
        layout.separator()
        layout.operator("object.runwrap", text = "PUnwrap", icon_value=custom_icons["PUnwrap"].icon_id)
        layout.separator()
        layout.operator("clean.recenter", text = "SClean Recenter", icon_value=custom_icons["SCleanRecenter"].icon_id)
        layout.operator("stomp2.object", text = "ApplyAll(-L)", icon_value=custom_icons["Applyall"].icon_id)
        #layout.operator("stomp.object", text = "ApplyAll")
        
class eMeshtools(bpy.types.Menu):
    bl_label = 'MeshTools(E)'
    bl_idname = 'view3d.emstool_submenu'

    def draw(self, context):
        layout = self.layout
        
        layout.operator("circle.setup", text = "(E)CircleSetup", icon_value=custom_icons["CircleSetup"].icon_id)
        layout.operator("fgrate.op", text = "(E)FaceGrateSetup", icon_value=custom_icons["FaceGrate"].icon_id)
        layout.operator("fknurl.op", text = "(E)FaceKnurlSetup", icon_value=custom_icons["FaceKnurl"].icon_id)
        layout.operator("nth.circle", text = "(E)NthCircleSetup", icon_value=custom_icons["NthCircle"].icon_id)
        layout.separator()
        layout.operator("quick.panel", text = "(E)Face - Panel", icon_value=custom_icons["EdgeRingPanel"].icon_id)
        layout.operator("entrench.selection", text = "(E)Edge Loop Ring - Panel", icon_value=custom_icons["EdgeRingPanel"].icon_id)

#Wazou added this. Currently disabled due to being broken.
class Display_Components(bpy.types.Menu):
    bl_idname = "display.components"
    bl_label = "Display Components"
    
    def draw(self, context):
        layout = self.layout
        
        show_text = context.window_manager.show_text
            
        
        row = layout.row(align=True)
        if show_text.display_color_enabled:
            row.operator("object.remove_materials", text="Hide Colors", icon='RESTRICT_VIEW_OFF')
        else:
            row.operator("object.add_materials", text="Display Colors", icon='COLOR') 
        row = layout.row(align=True)
        
        row.separator()
        layout.operator("data.triangles_select", text="Select Triangles", icon='TRIA_UP')
        layout.operator("data.ngons_select", text="Select Ngons", icon='GROUP_VERTEX')

#############################
#MODAL Bevel Width
#############################

class bwidthOperator(bpy.types.Operator):
    """Sets Bevel Width With A Modal"""
    bl_idname = "bwidth.modal_operator"
    bl_label = "Simple Modal Operator"
    bl_options = {'REGISTER', 'UNDO'}
    
    first_mouse_x = IntProperty()
    first_value = FloatProperty()
    angle = FloatProperty()

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            delta = self.first_mouse_x - event.mouse_x
            try :
                context.object.modifiers["Bevel"]
            except:
                bpy.context.object.modifiers.new("Bevel", "BEVEL")
                bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
                bpy.context.object.modifiers["Bevel"].show_in_editmode = False
                #bpy.context.object.modifiers["Bevel"].width = bevelwidth
                bpy.context.object.modifiers["Bevel"].segments = 3
                bpy.context.object.modifiers["Bevel"].profile = 0.70
                print("Added bevel modifier")
                
            try:
                context.object.modifiers["Bevel"].width = self.first_value + delta * 0.0008
            #context.object.location.x = self.first_value + delta * 0.01        
            except: 
                print("could not find first bevel modifier! adding...")
                bpy.context.object.modifiers.new("Bevel", "BEVEL")
                bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
                bpy.context.object.modifiers["Bevel"].show_in_editmode = False
                #bpy.context.object.modifiers["Bevel"].width = bevelwidth
                bpy.context.object.modifiers["Bevel"].segments = 3
                bpy.context.object.modifiers["Bevel"].profile = 0.70
                print("Added bevel modifier")
            

        elif event.type == 'LEFTMOUSE':
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            #context.object.location.x = self.first_value
            context.object.modifiers["Bevel"].width = self.first_value
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.object:
            self.first_mouse_x = event.mouse_x
            #self.first_value = context.object.location.x
            try:
                self.first_value = context.object.modifiers["Bevel"].width
            except:
                    print("could not find second bevel... adding")
                    bpy.context.object.modifiers.new("Bevel", "BEVEL")
                    bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
                    bpy.context.object.modifiers["Bevel"].show_in_editmode = False
                    #bpy.context.object.modifiers["Bevel"].width = bevelwidth
                    bpy.context.object.modifiers["Bevel"].segments = 3
                    bpy.context.object.modifiers["Bevel"].profile = 0.70
                    print("Added bevel modifier")
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

    def execute(self, context):
        bpy.ops.bwidth.modal_operator('INVOKE_DEFAULT')
        return {'CANCELLED'}
    
#############################
#Adrian's CStep
#############################
class cstepOperator(bpy.types.Operator):
    '''AR's Cstep Idea'''
    bl_idname = "cstep.objects"
    bl_label = "CStep"
    bl_options = {'REGISTER', 'UNDO'} 
    
    #Declare Some Variables Here
    tthick = FloatProperty(name="ThickeningAmount", description="Set Thickness Amount", default= .1, min = 0.001, max = 4.0)
          
    angle = FloatProperty(name="AutoSmooth Angle", description="Set AutoSmooth angle", default= 60.0, min = 0.0, max = 180.0)
    
    bevelwidth = FloatProperty(name="Bevel Width Amount", description="Set Bevel Width", default= 0.01, min = 0.002, max = .25)
         
    def execute(self, context):
        #convert angle
        bevelwidth = self.bevelwidth
        tthick = self.tthick
        ob = bpy.context.selected_objects
        angle = self.angle
        angle = angle * (3.14159265359/180)
        
                
        #start off removing solidify and bevel to avoid issues later.
        #bpy.ops.object.modifier_remove(modifier="Bevel")
        #bpy.ops.object.modifier_remove(modifier="Solidify")
        
        #go into edit mode and select nothing then select all
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.mode_set(mode='EDIT')
        #bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.reveal()
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
		# bpy.ops.mesh.edges_select_sharp()

        # remove creese and weight
        bpy.ops.transform.edge_bevelweight(value=-1)
        bpy.ops.transform.edge_crease(value=-1)

        #convert to Loop and Mark Sharp + Beveling
        #bpy.ops.mesh.region_to_loop()   
        #bpy.ops.transform.edge_bevelweight(value=1)
        #bpy.ops.mesh.mark_sharp()
        bpy.ops.mesh.hide()
        bpy.ops.object.editmode_toggle()
        
        #add Bevel
        bpy.ops.object.modifier_add(type='BEVEL')
        bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
        bpy.context.object.modifiers["Bevel"].show_in_editmode = False
        bpy.context.object.modifiers["Bevel"].width = bevelwidth
        bpy.context.object.modifiers["Bevel"].segments = 3
        bpy.context.object.modifiers["Bevel"].profile = 0.7
        bpy.context.object.modifiers["Bevel"].limit_method = 'WEIGHT'
        bpy.context.object.modifiers["Bevel"].angle_limit = angle
       
        #set Smoothing
        #bpy.context.object.data.use_auto_smooth = True
        #bpy.context.object.data.auto_smooth_angle = angle
        bpy.ops.object.shade_smooth()

        return {'FINISHED'}


#############################
#Reverse Boolean
#############################

class RevBool(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "reverse.boolean"
    bl_label = "ReverseBoolean"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        #main(context)
        context = bpy.context
        scene = context.scene

        obj = context.object.copy()

        bool_mods = [m for m in obj.modifiers if m.type == 'BOOLEAN']

        if len(bool_mods):
            mod = bool_mods[-1]
            if mod.operation == 'DIFFERENCE':
                mod.operation = 'INTERSECT'
            elif mod.operation == 'INTERSECT':
                mod.operation = 'DIFFERENCE'

        scene.objects.link(obj)
        return {'FINISHED'}


#############################
#Paweł Łyczkowski's Hard UVs 
#############################

class RUnwrap(bpy.types.Operator):
    '''Tooltip'''
    bl_description = "Paweł Łyczkowski made a quick UV script and now it's part of hard ops!"
    bl_idname = "object.runwrap"
    bl_label = "RUnwrap"
    bl_options = {'REGISTER', 'UNDO'}
 
    rsharpness = bpy.props.FloatProperty(name="Island Size", default=1)
 
    @classmethod
    def poll(cls, context):
            obj_type = obj.type
            # return(obj and obj_type in {'MESH', 'CURVE', 'SURFACE', 'ARMATURE', 'FONT', 'LATTICE'} and context.mode == 'OBJECT')
            return(obj in {'MESH'})
 
    def execute(self, context):
 
            for obj in bpy.context.selected_objects:
 
                    #area = bpy.context.area
                    #old_type = area.type
                   
                    bpy.context.scene.objects.active = obj
 
                    bpy.ops.object.mode_set(mode = 'EDIT')
                    bpy.ops.mesh.select_mode(type="EDGE")
 
                    bpy.ops.mesh.select_all(action = 'DESELECT')
                    bpy.ops.mesh.edges_select_sharp(sharpness=self.rsharpness)
                    bpy.ops.mesh.mark_seam(clear=False)
 
                    bpy.ops.mesh.select_all(action = 'DESELECT')
                    bpy.ops.mesh.select_similar(type='SHARP', threshold=0.01)
                    bpy.ops.mesh.mark_seam(clear=False)
                   
                    bpy.ops.mesh.select_all(action = 'DESELECT')
                    me = obj.data
                    bm = bmesh.from_edit_mesh(me)
                    for e in bm.edges:
                            if not e.smooth:
                                    e.select = True
                    bpy.ops.mesh.mark_seam(clear=False)
                    bmesh.update_edit_mesh(me, False)
 
                    bpy.ops.mesh.select_all(action = 'SELECT')
                    #area.type = 'IMAGE_EDITOR'
                    #bpy.ops.uv.pin(clear=True)
                    #area.type = old_type
                    bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=0.010)
                    bpy.ops.mesh.select_all(action = 'DESELECT')
                    bpy.ops.object.mode_set(mode = 'OBJECT')
 
            return {'FINISHED'}
        
#############################
#Skin Hose Experimental
#############################

#creates a skin mod hose / needs a vert count limit so it doesnt cause crashes
class skinhoseOperator(bpy.types.Operator):
    "Sets EndTime On Timeline Maybe start too someday"
    bl_idname = "skinhose.add"
    bl_label = "VertToSkinHose"
    
    def execute(self, context):
        bpy.ops.object.modifier_add(type='SUBSURF')
        bpy.ops.object.modifier_add(type='SKIN')
        bpy.ops.object.modifier_add(type='SUBSURF')
        bpy.context.object.modifiers["Subsurf"].show_expanded = False
        #bpy.context.object.modifiers["Skin"].show_expanded = False
        bpy.context.object.modifiers["Subsurf.001"].show_expanded = False
        bpy.context.object.modifiers["Subsurf"].show_in_editmode = False
        #bpy.context.object.modifiers["Skin"].show_in_editmode = False
        bpy.context.object.modifiers["Subsurf.001"].show_in_editmode = False
        #I need to add a query here but I'm tired right now. 
        return {'FINISHED'}


#Sets the final frame. Experimental
class endframeOperator(bpy.types.Operator):
    "Sets EndTime On Timeline Maybe start too someday"
    bl_idname = "setframe.end"
    bl_label = "Frame Range"
    bl_options = {'REGISTER', 'UNDO'}
    
    #this should be a property next to the option
       
    firstframe = IntProperty(name="StartFrame", description="SetStartFrame.", default=1, min = 1, max = 20000)
    lastframe = IntProperty(name="EndFrame", description="SetStartFrame.", default=100, min = 1, max = 20000)
    
    
    def execute(self, context):
        lastframe=self.lastframe #needed to get var involved
        firstframe=self.firstframe
        bpy.context.scene.frame_start = firstframe
        bpy.context.scene.frame_end = lastframe
        return {'FINISHED'}
    
    
#Sets Up The Render / As Always
class renset1Operator(bpy.types.Operator):
    "Typical Starter Render Settings"
    bl_idname = "render.setup"
    bl_label = "RenderSetup"
    
    def execute(self, context):
        bpy.context.scene.cycles.sample_clamp_indirect = 2
        bpy.context.scene.cycles.sample_clamp_direct = 2
        bpy.context.scene.cycles.use_square_samples = True
        bpy.context.scene.cycles.preview_samples = 20
        bpy.context.scene.cycles.samples = 20
        bpy.context.scene.cycles.min_bounces = 5
        bpy.context.scene.cycles.glossy_bounces = 16
        bpy.context.scene.cycles.diffuse_bounces = 16
        bpy.context.scene.cycles.blur_glossy = 0.8
        bpy.context.scene.world.cycles.sample_as_light = True
        bpy.context.scene.world.cycles.sample_map_resolution = 512
        return {'FINISHED'}

#############################
#FaceOps Start Here
#############################

#Sets Up Faces For Grating
class facegrateOperator(bpy.types.Operator):
    "Face Grate Setup"
    bl_idname = "fgrate.op"
    bl_label = "FaceGrate" 
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        bpy.context.space_data.pivot_point = 'INDIVIDUAL_ORIGINS'
        bpy.ops.mesh.poke()
        
        #Threshold is a tricky devil
        bpy.ops.mesh.tris_convert_to_quads(face_threshold=0.698132, shape_threshold=1.39626)        
        bpy.ops.mesh.inset(thickness=0.004, use_individual=True)   
        return {'FINISHED'}
    
#Sets Up Faces For Knurling
class faceknurlOperator(bpy.types.Operator):
    "Face Knurl Setup"
    bl_idname = "fknurl.op"
    bl_label = "FaceKnurl" 
    bl_options = {'REGISTER', 'UNDO'}
    
    knurlSubd = IntProperty(name="KnurlSubdivisions", description="Amount Of Divisions", default=0, min = 0, max = 5)
    
    def execute(self, context):
        #allows the knurl to be subdivided
        knurlSubd = self.knurlSubd
        bpy.ops.mesh.subdivide(number_cuts=knurlSubd, smoothness=0)
                
        bpy.ops.mesh.inset(thickness=0.024, use_individual=True)
        bpy.ops.mesh.poke()
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        bpy.ops.mesh.select_less()
        #bpy.ops.transform.shrink_fatten(value=0.2, use_even_offset=True, mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        return {'FINISHED'}


#############################
#Set UI Ops Start Here
#############################

#Return The UI Back To Normal
class reguiOperator(bpy.types.Operator):
    "Turns On Stuff I'd Turn Off"
    bl_idname = "ui.reg"
    bl_label = "regViewport"   
    
    def execute(self, context):
        bpy.context.space_data.show_floor = True
        bpy.context.space_data.show_relationship_lines = True
        bpy.context.space_data.show_only_render = False
        bpy.context.space_data.use_matcap = False
        return {'FINISHED'}

#Attempting To Clean Up UI For A Clean Workspace
class cleanuiOperator(bpy.types.Operator):
    "Turns Off Stuff I'd Turn Off"
    bl_idname = "ui.clean"
    bl_label = "cleanViewport"   
    
    def execute(self, context):
        bpy.context.space_data.show_floor = False
        bpy.context.space_data.show_relationship_lines = False
        bpy.context.space_data.show_only_render = True
        bpy.context.space_data.use_matcap = False
        return {'FINISHED'}
    
#ClassicBigRedMode
class redmodeOperator(bpy.types.Operator):
    "Cleans UI / Preps You With Red"
    bl_idname = "ui.red"
    bl_label = "redViewport"   
    
    def execute(self, context):
        bpy.context.space_data.show_floor = False
        bpy.context.space_data.show_relationship_lines = False
        bpy.context.space_data.show_only_render = True
        bpy.context.space_data.use_matcap = True
        bpy.context.space_data.matcap_icon = '12'
        return {'FINISHED'}
        
#############################
#OrginAndApply Operators Start Here
#############################

class cleanRecenter(bpy.types.Operator):
    "RemovesDoubles/RecenterOrgin/ResetGeometry"
    bl_idname = "clean.recenter"
    bl_label = "CleanRecenter"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        #maybe convert to mesh then recenter
        bpy.ops.object.modifier_remove(modifier="Bevel")
        #bpy.ops.object.modifier_remove(modifier="Solidify")
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.remove_doubles()
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
        bpy.ops.object.location_clear()
        return {'FINISHED'}

#apply all 2 except Loc at once and be done    
class stompObjectnoloc(bpy.types.Operator):
    "RemovesDoubles/ResetGeometry/NotLoc"
    bl_idname = "stomp2.object"
    bl_label = "stompObjectnoLoc"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
        #bpy.ops.object.location_clear()
        return {'FINISHED'}

#apply all 3 at once and be done
class stompObject(bpy.types.Operator):
    "Applies LocRotScale Finally"
    bl_idname = "stomp.object"
    bl_label = "stompObject"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.location_clear()
        return {'FINISHED'}

#############################
#AutoMirroring-X Operators Start Here
#############################

#half stomps in edit mode
class ehalfStomp(bpy.types.Operator):
    "Symmetrizes Based Off Of Right"
    bl_idname = "ehalfslap.object"
    bl_label = "ehalfslapObject"
    bl_options = {'REGISTER', 'UNDO'} 
    
        
    def execute(self, context):
        #bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.reveal()
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='NEGATIVE_X')
        #bpy.ops.object.editmode_toggle()
        return {'FINISHED'}

#half stomps in object mode
class halfStomp(bpy.types.Operator):
    "Symmetrizes Based Off Of Right"
    bl_idname = "halfslap.object"
    bl_label = "halfslapObject"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.reveal()
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='NEGATIVE_X')
        bpy.ops.object.editmode_toggle()
        return {'FINISHED'}
    
#half stomps in object mode
class yhalfStomp(bpy.types.Operator):
    "Symmetrizes Based Off Of Right"
    bl_idname = "yhalfslap.object"
    bl_label = "yhalfslapObject"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.reveal()
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='NEGATIVE_Y')
        bpy.ops.object.editmode_toggle()
        return {'FINISHED'}

class reactivateWire(bpy.types.Operator):
    '''Show Wire'''
    bl_idname = "showwire.objects"
    bl_label = "showWire"
    bl_options = {'REGISTER', 'UNDO'} 
    
    noexist = BoolProperty(default = False)
    
    def draw(self, context):
        layout = self.layout

        box = layout.box()
        # DRAW YOUR PROPERTIES IN A BOX
        box.prop( self, 'noexist', text = "Unrenderable" )
    
    def execute(self, context):
        bpy.context.object.show_wire = True
        bpy.context.object.draw_type = 'WIRE'
        bpy.context.object.show_all_edges = True
        
        if self.noexist:
            bpy.context.object.cycles_visibility.camera = False
            bpy.context.object.cycles_visibility.diffuse = False
            bpy.context.object.cycles_visibility.glossy = False
            bpy.context.object.cycles_visibility.transmission = False
            bpy.context.object.cycles_visibility.scatter = False
            bpy.context.object.cycles_visibility.shadow = False
        
        else:
            bpy.context.object.cycles_visibility.camera = False
        return {'FINISHED'}

#############################
#Sharpen Operators Start Here
#############################

class xsharpenOperator(bpy.types.Operator):
    '''Sharpen Test'''
    bl_idname = "xsharpen.objects"
    bl_label = "XSharpen"
    bl_options = {'REGISTER', 'UNDO'} 
    
    ssharpangle = FloatProperty(name="SSharpening Angle", description="Set SSharp Angle", default= 30.0, min = 0.0, max = 180.0)
    
    angle = FloatProperty(name="AutoSmooth Angle", description="Set AutoSmooth angle", default= 60.0, min = 0.0, max = 180.0)
    
    bevelwidth = FloatProperty(name="Bevel Width Amount", description="Set Bevel Width", default= 0.0071, min = 0.002, max = .25)
      
    def execute(self, context):
        
        #convert angle
        ob = bpy.context.selected_objects
        angle = self.angle
        ssharpangle = self.ssharpangle
        angle = angle * (3.14159265359/180)
        #ssharpangle = self.ssharpangle
        ssharpangle = ssharpangle * (3.14159265359/180)
        
        #angle = bpy.context.object.data.auto_smooth_angle
        bevelwidth = self.bevelwidth
        
        #Sets the Bevel Width To The Orig Bevel Width
        #bevelwidth = bpy.context.object.modifiers["Bevel"].width

        #apply the scale to keep me sane
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        
        #remove modifiers 
        bpy.ops.object.modifier_remove(modifier="Bevel")
        bpy.ops.object.modifier_remove(modifier="Solidify")
        #so that the csharp doesnt mesh up the object
        
        #converts to mesh because it makes sense
        bpy.ops.object.convert(target='MESH')

        #Start In Edit Mode
        bpy.ops.object.mode_set(mode='EDIT')
       
        #Unhide all The Geo!
        bpy.ops.mesh.reveal()
        
        #Clear SSharps Then Redo It
        #bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        #bpy.ops.mesh.select_all(action='DESELECT')
        #bpy.ops.mesh.select_all(action='TOGGLE')
        
        #AR suggested using -1s instead of Zeroes
        #bpy.ops.transform.edge_bevelweight(value=-1)
        #bpy.ops.mesh.mark_sharp(clear=True)
        #bpy.ops.transform.edge_crease(value=-1)
        
        #then do the csharp operator stuff.
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.select_all(action='DESELECT')
        
        #Sharpening now using the ssharpangle parameter.
        bpy.ops.mesh.edges_select_sharp(sharpness=ssharpangle)
        
                
        bpy.ops.transform.edge_bevelweight(value=1)
        bpy.ops.transform.edge_crease(value=1)
        bpy.ops.mesh.mark_sharp()
        bpy.ops.object.editmode_toggle()     
        
        #keep the old here for now
        bpy.ops.object.modifier_add(type='BEVEL')
        context.object.modifiers["Bevel"].use_clamp_overlap = False
        context.object.modifiers["Bevel"].show_in_editmode = False
        context.object.modifiers["Bevel"].width = 0.0071
        context.object.modifiers["Bevel"].segments = 3
        context.object.modifiers["Bevel"].profile = 0.70
        context.object.modifiers["Bevel"].limit_method = 'WEIGHT'

        #Sets Bevel To Bevel Width
        context.object.modifiers["Bevel"].width = bevelwidth
        
        context.object.data.use_auto_smooth = True
        
        #now sets angle to Var angle.
        context.object.data.auto_smooth_angle = angle
        
        
        bpy.ops.object.shade_smooth()
        return {'FINISHED'}

class csharpenOperator(bpy.types.Operator): #now Csharp 2.0
    '''Sharpen With Modifiers and Bevelling'''
    bl_description = "Sharpens The Mesh And Adds Bevelling On Sharps"
    bl_idname = "csharpen.objects"
    bl_label = "CSharpen"
    bl_options = {'REGISTER', 'UNDO'} 
    
    items = [(x.identifier, x.name, x.description, x.icon) 
             for x in bpy.types.Modifier.bl_rna.properties['type'].enum_items]

    modtypes = EnumProperty(name="Modifier Types",
                           items=[(id, name, desc, icon, 2**i) for i, (id, name, desc, icon) in enumerate(items)
                                   if id in ['BOOLEAN', 'MIRROR', 'BEVEL', 'SOLIDIFY']],
                           description="Don't apply these",
                           default={'BEVEL', 'MIRROR'},
                           options={'ENUM_FLAG'})

    angle = FloatProperty(name="AutoSmooth Angle",
                          description="Set AutoSmooth angle",
                          default= radians(60.0),
                          min = 0.0,
                          max = radians(180.0),
                          subtype='ANGLE')

    bevelwidth = FloatProperty(name="Bevel Width Amount",
                               description="Set Bevel Width",
                               default=0.0200,
                               min =
                               0.002,
                               max =0.25)
                               
    ssharpangle = FloatProperty(name="SSharpening Angle", description="Set SSharp Angle", default= 30.0, min = 0.0, max = 180.0)

    togglesharpening = BoolProperty(default = True)
    
    apply_all = BoolProperty(default = True)

    original_bevel = FloatProperty()
      
    @classmethod
    def poll(cls, context):
        ob = context.object
        if ob is None:
            return False
        return (ob.type == 'MESH')

        #F6 MENU
    def draw(self, context):
        layout = self.layout
        box = layout.box()
        # DRAW YOUR PROPERTIES IN A BOX
        #box.prop( self, 'ssharpangle', text = "SsharpAngle")
        col = box.column()
        col.prop(self, "modtypes", expand=True)
        box.prop( self, 'angle', text = "SmoothingAngle" )
        box.prop( self, 'ssharpangle', text = "SSharp Angle")
        box.prop( self, 'bevelwidth', text = "BevelWidth")
        box.prop( self, 'apply_all', text = "ApplyAll")
        box.prop( self, 'togglesharpening', text = "ToggleSsharp")

    def execute(self, context):
        scene = context.scene
        ob = context.object  # soapbox call don't use bpy.context as context is passed
        obs = context.selected_objects
        angle = self.angle
        original_bevel = self.original_bevel
        bevelwidth = self.bevelwidth
        ssharpangle = self.ssharpangle
        ssharpangle = ssharpangle * (3.14159265359/180)
        
        #Sets Original Bevel To Initial Value
        #original_bevel = 0.2
       
        """
        obj.modifiers.get("Bevel")
        
        #Just Trying To Make It Work
        bpy.ops.object.modifier_remove(modifier="Bevel")
        bpy.ops.object.modifier_remove(modifier="Solidify")
        #so that the csharp doesnt mesh up the object
        
        #keep the old here for now
        bpy.ops.object.modifier_add(type='BEVEL')
        bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
        bpy.context.object.modifiers["Bevel"].show_in_editmode = False
        bpy.context.object.modifiers["Bevel"].width = bevelwidth
        bpy.context.object.modifiers["Bevel"].segments = 3
        bpy.context.object.modifiers["Bevel"].profile = 0.70
        bpy.context.object.modifiers["Bevel"].limit_method = 'WEIGHT'
        """
        
        mod_dic = {}
        if self.apply_all:
            #remove modifiers no one would want applied in this instance

            #bpy.ops.object.modifier_remove(modifier="Bevel")
            #bpy.ops.object.modifier_remove(modifier="Solidify")
            
            # replace with       
            mods = [m for m in ob.modifiers if m.type in self.modtypes]
            for mod in mods:

                mod_dic[mod.name] = {k:getattr(mod, k) for k in mod.bl_rna.properties.keys()
                                     if k not in ["rna_type"]}
                print(mod_dic)
                ob.modifiers.remove(mod)

            #convert to mesh for sanity
            #bpy.ops.object.convert(target='MESH')            
            #Object.to_mesh(scene, apply_modifiers, settings, calc_tessface=True, calc_undeformed=False)

            mesh_name = ob.data.name
            ob.data.name = 'XXXX'
            # remove the old mesh
            if not ob.data.users:
                bpy.data.meshes.remove(ob.data)               
            mesh = ob.to_mesh(scene, True, 'PREVIEW') # or 'RENDER'
            ob.modifiers.clear()
            mesh.name = mesh_name
            ob.data = mesh

            for name, settings in mod_dic.items():
                m = ob.modifiers.new(name, settings["type"])
                for s, v in settings.items():
                    if s == "type":
                        continue
                    setattr(m, s, v)
                    
            #Attempting to toggle Ssharpening on Csharp
            if self.togglesharpening:
                #Start In Edit Mode
                bpy.ops.object.mode_set(mode='EDIT')
               
                #Unhide all The Geo!
                bpy.ops.mesh.reveal()
                
                #then do the ssharp operator stuff.
                
                bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
                bpy.ops.mesh.select_all(action='DESELECT')
                
                #Sharpening now using the ssharpangle parameter.
                bpy.ops.mesh.edges_select_sharp(sharpness=ssharpangle)
                bpy.ops.transform.edge_bevelweight(value=1)
                bpy.ops.transform.edge_crease(value=1)
                bpy.ops.mesh.mark_sharp()
                bpy.ops.object.editmode_toggle()  
                
                bpy.context.object.data.auto_smooth_angle = angle
            
            else:
                bpy.context.object.data.auto_smooth_angle = angle
            
            try :
                context.object.modifiers["Bevel"]
            except:
                bpy.context.object.modifiers.new("Bevel", "BEVEL")
                #bpy.ops.object.modifier_add(type='BEVEL')
                bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
                bpy.context.object.modifiers["Bevel"].show_in_editmode = False
                bpy.context.object.modifiers["Bevel"].width = bevelwidth
                bpy.context.object.modifiers["Bevel"].segments = 3
                bpy.context.object.modifiers["Bevel"].profile = 0.70
                bpy.context.object.modifiers["Bevel"].limit_method = 'WEIGHT'
                print("Added bevel modifier")
                    
            bpy.context.object.modifiers["Bevel"].width = bevelwidth
            context.object.data.use_auto_smooth = True
            bpy.ops.object.shade_smooth()
                    
        return {'FINISHED'}

#SharpenMesh But Don't Bevel Edges AKA SSharpen (Now SSharp2.0)
class softsharpenOperator(bpy.types.Operator):
    '''Sharpen Without Modifiers'''
    bl_description = "Sharpens The Mesh And Without Bevelling On Sharps"
    bl_idname = "ssharpen.objects"
    bl_label = "softSharpen"
    bl_options = {'REGISTER', 'UNDO'} 

    items = [(x.identifier, x.name, x.description, x.icon) 
             for x in bpy.types.Modifier.bl_rna.properties['type'].enum_items]

    modtypes = EnumProperty(name="Modifier Types",
                           items=[(id, name, desc, icon, 2**i) for i, (id, name, desc, icon) in enumerate(items)
                                   if id in ['BOOLEAN', 'MIRROR', 'BEVEL']],
                           description="Don't apply these",
                           default={'BEVEL', 'MIRROR'},
                           options={'ENUM_FLAG'})

    angle = FloatProperty(name="AutoSmooth Angle",
                          description="Set AutoSmooth angle",
                          default= radians(60.0),
                          min = 0.0,
                          max = radians(180.0),
                          subtype='ANGLE')

    bevelwidth = FloatProperty(name="Bevel Width Amount",
                               description="Set Bevel Width",
                               default=0.0200,
                               min =
                               0.002,
                               max =0.25)

    togglesharpening = BoolProperty(default = True)
    
    apply_all = BoolProperty(default = True)

    original_bevel = FloatProperty()

    ssharpangle = FloatProperty(name="SSharpening Angle", description="Set SSharp Angle", default= 30.0, min = 0.0, max = 180.0)


    # ADD A BOOLEAN PROPERTY TO DISCERN BETWEEN THE TWO ALTERNATE MODES and cstep mode
    alternatemode = BoolProperty(default = True)
    cstepmode = BoolProperty(default = False)
    
    @classmethod
    def poll(cls, context):
        ob = context.object
        if ob is None:
            return False
        return (ob.type == 'MESH')

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        col = box.column()
        col.prop(self, "modtypes", expand=True)
        box.prop( self, 'ssharpangle', text = "SsharpAngle" )
        box.prop( self, 'angle', text = "SmoothingAngle" )
        box.prop( self, 'alternatemode', text = "Don't Recalculate")
        box.prop( self, 'cstepmode', text = "cStep fix")

    #If - Default Calculation / Else - Replacive Calculation
    def execute(self, context):
        
        scene = context.scene
        ob = context.object  # soapbox call don't use bpy.context as context is passed
        obs = context.selected_objects
        original_bevel = self.original_bevel
        bevelwidth = self.bevelwidth
        
        angle = self.angle

        ssharpangle = self.ssharpangle
        ssharpangle = ssharpangle * (3.14159265359/180)
        
        if self.cstepmode:

            mod_dic = {}
            if self.apply_all:
            #remove modifiers no one would want applied in this instance

            #bpy.ops.object.modifier_remove(modifier="Bevel")
            #bpy.ops.object.modifier_remove(modifier="Solidify")
            
            # replace with       
                mods = [m for m in ob.modifiers if m.type in self.modtypes]
                for mod in mods:

                    mod_dic[mod.name] = {k:getattr(mod, k) for k in mod.bl_rna.properties.keys()
                                     if k not in ["rna_type"]}
                    print(mod_dic)
                    ob.modifiers.remove(mod)

            #convert to mesh for sanity
            #bpy.ops.object.convert(target='MESH')            
            #Object.to_mesh(scene, apply_modifiers, settings, calc_tessface=True, calc_undeformed=False)

                mesh_name = ob.data.name
                ob.data.name = 'XXXX'
            # remove the old mesh
                if not ob.data.users:
                    bpy.data.meshes.remove(ob.data)               
                mesh = ob.to_mesh(scene, True, 'PREVIEW') # or 'RENDER'
                ob.modifiers.clear()
                mesh.name = mesh_name
                ob.data = mesh

                for name, settings in mod_dic.items():
                    m = ob.modifiers.new(name, settings["type"])
                    for s, v in settings.items():
                        if s == "type":
                            continue
                        setattr(m, s, v)
            #Start In Edit Mode
            bpy.ops.object.mode_set(mode='EDIT')

            #delete unwanted edges
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
            bpy.ops.mesh.select_all(action='INVERT')
            bpy.ops.mesh.dissolve_edges()
            bpy.ops.mesh.select_all(action='DESELECT')

            #Unhide all The Geo!

            #bpy.ops.mesh.reveal()

            #Now Sharpen It
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
            bpy.ops.mesh.select_all(action='DESELECT')

            #Selects Sharps From A Nothing Selection
            bpy.ops.mesh.edges_select_sharp(sharpness=ssharpangle)

            #And Then Adds Weight / Crease / Sharp        
            bpy.ops.transform.edge_bevelweight(value=1)
            bpy.ops.transform.edge_crease(value=1)
            bpy.ops.mesh.mark_sharp()

            #Comes Out Of Edit Mode
            bpy.ops.object.editmode_toggle()

            bpy.context.object.data.auto_smooth_angle = angle

        elif self.alternatemode:
            #Start In Edit Mode
            bpy.ops.object.mode_set(mode='EDIT')

            #Unhide all The Geo!
            bpy.ops.mesh.reveal()

            #Now Sharpen It
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
            bpy.ops.mesh.select_all(action='DESELECT')

            #Selects Sharps From A Nothing Selection
            bpy.ops.mesh.edges_select_sharp(sharpness=ssharpangle)

            #And Then Adds Weight / Crease / Sharp        
            bpy.ops.transform.edge_bevelweight(value=1)
            bpy.ops.transform.edge_crease(value=1)
            bpy.ops.mesh.mark_sharp()

            #Comes Out Of Edit Mode
            bpy.ops.object.editmode_toggle()
            bpy.context.object.data.auto_smooth_angle = angle
                
        else:
            #Start In Edit Mode
            bpy.ops.object.mode_set(mode='EDIT')

            #Unhide all The Geo!
            bpy.ops.mesh.reveal()
                
            #Clear SSharps Then Redo It
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
                
            #AR suggested using -1s instead of Zeroes
            bpy.ops.transform.edge_bevelweight(value=-1)
            bpy.ops.mesh.mark_sharp(clear=True)
            bpy.ops.transform.edge_crease(value=-1)

            #Now Sharpen It
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
            bpy.ops.mesh.select_all(action='DESELECT')

            #Selects Sharps From A Nothing Selection
            bpy.ops.mesh.edges_select_sharp(sharpness=ssharpangle)

            #And Then Adds Weight / Crease / Sharp        
            bpy.ops.transform.edge_bevelweight(value=1)
            bpy.ops.transform.edge_crease(value=1)
            bpy.ops.mesh.mark_sharp()

            #Comes Out Of Edit Mode
            bpy.ops.object.editmode_toggle()
            bpy.context.object.data.auto_smooth_angle = angle

        #Turns On Smoothing And Then Sorts It Out
            
        bpy.context.object.data.use_auto_smooth = True

        #now sets angle to Var angle.
        #bpy.context.object.data.auto_smooth_angle = angle

        bpy.ops.object.shade_smooth()
                

        return {'FINISHED'}    

"""    
#Re-Sharpen Mesh 
class resharpenOperator(bpy.types.Operator):
    '''Sharpen Without Modifiers'''
    bl_idname = "resharpen.objects"
    bl_label = "reSharpen"
    bl_options = {'REGISTER', 'UNDO'} 
    
    ssharpangle = FloatProperty(name="SSharpening Angle", description="Set SSharp Angle", default= 30.0, min = 0.0, max = 180.0)
    
    angle = FloatProperty(name="AutoSmooth Angle", description="Set AutoSmooth angle", default= 60.0, min = 0.0, max = 180.0)
           
    #Setting Bevel Width Should Be An Option That Toggles
    #bevelwidth = FloatProperty(name="Bevel Width Amount", description="Set Bevel Width", default= 0.0071, min = 0.002, max = .25)
    
    def execute(self, context):
        
        #convert angle
        ob = bpy.context.selected_objects
        angle = self.angle
        ssharpangle = self.ssharpangle
        #bevelwidth = self.bevelwidth
        angle = angle * (3.14159265359/180)
        ssharpangle = ssharpangle * (3.14159265359/180)
        
        #Start In Edit Mode
        bpy.ops.object.mode_set(mode='EDIT')
        
        #Unhide all The Geo!
        bpy.ops.mesh.reveal()
        
        #Clear SSharps Then Redo It
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        
        #AR suggested using -1s instead of Zeroes
        bpy.ops.transform.edge_bevelweight(value=-1)
        bpy.ops.mesh.mark_sharp(clear=True)
        bpy.ops.transform.edge_crease(value=-1)
        
        #Now Sharpen It
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.select_all(action='DESELECT')
       

        #Selects Sharps From A Nothing Selectiozzn
        bpy.ops.mesh.edges_select_sharp(sharpness=ssharpangle)
        #bpy.ops.mesh.edges_select_sharp(sharpness=1.0472) 
        #bpy.ops.mesh.edges_select_sharp(sharpness=0.523599)

        #And Then Adds Weight / Crease / Sharp        
        bpy.ops.transform.edge_bevelweight(value=1)
        bpy.ops.transform.edge_crease(value=1)
        bpy.ops.mesh.mark_sharp()
        
        #Comes Out Of Edit Mode
        bpy.ops.object.editmode_toggle()
        
        #Turns On Smoothing And Then Sorts It Out
        bpy.context.object.data.use_auto_smooth = True
        bpy.context.object.data.auto_smooth_angle = angle
        
        #Should Ssharpen Change Bevel Parameters?
        #bpy.context.object.modifiers["Bevel"].width = bevelwidth
        
        bpy.ops.object.shade_smooth()
        return {'FINISHED'}
"""    

#Solidify and Bevel Edges
class solidOperator(bpy.types.Operator):
    '''Solidify Mod And Bevel The Edges'''
    bl_description = "Sharpens The Mesh And Adds Thickness"
    bl_idname = "solidify.objects"
    bl_label = "EdgeSolidify"
    bl_options = {'REGISTER', 'UNDO'} 
    
    #Declare Some Variables Here
    tthick = FloatProperty(name="ThickeningAmount", description="Set Thickness Amount", default= .1, min = 0.001, max = 4.0)
          
    angle = FloatProperty(name="AutoSmooth Angle", description="Set AutoSmooth angle", default= 60.0, min = 0.0, max = 180.0)
    
    bevelwidth = FloatProperty(name="Bevel Width Amount", description="Set Bevel Width", default= 0.01, min = 0.002, max = .25)
    
    bevelmodiferon = BoolProperty(default = True)

    def draw(self, context):
       
        layout = self.layout

        box = layout.box()
        box.prop( self, 'tthick', text = "thicknes" )
        box.prop( self, 'bevelwidth', text = "bevel width" )
        box.prop( self, 'bevelmodiferon', text = "bevel ON/OFF")

    def execute(self, context):
        #convert angle
        bevelwidth = self.bevelwidth
        tthick = self.tthick
        ob = bpy.context.selected_objects
        angle = self.angle
        angle = angle * (3.14159265359/180)

        #bevelmodiferon = BoolProperty(default = True)
        
        
        #start off removing solidify and bevel to avoid issues later.
        bpy.ops.object.modifier_remove(modifier="Bevel")
        bpy.ops.object.modifier_remove(modifier="Solidify")
        
        #go into edit mode and select nothing then select all
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.reveal()
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
#        bpy.ops.mesh.edges_select_sharp()
        
        #convert to Loop and Mark Sharp + Beveling
        bpy.ops.mesh.region_to_loop()   
        bpy.ops.transform.edge_bevelweight(value=1)
        bpy.ops.mesh.mark_sharp()
        bpy.ops.object.editmode_toggle()

        if self.bevelmodiferon:    
            #add Bevel
            bpy.ops.object.modifier_add(type='BEVEL')
            bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
            bpy.context.object.modifiers["Bevel"].show_in_editmode = False
            bpy.context.object.modifiers["Bevel"].width = bevelwidth
            bpy.context.object.modifiers["Bevel"].segments = 3
            bpy.context.object.modifiers["Bevel"].profile = 0.734346
            bpy.context.object.modifiers["Bevel"].limit_method = 'ANGLE'
            bpy.context.object.modifiers["Bevel"].angle_limit = angle

        
        #add Solidify
        bpy.ops.object.modifier_add(type='SOLIDIFY')
        bpy.ops.object.modifier_move_up(modifier="Solidify")
        bpy.context.object.modifiers["Solidify"].thickness = tthick
        bpy.context.object.modifiers["Solidify"].offset = 0
        bpy.context.object.modifiers["Solidify"].use_even_offset = True
        bpy.context.object.modifiers["Solidify"].material_offset_rim = 1
        bpy.context.object.modifiers["Solidify"].material_offset = 2
        bpy.context.object.modifiers["Solidify"].show_in_editmode = False
       
        #set Smoothing
        bpy.context.object.data.use_auto_smooth = True
        bpy.context.object.data.auto_smooth_angle = angle
        bpy.ops.object.shade_smooth()

        return {'FINISHED'}

#Clean Off Bevel and Sharps In Object Mode (now with options to remove modifiers
class unsharpOperator(bpy.types.Operator):
    '''Clear Off Sharps And Bevels'''
    bl_idname = "clean.objects"
    bl_label = "UnsharpBevel"
    bl_options = {'REGISTER', 'UNDO'} 
    
    removeMods = BoolProperty(default = True)
    
    def draw(self, context):
        layout = self.layout

        box = layout.box()
        # DRAW YOUR PROPERTIES IN A BOX
        box.prop( self, 'removeMods', text = "RemoveModifiers?")
        
    def execute(self, context):
        bpy.ops.object.mode_set(mode='EDIT')
        
        #Unhide all The Geo!
        bpy.ops.mesh.reveal()        
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        
        #AR suggested using -1s instead of Zeroes
        bpy.ops.transform.edge_bevelweight(value=-1)
        bpy.ops.mesh.mark_sharp(clear=True)
        bpy.ops.transform.edge_crease(value=-1)
        
        #Now Get Rid of Modifiers/SetSmooth
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.shade_flat()
        
        if self.removeMods:
            bpy.ops.object.modifier_remove(modifier="Bevel")
            bpy.ops.object.modifier_remove(modifier="Solidify")
            
        else:
            bpy.context.object.modifiers["Bevel"].limit_method = 'ANGLE'
            bpy.context.object.modifiers["Bevel"].angle_limit = 0.785398
            return {'FINISHED'}        
        
        return {'FINISHED'}

#Clean Off Bevel and Sharps In Edit Mode
class unsharpOperatorE(bpy.types.Operator):
    '''Clear Off Sharps And Bevels'''
    bl_idname = "clean1.objects"
    bl_label = "UnsharpBevelE"
    bl_options = {'REGISTER', 'UNDO'} 
        
    def execute(self, context):
        #bpy.ops.object.mode_set(mode='EDIT')
        #bpy.ops.mesh.select_all(action='DESELECT')
        #bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.transform.edge_bevelweight(value=-1)
        bpy.ops.mesh.mark_sharp(clear=True)
        bpy.ops.transform.edge_crease(value=-1)
        #bpy.ops.object.editmode_toggle()
        #bpy.ops.object.shade_flat()
        #bpy.ops.object.modifier_remove(modifier="Bevel")
        #bpy.ops.object.modifier_remove(modifier="Solidify")
        
        return {'FINISHED'}
    
#Bevel and Sharps In Edit Mode to Selection
class sharpandbevelOperatorE(bpy.types.Operator):
    '''Clear Off Sharps And Bevels'''
    bl_idname = "bevelandsharp1.objects"
    bl_label = "UnsharpBevelE"
        
    def execute(self, context):
        #bpy.ops.object.mode_set(mode='EDIT')
        #bpy.ops.mesh.select_all(action='DESELECT')
        #bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.transform.edge_bevelweight(value=1)
        bpy.ops.transform.edge_crease(value=1)
        bpy.ops.mesh.mark_sharp()
        #bpy.ops.object.editmode_toggle()
        #bpy.ops.object.shade_flat()
        #bpy.ops.object.modifier_remove(modifier="Bevel")
        #bpy.ops.object.modifier_remove(modifier="Solidify")
        
        return {'FINISHED'}
 
    

#############################
#Panelling Operators Start Here
#############################

#Panel From An Edge Ring Selection
#Scale Dependant for now.
class entrenchOperatorA(bpy.types.Operator):
    '''Entrench Those Edges!'''
    bl_idname = "entrench.selection"
    bl_label = "Entrench"
    
    def execute(self, context):
        bpy.context.space_data.pivot_point = 'MEDIAN_POINT'
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.bevel(offset=0.0128461, vertex_only=False)
        bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"mirror":False}, TRANSFORM_OT_translate={"value":(0, 0, 0), "constraint_axis":(False, False, False), "constraint_orientation":'GLOBAL', "mirror":False, "proportional":'DISABLED', "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "snap":False, "snap_target":'CLOSEST', "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "texture_space":False, "remove_on_cancel":False, "release_confirm":False})
        bpy.ops.transform.shrink_fatten(value=0.04, use_even_offset=True, mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        bpy.ops.mesh.region_to_loop()
        bpy.ops.mesh.bevel(offset=0.00885385, vertex_only=False)
        bpy.ops.mesh.select_more()
        bpy.ops.mesh.region_to_loop()
        bpy.ops.transform.edge_bevelweight(value=1)
        bpy.ops.mesh.mark_sharp()
        bpy.ops.object.editmode_toggle()
        #its important to specify that its edge mode youre working from. Vert mode is a different game altogether for it. 
        return {'FINISHED'}

#Make A Panel Loop From Face Selection
#Scale Dependant for now.
class panelOperatorA(bpy.types.Operator):
    '''Create A Panel From A Face Selection'''
    bl_idname = "quick.panel"
    bl_label = "Sharpen"
    
    def execute(self, context):
        bpy.context.space_data.pivot_point = 'MEDIAN_POINT'
        bpy.ops.mesh.region_to_loop()
        bpy.ops.mesh.bevel(offset=0.00841237, segments=2, vertex_only=False)
        bpy.ops.mesh.select_less()
        bpy.ops.transform.shrink_fatten(value=0.0211908, use_even_offset=False, mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        bpy.ops.mesh.bevel(offset=0.00683826, vertex_only=False)
        return {'FINISHED'}

#############################
#Array Operators Start Here
#############################

#Array Twist
class arrayOperator(bpy.types.Operator):
    '''Array And Twist 360 Degrees'''
    bl_idname = "array.twist" #must be lowercase always
    bl_label = "ArrayTwist"
    bl_options = {'REGISTER', 'UNDO'} 
    
    arrayCount = IntProperty(name="ArrayCount", description="Amount Of Clones", default=8, min = 1, max = 100)
    
    destructive = BoolProperty(default = False)
    
    #xy = BoolProperty(default = False)

        # ADD A DRAW FUNCTION TO DISPLAY PROPERTIES ON THE F6 MENU
    def draw(self, context):
        layout = self.layout

        box = layout.box()
        # DRAW YOUR PROPERTIES IN A BOX
        box.prop( self, 'arrayCount', text = "ArrayCount" )
        box.prop( self, 'destructive', text = "Destructive/Non")
        #box.prop( self, 'xy', text = "Toggle X/Y")
      
        
    def execute(self, context):
        #Now Has A Custom Count
        arrayCount=self.arrayCount #sets array count
                
        if self.destructive:
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
            bpy.ops.object.modifier_add(type='ARRAY')
            bpy.context.object.modifiers["Array"].count = arrayCount
            bpy.ops.object.modifier_add(type='SIMPLE_DEFORM')
            bpy.context.object.modifiers["SimpleDeform"].deform_method = 'BEND'
            bpy.context.object.modifiers["SimpleDeform"].angle = 6.28319
            bpy.ops.object.convert(target='MESH')
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.remove_doubles()
            bpy.ops.object.editmode_toggle()
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
            bpy.ops.object.location_clear()
            """
            if self.xy:
                bpy.context.object.modifiers["Array"].relative_offset_displace[0] = 0
                bpy.context.object.modifiers["Array"].relative_offset_displace[1] = 1
            else:
                bpy.context.object.modifiers["Array"].relative_offset_displace[0] = 1
                bpy.context.object.modifiers["Array"].relative_offset_displace[1] = 0
                """
            
        else:
            #Now Has A Custom Count
            arrayCount=self.arrayCount #sets array count
            
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
            bpy.ops.object.modifier_add(type='ARRAY')
            bpy.context.object.modifiers["Array"].count = arrayCount
            bpy.ops.object.modifier_add(type='SIMPLE_DEFORM')
            bpy.context.object.modifiers["SimpleDeform"].deform_method = 'BEND'
            bpy.context.object.modifiers["SimpleDeform"].angle = 6.28319     
            
            """if self.xy:
                bpy.context.object.modifiers["Array"].relative_offset_displace[0] = 0
                bpy.context.object.modifiers["Array"].relative_offset_displace[1] = 1
            else:
                bpy.context.object.modifiers["Array"].relative_offset_displace[0] = 1
                bpy.context.object.modifiers["Array"].relative_offset_displace[1] = 0
                """   
        return {'FINISHED'}


###########################
#Circle Stuff Starts Here
###########################

#Creates a Circle With No Extrudes / Allows For Setup
class circleSetupOperator(bpy.types.Operator):
    "Creates a Clean Circle At The Vert"
    bl_idname = "circle.setup"
    bl_label = "SetCircle"
    bl_options = {'REGISTER', 'UNDO'} 
    
    circleSubdivs = IntProperty(name="Circle", description="Amount Of Divisions Per Circle", default=5, min = 2, max = 8)
    
    
    def execute(self, context):     
        #Now Has A Custom Count
        circleSubdivs=self.circleSubdivs #sets the subdivs on the circle.
           
        bpy.ops.mesh.bevel(offset=0.1, segments=circleSubdivs, vertex_only=True)
        bpy.ops.mesh.looptools_circle(custom_radius=False, fit='best', flatten=True, influence=100, lock_x=False, lock_y=False, lock_z=False, radius=1, regular=True)
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        
        
        bpy.ops.mesh.dissolve_mode()
        #sets Individual Scaling Of Newly Created Points.
        bpy.context.space_data.pivot_point = 'INDIVIDUAL_ORIGINS'
        return {'FINISHED'}


#Make A Circle At Each Vert - No Mercy
class circleOperator(bpy.types.Operator):
    '''Creates A Circle At Vert'''
    bl_idname = "area.circle"
    bl_label = "Encircle"
    
    def execute(self, context):
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        bpy.ops.mesh.bevel(offset=0.1, segments=4, vertex_only=True)
        bpy.ops.mesh.looptools_circle(custom_radius=False, fit='best', flatten=True, influence=100, lock_x=False, lock_y=False, lock_z=False, radius=1, regular=True)
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        bpy.ops.mesh.inset(thickness=0.0109504)
        bpy.ops.mesh.inset(thickness=0.0150383)
        bpy.ops.transform.shrink_fatten(value=0.0977827, use_even_offset=False, mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        bpy.ops.mesh.inset(thickness=0.0125973)
        bpy.ops.mesh.dissolve_mode()
        bpy.ops.mesh.dissolve_faces()
        return {'FINISHED'}

#Nth Circle Rings
class cicleRinger(bpy.types.Operator):
    '''Turns Every Nth Selection Into a Circle'''
    bl_idname = "nth.circle"
    bl_label = "Nthcircle"
    
    def execute(self, context):
        #massive hole punching
        #bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        #bpy.ops.mesh.inset(thickness=0.05)
        bpy.context.space_data.pivot_point = 'INDIVIDUAL_ORIGINS'    
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        bpy.ops.mesh.select_nth()
        bpy.ops.mesh.bevel(offset=0.03, segments=4, vertex_only=True)
        bpy.ops.mesh.looptools_circle(custom_radius=False, fit='best', flatten=True, influence=100, lock_x=False, lock_y=False, lock_z=False, radius=1, regular=True)
        #bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        #bpy.ops.mesh.inset(thickness=0.0109504)
        #bpy.ops.mesh.inset(thickness=0.0150383)
        #bpy.ops.transform.shrink_fatten(value=0.0977827, use_even_offset=False, mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        #bpy.ops.mesh.inset(thickness=0.0125973)
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        bpy.ops.mesh.dissolve_mode()
        return {'FINISHED'}

#Individual Circle Rings AKA Circle Selection
class cicleRings(bpy.types.Operator):
    '''Turns Every Vert Into a Circle'''
    bl_idname = "select.circle"
    bl_label = "Selectioncircle"
    
    def execute(self, context):
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        #these 2 lines might be a bad idea
        bpy.ops.mesh.inset(thickness=0.0705154)
        #bpy.ops.mesh.bevel(offset=0.065, segments=2, vertex_only=False) #the segments should offset because of the segments lower down
        #bpy.ops.mesh.select_less()
        #but lets find out!
        bpy.ops.mesh.bevel(offset=0.04, segments=4, vertex_only=True) #segments should be adjustable in an ideal world
        bpy.ops.mesh.looptools_circle(custom_radius=False, fit='best', flatten=True, influence=100, lock_x=False, lock_y=False, lock_z=False, radius=1, regular=True)
        bpy.context.space_data.pivot_point = 'INDIVIDUAL_ORIGINS'
        bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"mirror":False}, TRANSFORM_OT_translate={"value":(0, 0, 0), "constraint_axis":(False, False, False), "constraint_orientation":'GLOBAL', "mirror":False, "proportional":'DISABLED', "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "snap":False, "snap_target":'CLOSEST', "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "texture_space":False, "remove_on_cancel":False, "release_confirm":False})
        bpy.ops.transform.resize(value=(0.730115, 0.730115, 0.730115), constraint_axis=(False, False, False), constraint_orientation='GLOBAL', mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        bpy.ops.transform.shrink_fatten(value=0.0841381, use_even_offset=False, mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"mirror":False}, TRANSFORM_OT_translate={"value":(0, 0, -0.0705891), "constraint_axis":(False, False, True), "constraint_orientation":'GLOBAL', "mirror":False, "proportional":'DISABLED', "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "snap":False, "snap_target":'CLOSEST', "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "texture_space":False, "remove_on_cancel":False, "release_confirm":False})
        bpy.ops.mesh.select_more()
        bpy.ops.mesh.dissolve_faces()
        #ew N-gon I need a way to make this individally solve for the grid fill operation while also keeping them going the same directions and not be rampart
        return {'FINISHED'}

#Single Circle Rings AKA Circle Ring
class cicleRing(bpy.types.Operator):
    '''Turns Every Vert Into a Circle'''
    bl_idname = "circle.ring"
    bl_label = "CircleRing"
    
    def execute(self, context):
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        bpy.ops.mesh.bevel(offset=0.1, segments=4, vertex_only=True)
        bpy.ops.mesh.looptools_circle(custom_radius=False, fit='best', flatten=True, influence=100, lock_x=False, lock_y=False, lock_z=False, radius=1, regular=True)
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        bpy.ops.mesh.inset(thickness=0.0109504)
        bpy.ops.mesh.inset(thickness=0.0150383)
        bpy.ops.transform.shrink_fatten(value=0.0977827, use_even_offset=False, mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        bpy.ops.mesh.inset(thickness=0.0125973)
        bpy.ops.mesh.dissolve_mode()
        #ew N-gon I need a way to make this individally solve for the grid fill operation while also keeping them going the same directions and not be rampart
        return {'FINISHED'}

##############################
#                            #
#     Display components     #
#                            #
##############################

def editInfo():        
    show_text = bpy.context.window_manager.show_text
    show_text.updated_edt_text[:] = []                                      
    label_color = show_text.label_color
    value_color = show_text.value_color
    CR = "Carriage return"         
    
    ob = bpy.context.object
    me = ob.data
    bm = bmesh.from_edit_mesh(me)
    
    quads = tris = ngons = 0
    ngons_to_tris = 0             
    
    for f in bm.faces:                
        v = len(f.verts)
        if v == 3: # tris
            tris += 1
            if show_text.display_color_enabled:
                f.material_index = 2
        elif v == 4: # quads
            quads += 1 
            if show_text.display_color_enabled:
                f.material_index = 0 
        elif v > 4: # ngons
            ngons += 1            
            V = len(f.verts) - 2 # nomber of tris in ngons
            ngons_to_tris += V # get total tris of total ngons 
            if show_text.display_color_enabled:  
                f.material_index = 1 
                
    bmesh.update_edit_mesh(me)
    
    if show_text.faces_count_edt:        
        show_text.updated_edt_text.extend([CR, ("Faces: ", label_color), (str(len(bm.faces)), value_color)]) 
    if show_text.tris_count_edt:
        show_text.updated_edt_text.extend([CR, ("Tris: ", label_color), (str(tris + quads*2 + ngons_to_tris), value_color)]) 
    if show_text.ngons_count_edt:
        show_text.updated_edt_text.extend([CR, ("Ngons: ", label_color), (str(ngons), value_color)]) 
    if show_text.verts_count_edt:
        show_text.updated_edt_text.extend([CR, ("Vertex: ", label_color), (str(len(bm.verts)), value_color)])
    
        

def updateTextHandlers(scene):
    show_text = bpy.context.window_manager.show_text
    mode = bpy.context.object.mode
    
    if mode == 'EDIT':
        if show_text.update_mode_enabled:
            if show_text.update_toggle_mode != 'EDIT':
                show_text.update_toggle_mode = bpy.context.object.mode  
                editInfo()          
        if show_text.edt_use:
            ob = scene.objects.active
            if ob.data.is_updated_data:                                      
                editInfo()
    elif mode == 'OBJECT':
        if show_text.update_toggle_mode != 'OBJECT':
            show_text.update_toggle_mode = bpy.context.object.mode   
            objInfo()       
        if show_text.obj_use:
            if bpy.context.selected_objects not in show_text.obj_pre:
                show_text.obj_pre[:] = []            
                show_text.obj_pre.append(bpy.context.selected_objects)
                objInfo() 
                
                
        #######################################
        ####    DISPLAY COLOR FONCTIONS    ####
        #######################################
        
        
def setupScene():
    bpy.ops.object.mode_set(mode='OBJECT')
    for slots in bpy.context.active_object.material_slots:
        bpy.ops.object.material_slot_remove() # remove all materials slots   
    bpy.ops.object.mode_set(mode='EDIT')

   
def createMat():
    show_text = bpy.context.window_manager.show_text
    if bpy.context.space_data.use_matcap:
        show_text.matcap_enabled = True
        bpy.context.space_data.use_matcap = False
                            
    # create new material        
    mat_A = bpy.data.materials.new("Quads")
    mat_A.diffuse_color = (0.865, 0.865, 0.865)

    mat_B = bpy.data.materials.new("Ngons")
    mat_B.diffuse_color = (1, 0, 0)
    
    mat_C = bpy.data.materials.new("Tris")
    mat_C.diffuse_color = (1, 1, 0)
    
    ob = bpy.context.active_object
    me = ob.data
    mat_list = [mat_A, mat_B, mat_C]
    for mat in mat_list:
        me.materials.append(mat) # assign materials

       
def restoreMat():
    setupScene()
    mat_A = bpy.data.materials['Quads']

    mat_B = bpy.data.materials['Ngons']
    
    mat_C = bpy.data.materials['Tris']
    
    ob = bpy.context.active_object
    me = ob.data
    mat_list = [mat_A, mat_B, mat_C]
    for mat in mat_list:
        me.materials.append(mat)

def selectModePre():
    show_text = bpy.context.window_manager.show_text
    if tuple(bpy.context.tool_settings.mesh_select_mode) == (True, False, False):
        show_text.select_mode = "VERT"
    elif tuple(bpy.context.tool_settings.mesh_select_mode) == (False, True, False):
        show_text.select_mode = "EDGE"
    elif tuple(bpy.context.tool_settings.mesh_select_mode) == (False, False, True):
        show_text.select_mode = "FACE"

#Add MAterial
class addMaterials(bpy.types.Operator):
    bl_idname = "object.add_materials"
    bl_label = "Add materials"
    
    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type == 'MESH'
    
    def execute(sefl, context):        
        show_text = bpy.context.window_manager.show_text
        show_text.active_shade = bpy.context.space_data.viewport_shade
        bpy.context.space_data.viewport_shade = 'SOLID'         
        if not bpy.data.materials:
            if context.object.mode == 'OBJECT':
                bpy.ops.object.mode_set(mode='EDIT')
                createMat() 
            elif context.object.mode == 'EDIT':
                createMat()
            
        else:
            if bpy.context.object.active_material:
                for mat_slots in bpy.context.active_object.material_slots:
                    show_text.save_mat.append(mat_slots.name)
                        
            ref_list = ['Quads', 'Ngons', 'Tris']            
            mat_list = []
            for mat in bpy.data.materials:
                mat_list.append(mat.name)
            for ref in ref_list:
                if ref in mat_list:
                    if bpy.context.space_data.use_matcap:
                        show_text.matcap_enabled = True
                        bpy.context.space_data.use_matcap = False 
                    else:
                        show_text.matcap_enabled = False                    
                    restoreMat()
                    
                else:
                    setupScene() 
                    createMat()
        show_text.display_color_enabled = True 
        if not updateTextHandlers in bpy.app.handlers.scene_update_post:
            bpy.app.handlers.scene_update_post.append(updateTextHandlers)
        show_text.update_mode_enabled = True
        editInfo()    
        return {'FINISHED'}


#Remove Material
class removeMaterials(bpy.types.Operator):
    bl_idname = "object.remove_materials"
    bl_label = "Remove materials"
    
    @classmethod
    def poll(cls, context):
        return context.active_object.type == 'MESH'
    
    def execute(self, context):
        show_text = bpy.context.window_manager.show_text     
        if bpy.context.object.mode == 'OBJECT':
            for slots in bpy.context.active_object.material_slots:
                bpy.ops.object.material_slot_remove()
            if len(show_text.save_mat) > 0:
                ob = bpy.context.active_object
                me = ob.data
                
                for mat in show_text.save_mat:
                    mat_list = bpy.data.materials[mat]
                    me.materials.append(mat_list)

                show_text.save_mat[:] = [] # clean the list
            if show_text.matcap_enabled:
                bpy.context.space_data.use_matcap = True 
        elif bpy.context.object.mode == 'EDIT': 
            show_text.update_mode_enabled = False                      
            bpy.ops.object.mode_set(mode='OBJECT')
            for slots in bpy.context.active_object.material_slots:
                bpy.ops.object.material_slot_remove()
            if len(show_text.save_mat) != 0:
                ob = bpy.context.active_object
                me = ob.data
                
                for mat in show_text.save_mat:
                    mat_list = bpy.data.materials[mat]
                    me.materials.append(mat_list)

                show_text.save_mat[:] = [] # clean the list
            if show_text.matcap_enabled:
                bpy.context.space_data.use_matcap = True   
            bpy.ops.object.mode_set(mode='EDIT')
            show_text.update_mode_enabled = True
        
        bpy.context.space_data.viewport_shade = show_text.active_shade
        show_text.display_color_enabled = False   
        if show_text.vp_info_enabled == False: 
            bpy.app.handlers.scene_update_post.remove(updateTextHandlers)            
        return {'FINISHED'}

#Triangles Selection
class DATA_OP_triangles_select(bpy.types.Operator):
    """Select triangles"""
    bl_idname = "data.triangles_select"
    bl_label = "Select triangles"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type == 'MESH'

    def execute(self, context):
        show_text = bpy.context.window_manager.show_text 
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT') 
        selectModePre()       
        context.tool_settings.mesh_select_mode=(False, False, True)
        bpy.ops.mesh.select_face_by_sides(number=3, type='EQUAL')
        bpy.ops.mesh.select_mode(type=show_text.select_mode)
        return {'FINISHED'} 
    
        
#Ngons Selection
class DATA_OP_ngons_select(bpy.types.Operator):
    """Select ngons"""
    bl_idname = "data.ngons_select"
    bl_label = "Select ngons"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type == 'MESH'

    def execute(self, context):
        show_text = bpy.context.window_manager.show_text 
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT') 
        selectModePre()       
        context.tool_settings.mesh_select_mode=(False, False, True)
        bpy.ops.mesh.select_face_by_sides(number=4, type='GREATER')
        bpy.ops.mesh.select_mode(type=show_text.select_mode)        
        return {'FINISHED'}  


#
# AR -  modification starts here
#   should not couse any problems now. will add 1 hotkey and remove all(even multiple ones) after also the changed ones
#   but remamber that after removing addon You still see hotkeys (but it is not there) it will be gone when presed on it its just how blender updates stuff
#   
#
#added to store km

addon_keymaps = []


def register():

    global custom_icons
    custom_icons = bpy.utils.previews.new()
    #script_path = bpy.context.space_data.text.filepath
    
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")

    #Custom Icons Here
    
    custom_icons.load("custom_icon", os.path.join(icons_dir, "icon.png"), 'IMAGE')
    
    custom_icons.load("HardOps", os.path.join(icons_dir, "HIconHO.jpg"), 'IMAGE')
    custom_icons.load("AdjustBevel", os.path.join(icons_dir, "HIconAdjustBevel.jpg"), 'IMAGE')
    custom_icons.load("Applyall", os.path.join(icons_dir, "HIconApplyall.jpg"), 'IMAGE')
    custom_icons.load("SCleanRecenter", os.path.join(icons_dir, "HIconScrecenter.jpg"), 'IMAGE')
    custom_icons.load("ATwist360", os.path.join(icons_dir, "HIconATwist360.jpg"), 'IMAGE')
    custom_icons.load("Bboxoff", os.path.join(icons_dir, "HIconBboxoff.jpg"), 'IMAGE')
    custom_icons.load("PUnwrap", os.path.join(icons_dir, "HIconPUnwrap.jpg"), 'IMAGE')
    
    custom_icons.load("ReBool", os.path.join(icons_dir, "HIconReBool.jpg"), 'IMAGE')

    custom_icons.load("CircleSetup", os.path.join(icons_dir, "HIconCirclesetup.jpg"), 'IMAGE')
    custom_icons.load("NthCircle", os.path.join(icons_dir, "HIconNthcircle.jpg"), 'IMAGE')
    custom_icons.load("FaceGrate", os.path.join(icons_dir, "HIconFacegrate.jpg"), 'IMAGE')
    custom_icons.load("FaceKnurl", os.path.join(icons_dir, "HIconFaceknurl.jpg"), 'IMAGE')
    custom_icons.load("EdgeRingPanel", os.path.join(icons_dir, "HIconEdgeringPanel.jpg"), 'IMAGE')
    custom_icons.load("FacePanel", os.path.join(icons_dir, "HIconFacepanel.jpg"), 'IMAGE')

    custom_icons.load("CleansharpsE", os.path.join(icons_dir, "HIconCleansharps.jpg"), 'IMAGE')
    custom_icons.load("MakeSharpE", os.path.join(icons_dir, "HIconMakesharp.jpg"), 'IMAGE')


    custom_icons.load("CST", os.path.join(icons_dir, "HIconCST.jpg"), 'IMAGE')
    custom_icons.load("Frame", os.path.join(icons_dir, "HIconFrame.jpg"), 'IMAGE')
    custom_icons.load("Diagonal", os.path.join(icons_dir, "HIcondiagonal.jpg"), 'IMAGE')
    
    custom_icons.load("Gui", os.path.join(icons_dir, "GUI.jpg"), 'IMAGE')   
    custom_icons.load("NGui", os.path.join(icons_dir, "HIconNGui.jpg"), 'IMAGE')
    custom_icons.load("QGui", os.path.join(icons_dir, "HIconQgui.jpg"), 'IMAGE')
    custom_icons.load("RGui", os.path.join(icons_dir, "HIconRGui.jpg"), 'IMAGE')    

    custom_icons.load("RenderSet1", os.path.join(icons_dir, "HIconRenderset1.jpg"), 'IMAGE')
    custom_icons.load("SetFrame", os.path.join(icons_dir, "HIconFrameset.jpg"), 'IMAGE')

    custom_icons.load("CSharpen", os.path.join(icons_dir, "HIconCsharpen.jpg"), 'IMAGE')
    custom_icons.load("Ssharpen", os.path.join(icons_dir, "HIconSsharpen.jpg"), 'IMAGE')
    custom_icons.load("Tsharpen", os.path.join(icons_dir, "HIconTSharpen.jpg"), 'IMAGE')
    custom_icons.load("ClearSharps", os.path.join(icons_dir, "HIconClearSharps.jpg"), 'IMAGE')

    custom_icons.load("Xslap", os.path.join(icons_dir, "HIconXslap.jpg"), 'IMAGE')
    custom_icons.load("Yslap", os.path.join(icons_dir, "HIconYslap.jpg"), 'IMAGE')
        
    #bpy.utils.register_class(customMenu)
    
    bpy.utils.register_module(__name__)
   
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu', 'Q', 'PRESS')
    kmi.properties.name = "customMenu"
    addon_keymaps.append(km)

def unregister():
    
    global custom_icons
    bpy.utils.previews.remove(custom_icons)

    #bpy.utils.unregister_class(customMenu)

    bpy.utils.register_module(__name__)
    
    wm = bpy.context.window_manager
    
    for km in addon_keymaps:
        wm.keyconfigs.addon.keymaps.remove(km)
    del addon_keymaps[:]

    
if __name__ == "__main__":
    register()

    # The menu can also be called from scripts
    bpy.ops.wm.call_menu(name=customMenu.bl_idname)
    
