import os
import bpy
import bpy.utils.previews

icon_collections = {}
icons_loaded = False

def load_icons():
    global icon_collections
    global icons_loaded

    if icons_loaded: return icon_collections["main"]

    custom_icons = bpy.utils.previews.new()

    icons_dir = os.path.join(os.path.dirname(__file__), "icons")

    custom_icons.load("custom_icon", os.path.join(icons_dir, "icon.png"), 'IMAGE')

    custom_icons.load("HardOps", os.path.join(icons_dir, "HIconHO.jpg"), 'IMAGE')
    custom_icons.load("AdjustBevel", os.path.join(icons_dir, "HIconAdjustBevel.jpg"), 'IMAGE')
    custom_icons.load("Applyall", os.path.join(icons_dir, "HIconApplyall.jpg"), 'IMAGE')
    custom_icons.load("SCleanRecenter", os.path.join(icons_dir, "HIconScrecenter.jpg"), 'IMAGE')
    custom_icons.load("ATwist360", os.path.join(icons_dir, "HIconATwist360.jpg"), 'IMAGE')
    custom_icons.load("Bboxoff", os.path.join(icons_dir, "HIconBboxoff.jpg"), 'IMAGE')
    custom_icons.load("PUnwrap", os.path.join(icons_dir, "HIconPUnwrap.jpg"), 'IMAGE')
    
    custom_icons.load("ReBool", os.path.join(icons_dir, "HIconReBool.jpg"), 'IMAGE')

    custom_icons.load("CircleSetup", os.path.join(icons_dir, "HIconCirclesetup.jpg"), 'IMAGE')
    custom_icons.load("NthCircle", os.path.join(icons_dir, "HIconNthcircle.jpg"), 'IMAGE')
    custom_icons.load("FaceGrate", os.path.join(icons_dir, "HIconFacegrate.jpg"), 'IMAGE')
    custom_icons.load("FaceKnurl", os.path.join(icons_dir, "HIconFaceknurl.jpg"), 'IMAGE')
    custom_icons.load("EdgeRingPanel", os.path.join(icons_dir, "HIconEdgeringPanel.jpg"), 'IMAGE')
    custom_icons.load("FacePanel", os.path.join(icons_dir, "HIconFacepanel.jpg"), 'IMAGE')

    custom_icons.load("CleansharpsE", os.path.join(icons_dir, "HIconCleansharps.jpg"), 'IMAGE')
    custom_icons.load("MakeSharpE", os.path.join(icons_dir, "HIconMakesharp.jpg"), 'IMAGE')


    custom_icons.load("CST", os.path.join(icons_dir, "HIconCST.jpg"), 'IMAGE')
    custom_icons.load("Frame", os.path.join(icons_dir, "HIconFrame.jpg"), 'IMAGE')
    custom_icons.load("Diagonal", os.path.join(icons_dir, "HIcondiagonal.jpg"), 'IMAGE')

    custom_icons.load("Gui", os.path.join(icons_dir, "GUI.jpg"), 'IMAGE')   
    custom_icons.load("NGui", os.path.join(icons_dir, "HIconNGui.jpg"), 'IMAGE')
    custom_icons.load("QGui", os.path.join(icons_dir, "HIconQgui.jpg"), 'IMAGE')
    custom_icons.load("RGui", os.path.join(icons_dir, "HIconRGui.jpg"), 'IMAGE')    

    custom_icons.load("RenderSet1", os.path.join(icons_dir, "HIconRenderset1.jpg"), 'IMAGE')
    custom_icons.load("SetFrame", os.path.join(icons_dir, "HIconFrameset.jpg"), 'IMAGE')

    custom_icons.load("CSharpen", os.path.join(icons_dir, "HIconCsharpen.jpg"), 'IMAGE')
    custom_icons.load("Ssharpen", os.path.join(icons_dir, "HIconSsharpen.jpg"), 'IMAGE')
    custom_icons.load("Tsharpen", os.path.join(icons_dir, "HIconTSharpen.jpg"), 'IMAGE')
    custom_icons.load("ClearSharps", os.path.join(icons_dir, "HIconClearSharps.jpg"), 'IMAGE')

    custom_icons.load("Xslap", os.path.join(icons_dir, "HIconXslap.jpg"), 'IMAGE')
    custom_icons.load("Yslap", os.path.join(icons_dir, "HIconYslap.jpg"), 'IMAGE')
    
    icon_collections["main"] = custom_icons
    icons_loaded = True

    return icon_collections["main"]

def clear_icons():
	global icons_loaded
	for icon in icon_collections.values():
		bpy.utils.previews.remove(icon)
	icon_collections.clear()
	icons_loaded = False