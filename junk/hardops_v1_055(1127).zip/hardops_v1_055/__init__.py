# -*- coding: utf-8 -*-

'''
Copyright (C) 2015 YOUR NAME
YOUR@MAIL.com

Created by YOUR NAME

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

bl_info = {
    "name": "HardOps V1",
    "description": "",
    "author": "MX, IS, RF, JM, AR, BF. SE, PL, Wazou, Pistiwique and you",
    "version": (0, 0, 5, 5),
    "blender": (2, 76, 0),
    "location": "View3D",
    "warning": "Hard Ops - Hard Surface Tactical Operations",
    "wiki_url": "",
    "category": "Object" }
    
    
import bpy 
from bpy.types import Menu
import os
from . mesh_check import (meshCheckCollectionGroup,
                          updateDisplayColor)
from . icons.icons import clear_icons
from . import developer_utils
from . add_object_to_selection import (create_object_to_selection,
                                     add_primitive)

modules = developer_utils.setup_addon_modules(__path__, __name__, "bpy" in locals())
import traceback



######Preferences######
class HardOpsMenuPrefs(bpy.types.AddonPreferences):
    """HardOps allow you to make Hardsurfaces modeling"""
    bl_idname = __name__

    bpy.types.Scene.Enable_Tab_01 = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.Enable_Tab_02 = bpy.props.BoolProperty(default=False)

    def draw(self, context):
        layout = self.layout
        
        layout.prop(context.scene, "Enable_Tab_01", text="info", icon="INFO")   
        if context.scene.Enable_Tab_01:
            row = layout.row()
            layout.label(text="HardOps allow you to make Hardsurfaces modeling")

        layout.prop(context.scene, "Enable_Tab_02", text="URL's", icon="URL")   
        if context.scene.Enable_Tab_02:
            row = layout.row()
            row.operator("wm.url_open", text="Youtube").url = "https://www.youtube.com/user/masterxeon1001/featured"
            row.operator("wm.url_open", text="Gumroad").url = "https://gumroad.com/l/hardops/"


# register
################################## 


addon_keymaps = []

def register():
    
    try: bpy.utils.register_module(__name__)
    except: traceback.print_exc()    
    print("Registered {} with {} modules".format(bl_info["name"], len(modules)))    
    
    bpy.types.WindowManager.choose_primitive = bpy.props.EnumProperty(
            items=(('cube', 'Cube', '', 'MESH_CUBE', 1),
               #('plane', 'Plane', '', 'MESH_PLANE', 2),
               #('cone', 'Cone', '', 'MESH_CONE', 3),
               #('cylinder_8', 'Cylinder 8', '', 'MESH_CYLINDER', 4),
               #('cylinder_16', "Cylinder 16", '', 'MESH_CYLINDER', 5),
               ('cylinder_24', "Cylinder 24", '', 'MESH_CYLINDER', 6),
               #('cylinder_32', "Cylinder 32", '', 'MESH_CYLINDER', 7),
               #('cylinder_64', "Cylinder 64", '', 'MESH_CYLINDER', 8),
               #('sphere_8', "Sphere 8", '', 'MESH_UVSPHERE', 9),
               #('sphere_16', "Sphere 16", '', 'MESH_UVSPHERE', 10),
               #('sphere_24', "Sphere 24", '', 'MESH_UVSPHERE', 11),
               ('sphere_32', "Sphere 32", '', 'MESH_UVSPHERE', 12)),
               default='cube',
               update=create_object_to_selection)        
    
    #kEYMAP#
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'Q', 'PRESS', ctrl = False, shift = True, alt=False)
    kmi.properties.name = "HardOps_Pie_Menu"
    
    
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu', 'Q', 'PRESS', ctrl = False, shift = False, alt=False)
    kmi.properties.name = "HardHops_CustomMenu"
    
    addon_keymaps.append(km)
    
    bpy.types.WindowManager.m_check = bpy.props.PointerProperty(
        type=meshCheckCollectionGroup)
    

def unregister():
     
    try: bpy.utils.unregister_module(__name__)
    except: traceback.print_exc()
    
    print("Unregistered {}".format(bl_info["name"]))
    
    m_check = bpy.context.window_manager.m_check    

    if m_check.meshcheck_enabled:
        if updateDisplayColor in bpy.app.handlers:
            bpy.app.handlers.scene_update_post.remove(updateDisplayColor)
        
    del bpy.types.WindowManager.m_check
    
        
    clear_icons()   
    #kEYMAP#
    wm = bpy.context.window_manager
    for km in addon_keymaps:
        wm.keyconfigs.addon.keymaps.remove(km)
    del addon_keymaps[:]    