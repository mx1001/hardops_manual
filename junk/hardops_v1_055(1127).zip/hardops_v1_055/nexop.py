# -*- coding: utf-8 -*-

import bpy
from bpy.props import *
from math import pi, radians

#############################
#MODAL Thickness 
#############################

class tthickOperator(bpy.types.Operator):
    """Sets Thickness With A Modal"""
    bl_idname = "tthick.modal_operator"
    bl_label = "Thickness Modal Operator"
    bl_options = {'REGISTER', 'UNDO'}
    
    first_mouse_x = IntProperty()
    first_value = FloatProperty()
    angle = FloatProperty()

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            delta = self.first_mouse_x - event.mouse_x
            try :
                context.object.modifiers["Solidify"]
            except:
                #bpy.context.object.modifiers.new("Solidify", "SOLIDIFY")
                bpy.context.object.modifiers["Solidify"].use_quality_normals = True
                bpy.context.object.modifiers["Solidify"].use_even_offset = True
                bpy.context.object.modifiers["Solidify"].material_offset_rim = 1
                bpy.context.object.modifiers["Solidify"].thickness = 0.2042
                print("Added solidify modifier")
                
            try:
                ccontext.object.modifiers["Solidify"].thickness = self.first_value + delta * 0.0008
            #context.object.location.x = self.first_value + delta * 0.01        
            except: 
                print("could not find first solidify modifier! adding...")
                #bpy.context.object.modifiers.new("Solidify", "SOLIDIFY")
                bpy.context.object.modifiers["Solidify"].use_quality_normals = True
                bpy.context.object.modifiers["Solidify"].use_even_offset = True
                bpy.context.object.modifiers["Solidify"].material_offset_rim = 1
                bpy.context.object.modifiers["Solidify"].thickness = 0.2042
                print("Added solidify modifier")

                print("Added solidify modifier")
            

        elif event.type == 'LEFTMOUSE':
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            #context.object.location.x = self.first_value
            context.object.modifiers["Solidify"].thickness = self.first_value
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.object:
            self.first_mouse_x = event.mouse_x
            #self.first_value = context.object.location.x
            try:
                self.first_value = context.object.modifiers["Solidify"].thickness
            except:
                    print("could not find second solidify... adding")
                    bpy.context.object.modifiers.new("Solidify", "SOLIDIFY")
                    bpy.context.object.modifiers["Solidify"].use_quality_normals = True
                    bpy.context.object.modifiers["Solidify"].use_even_offset = True
                    bpy.context.object.modifiers["Solidify"].material_offset_rim = 1
                    bpy.context.object.modifiers["Solidify"].thickness = 0.2042
                    print("Added solidify modifier")
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

    def execute(self, context):
        bpy.ops.tthick.modal_operator('INVOKE_DEFAULT')
        return {'CANCELLED'}
"""
class SimpleOperator(bpy.types.Operator):
    ""Sets Viewport AO""
    bl_idname = "viewport.ao_operator"
    bl_label = "ViewPort AO toggle"

    def execute(self, context):
        #main(context)
        bpy.data.screens["Default"].(null) = True
        bpy.data.screens["Default"].(null) = 1.85
        bpy.data.screens["Default"].(null) = 0.2
        bpy.data.screens["Default"].(null) = 0.007
        bpy.data.screens["Default"].(null) = 1
        bpy.data.screens["Default"].(null) = 60
        return {'FINISHED'}
    
"""
#############################
#Multi-CSharp
#############################

class multicsharpOperator(bpy.types.Operator):
    """Multi CSharp"""
    bl_idname = "multi.csharp"
    bl_label = "Multi Object Csharp"

    @classmethod
    def poll(cls, context):
        
        obj_type = context.object.type
        return(obj_type in {'MESH'})
        return context.active_object is not None

    def execute(self, context):
        
        
        sel = bpy.context.selected_objects
        active = bpy.context.scene.objects.active.name
        
        for ob in sel:
                ob = ob.name
                bpy.context.scene.objects.active = bpy.data.objects[ob] 
                
                print(context.selected_objects)
                bpy.ops.csharpen.objects()    
            
        return {'FINISHED'}

#############################