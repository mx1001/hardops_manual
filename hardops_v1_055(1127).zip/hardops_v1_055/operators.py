# -*- coding: utf-8 -*-

import os
import bpy
import bmesh
from bpy.props import *
from math import pi, radians
import bpy.utils.previews

cstepmode = BoolProperty(default = False)


class Make_Link(bpy.types.Operator):
    bl_idname = "make.link"
    bl_label = "Make Link"
    bl_description = ""
    bl_options = {"REGISTER"}
    
    
    
    def execute(self, context):
        bpy.ops.object.make_links_data(type='OBDATA')
        bpy.ops.object.make_links_data(type='MODIFIERS')

        return {"FINISHED"}
        

class Smooth_Sharpen(bpy.types.Operator): #now Csharp 2.0
    '''Sharpen With Modifiers and Bevelling'''
    bl_description = "Sharpens The Mesh For Subdivision Modeling"
    bl_idname = "object.smoothsharp"
    bl_label = "Smooth_Sharpen"
    bl_options = {'REGISTER', 'UNDO'} 
    
    items = [(x.identifier, x.name, x.description, x.icon) 
             for x in bpy.types.Modifier.bl_rna.properties['type'].enum_items]

    modtypes = EnumProperty(name="Modifier Types",
                           items=[(id, name, desc, icon, 2**i) for i, (id, name, desc, icon) in enumerate(items)
                                   if id in ['BOOLEAN', 'MIRROR', 'BEVEL', 'SOLIDIFY']],
                           description="Don't apply these",
                           default={'BEVEL', 'MIRROR'},
                           options={'ENUM_FLAG'})

    angle = FloatProperty(name="AutoSmooth Angle",
                          description="Set AutoSmooth angle",
                          default= radians(60.0),
                          min = 0.0,
                          max = radians(180.0),
                          subtype='ANGLE')

    bevelwidth = FloatProperty(name="Bevel Width Amount",
                               description="Set Bevel Width",
                               default=0.0200,
                               min =
                               0.002,
                               max =0.25)
                               
    ssharpangle = FloatProperty(name="SSharpening Angle", description="Set SSharp Angle", default= 30.0, min = 0.0, max = 180.0)

    togglesharpening = BoolProperty(default = True)
    
    apply_all = BoolProperty(default = True)

    original_bevel = FloatProperty()
      
    @classmethod
    def poll(cls, context):
        ob = context.object
        if ob is None:
            return False
        return (ob.type == 'MESH')

        #F6 MENU
    def draw(self, context):
        layout = self.layout
        box = layout.box()
        # DRAW YOUR PROPERTIES IN A BOX
        #box.prop( self, 'ssharpangle', text = "SsharpAngle")
        col = box.column()
        col.prop(self, "modtypes", expand=True)
        box.prop( self, 'angle', text = "SmoothingAngle" )
        box.prop( self, 'ssharpangle', text = "SSharp Angle")
        box.prop( self, 'bevelwidth', text = "BevelWidth")
        box.prop( self, 'apply_all', text = "ApplyAll")
        box.prop( self, 'togglesharpening', text = "ToggleSsharp")

    def execute(self, context):
        scene = context.scene
        ob = context.object  # soapbox call don't use bpy.context as context is passed
        obs = context.selected_objects
        angle = self.angle
        original_bevel = self.original_bevel
        bevelwidth = self.bevelwidth
        ssharpangle = self.ssharpangle
        ssharpangle = ssharpangle * (3.14159265359/180)
        
        mod_dic = {}
        if self.apply_all:
            
            # replace with       
            mods = [m for m in ob.modifiers if m.type in self.modtypes]
            for mod in mods:

                mod_dic[mod.name] = {k:getattr(mod, k) for k in mod.bl_rna.properties.keys()
                                     if k not in ["rna_type"]}
                print(mod_dic)
                ob.modifiers.remove(mod)

            mesh_name = ob.data.name
            ob.data.name = 'XXXX'
            # remove the old mesh
            if not ob.data.users:
                bpy.data.meshes.remove(ob.data)               
            mesh = ob.to_mesh(scene, True, 'PREVIEW') # or 'RENDER'
            ob.modifiers.clear()
            mesh.name = mesh_name
            ob.data = mesh

            for name, settings in mod_dic.items():
                m = ob.modifiers.new(name, settings["type"])
                for s, v in settings.items():
                    if s == "type":
                        continue
                    setattr(m, s, v)
                    
            #Attempting to toggle Ssharpening on Csharp
            if self.togglesharpening:
                #Start In Edit Mode
                bpy.ops.object.mode_set(mode='EDIT')
               
                #Unhide all The Geo!
                bpy.ops.mesh.reveal()
                
                #then do the ssharp operator stuff.
                
                bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
                bpy.ops.mesh.select_all(action='DESELECT')
                
                #Sharpening now using the ssharpangle parameter.
                bpy.ops.mesh.edges_select_sharp(sharpness=ssharpangle)
                bpy.ops.transform.edge_bevelweight(value=1)
                bpy.ops.transform.edge_crease(value=0)
#                bpy.ops.mesh.mark_sharp()
                bpy.ops.object.editmode_toggle()  
                
                bpy.context.object.data.auto_smooth_angle = angle
            
            else:
                bpy.context.object.data.auto_smooth_angle = angle
            
            try :
                context.object.modifiers["Bevel"]
            except:
                bpy.context.object.modifiers.new("Bevel", "BEVEL")
                #bpy.ops.object.modifier_add(type='BEVEL')
                bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
                bpy.context.object.modifiers["Bevel"].loop_slide = True
                bpy.context.object.modifiers["Bevel"].show_in_editmode = True
                bpy.context.object.modifiers["Bevel"].width = bevelwidth
                bpy.context.object.modifiers["Bevel"].segments = 2
                bpy.context.object.modifiers["Bevel"].profile = 0.5
                bpy.context.object.modifiers["Bevel"].limit_method = 'WEIGHT'
                

                print("Added bevel modifier")
                    
            bpy.context.object.modifiers["Bevel"].width = bevelwidth
            context.object.data.use_auto_smooth = False
            bpy.ops.object.shade_smooth()
                    
        return {'FINISHED'}

#Solid All
class SolidAll(bpy.types.Operator):

    bl_idname = "object.solid_all"
    bl_label = "Solid All"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None
    
    def execute(self, context):
        for obj in bpy.data.objects: 
            if obj.draw_type == 'WIRE': 
                obj.draw_type = 'SOLID'
            elif obj.draw_type == 'SOLID':
                obj.draw_type = 'SOLID' 
                
            else:                       
                obj.draw_type = 'WIRE'
        bpy.context.object.cycles_visibility.camera = True

        return {'FINISHED'}

#### Symetrize X ####
class Symetrize_X_POSITIVE(bpy.types.Operator):  
    bl_idname = "symetrize.xpositive"  
    bl_label = "Symetrize X Positive"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='POSITIVE_X')
        bpy.ops.mesh.select_all(action='TOGGLE')
        return {'FINISHED'} 

class Symetrize_X_NEGATIVE(bpy.types.Operator):  
    bl_idname = "symetrize.xnegative"  
    bl_label = "Symetrize X Negative"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='NEGATIVE_X')
        bpy.ops.mesh.select_all(action='TOGGLE')
        return {'FINISHED'} 

#### Symetrize Y ####
class Symetrize_Y_POSITIVE(bpy.types.Operator):  
    bl_idname = "symetrize.ypositive"  
    bl_label = "Symetrize Y Positive"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='POSITIVE_Y')
        bpy.ops.mesh.select_all(action='TOGGLE')
        return {'FINISHED'} 


class Symetrize_Y_NEGATIVE(bpy.types.Operator):  
    bl_idname = "symetrize.ynegative"  
    bl_label = "Symetrize Y Negative"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='NEGATIVE_Y')
        bpy.ops.mesh.select_all(action='TOGGLE')
        return {'FINISHED'}     

#### Symetrize Z ####
class Symetrize_Z_POSITIVE(bpy.types.Operator):  
    bl_idname = "symetrize.zpositive"  
    bl_label = "Symetrize Z Positive"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='POSITIVE_Z')
        bpy.ops.mesh.select_all(action='TOGGLE')
        return {'FINISHED'} 

class Symetrize_Z_NEGATIVE(bpy.types.Operator):  
    bl_idname = "symetrize.znegative"  
    bl_label = "Symetrize Z Negative"  
    bl_options = {'REGISTER', 'UNDO'}
  
    def execute(self, context):
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.symmetrize(direction='NEGATIVE_Z')
        bpy.ops.mesh.select_all(action='TOGGLE')
        return {'FINISHED'}     

class Show_Overlays(bpy.types.Operator):
	bl_idname = "object.showoverlays"
	bl_label = "Showoverlays"
	bl_description = ""
	bl_options = {'REGISTER', 'UNDO'}
	

	def execute(self, context):
		bpy.context.object.data.show_edge_crease = True
		bpy.context.object.data.show_edge_sharp = True
		bpy.context.object.data.show_edge_bevel_weight = True

		return {"FINISHED"}
	

class Hide_Overlays(bpy.types.Operator):
	bl_idname = "object.hide_overlays"
	bl_label = "Hide Overlays"
	bl_description = ""
	bl_options = {'REGISTER', 'UNDO'}
	
	
	def execute(self, context):
		bpy.context.object.data.show_edge_crease = False
		bpy.context.object.data.show_edge_sharp = False
		bpy.context.object.data.show_edge_bevel_weight = False
		return {"FINISHED"}
	  


		  
#############################
#MODAL Bevel Width
#############################

class bwidthOperator(bpy.types.Operator):
    """Sets Bevel Width With A Modal"""
    bl_idname = "bwidth.modal_operator"
    bl_label = "Simple Modal Operator"
    bl_options = {'REGISTER', 'UNDO'}
    
    first_mouse_x = IntProperty()
    first_value = FloatProperty()
    angle = FloatProperty()

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            delta = self.first_mouse_x - event.mouse_x
            try :
                context.object.modifiers["Bevel"]
            except:
                bpy.context.object.modifiers.new("Bevel", "BEVEL")
                bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
                bpy.context.object.modifiers["Bevel"].show_in_editmode = False
                #bpy.context.object.modifiers["Bevel"].width = bevelwidth
                bpy.context.object.modifiers["Bevel"].segments = 3
                bpy.context.object.modifiers["Bevel"].profile = 0.70
                bpy.context.object.modifiers["Bevel"].show_in_editmode = True
                print("Added bevel modifier")
                
            try:
                context.object.modifiers["Bevel"].width = self.first_value + delta * 0.0008
            #context.object.location.x = self.first_value + delta * 0.01        
            except: 
                print("could not find first bevel modifier! adding...")
                bpy.context.object.modifiers.new("Bevel", "BEVEL")
                bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
                bpy.context.object.modifiers["Bevel"].show_in_editmode = False
                #bpy.context.object.modifiers["Bevel"].width = bevelwidth
                bpy.context.object.modifiers["Bevel"].segments = 3
                bpy.context.object.modifiers["Bevel"].profile = 0.70
                bpy.context.object.modifiers["Bevel"].show_in_editmode = True

                print("Added bevel modifier")
            

        elif event.type == 'LEFTMOUSE':
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            #context.object.location.x = self.first_value
            context.object.modifiers["Bevel"].width = self.first_value
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.object:
            self.first_mouse_x = event.mouse_x
            #self.first_value = context.object.location.x
            try:
                self.first_value = context.object.modifiers["Bevel"].width
            except:
                    print("could not find second bevel... adding")
                    bpy.context.object.modifiers.new("Bevel", "BEVEL")
                    bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
                    bpy.context.object.modifiers["Bevel"].show_in_editmode = False
                    #bpy.context.object.modifiers["Bevel"].width = bevelwidth
                    bpy.context.object.modifiers["Bevel"].segments = 3
                    bpy.context.object.modifiers["Bevel"].profile = 0.70
                    bpy.context.object.modifiers["Bevel"].show_in_editmode = True
                    print("Added bevel modifier")
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

    def execute(self, context):
        bpy.ops.bwidth.modal_operator('INVOKE_DEFAULT')
        return {'CANCELLED'}
    
#############################
#Adrian's CStep
#############################
class cstepOperator(bpy.types.Operator):
    '''AR's Cstep Idea'''
    bl_idname = "cstep.objects"
    bl_label = "CStep"
    bl_options = {'REGISTER', 'UNDO'} 
    


    items = [(x.identifier, x.name, x.description, x.icon) 
             for x in bpy.types.Modifier.bl_rna.properties['type'].enum_items]

    modtypes = EnumProperty(name="Modifier Types",
                           items=[(id, name, desc, icon, 2**i) for i, (id, name, desc, icon) in enumerate(items)
                                   if id in ['BOOLEAN', 'MIRROR']],
                           description="Don't apply these",
                           default={'BOOLEAN', 'MIRROR'},
                           options={'ENUM_FLAG'})

    togglesharpening = BoolProperty(default = True)
    
    apply_all = BoolProperty(default = True)

    original_bevel = FloatProperty()

    ssharpangle = FloatProperty(name="SSharpening Angle", description="Set SSharp Angle", default= 30.0, min = 0.0, max = 180.0)
          
    angle = FloatProperty(name="AutoSmooth Angle", description="Set AutoSmooth angle", default= 60.0, min = 0.0, max = 180.0)
    
    bevelwidth = FloatProperty(name="Bevel Width Amount", description="Set Bevel Width", default= 0.01, min = 0.002, max = 0.25)
     

    @classmethod
    def poll(cls, context):
        ob = context.object
        if ob is None:
            return False
        return (ob.type == 'MESH')

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        col = box.column()
        col.prop(self, "modtypes", expand=True)

    def execute(self, context):
        #convert angle
        bevelwidth = self.bevelwidth
        #ob = bpy.context.selected_objects
        angle = self.angle
        angle = angle * (3.14159265359/180)
        scene = context.scene
        ob = context.object  # soapbox call don't use bpy.context as context is passed
        obs = context.selected_objects
        original_bevel = self.original_bevel
        ssharpangle = self.ssharpangle
        ssharpangle = ssharpangle * (3.14159265359/180)
        global cstepmode

        mod_dic = {}
        if self.apply_all:
            #remove modifiers no one would want applied in this instance

            
            # replace with       
            mods = [m for m in ob.modifiers if m.type in self.modtypes]
            for mod in mods:

                mod_dic[mod.name] = {k:getattr(mod, k) for k in mod.bl_rna.properties.keys()
                                     if k not in ["rna_type"]}
                print(mod_dic)
                ob.modifiers.remove(mod)

            #convert to mesh for sanity

            mesh_name = ob.data.name
            ob.data.name = 'XXXX'
            # remove the old mesh
            if not ob.data.users:
                bpy.data.meshes.remove(ob.data)               
            mesh = ob.to_mesh(scene, True, 'PREVIEW') # or 'RENDER'
            ob.modifiers.clear()
            mesh.name = mesh_name
            ob.data = mesh

            for name, settings in mod_dic.items():
                m = ob.modifiers.new(name, settings["type"])
                for s, v in settings.items():
                    if s == "type":
                        continue
                    setattr(m, s, v)
            

            #bpy.ops.object.convert(target='MESH')
            bpy.ops.object.mode_set(mode='EDIT')

            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')

            # remove creese and weight
            bpy.ops.transform.edge_bevelweight(value=-1)
            bpy.ops.transform.edge_crease(value=-1)

            #convert to Loop and Mark Sharp + Beveling
            bpy.ops.mesh.hide()
            bpy.ops.object.editmode_toggle()
            
            #add Bevel
            bpy.ops.object.modifier_add(type='BEVEL')
            bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
            bpy.context.object.modifiers["Bevel"].show_in_editmode = False
            bpy.context.object.modifiers["Bevel"].width = bevelwidth
            bpy.context.object.modifiers["Bevel"].segments = 3
            bpy.context.object.modifiers["Bevel"].profile = 0.7
            bpy.context.object.modifiers["Bevel"].limit_method = 'WEIGHT'
            bpy.context.object.modifiers["Bevel"].angle_limit = angle
            bpy.context.object.modifiers["Bevel"].show_in_editmode = True
           
            #set Smoothing
            bpy.ops.object.shade_smooth()

            cstepmode = True
        return {'FINISHED'}


#############################
#Reverse Boolean
#############################

class RevBool(bpy.types.Operator):
    """Gives A Reverse Boolean Of Selection"""
    bl_idname = "reverse.boolean"
    bl_label = "ReverseBoolean"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        #main(context)
        context = bpy.context
        scene = context.scene

        obj = context.object.copy()

        bool_mods = [m for m in obj.modifiers if m.type == 'BOOLEAN']

        if len(bool_mods):
            mod = bool_mods[-1]
            if mod.operation == 'DIFFERENCE':
                mod.operation = 'INTERSECT'
                
            elif mod.operation == 'INTERSECT':
                mod.operation = 'DIFFERENCE'

        scene.objects.link(obj)
        bpy.ops.multi.csharp()
        return {'FINISHED'}


#############################
#Pawel Lyczkowski's Hard UVs 
#############################

class RUnwrap(bpy.types.Operator):
        '''Tooltip'''
        bl_description = "Loops through selected objects, marks sharp and seams on sharp edges, and unwraps. Works best with hardsurface models."
        bl_idname = "object.runwrap"
        bl_label = "RUnwrap"
        bl_options = {'REGISTER', 'UNDO'}
 
        rsharpness = bpy.props.FloatProperty(name="Island Size", default=1)
 
        @classmethod
        def poll(cls, context):
                obj_type = obj.type
                # return(obj and obj_type in {'MESH', 'CURVE', 'SURFACE', 'ARMATURE', 'FONT', 'LATTICE'} and context.mode == 'OBJECT')
                return(obj in {'MESH'})
 
        def execute(self, context):
 
                for obj in bpy.context.selected_objects:
 
                        #area = bpy.context.area
                        #old_type = area.type
                       
                        bpy.context.scene.objects.active = obj
 
                        bpy.ops.object.mode_set(mode = 'EDIT')
                        bpy.ops.mesh.select_mode(type="EDGE")
 
                        bpy.ops.mesh.select_all(action = 'DESELECT')
                        bpy.ops.mesh.edges_select_sharp(sharpness=self.rsharpness)
                        bpy.ops.mesh.mark_seam(clear=False)
 
                        bpy.ops.mesh.select_all(action = 'DESELECT')
                        bpy.ops.mesh.select_similar(type='SHARP', threshold=0.01)
                        bpy.ops.mesh.mark_seam(clear=False)
                       
                        bpy.ops.mesh.select_all(action = 'DESELECT')
                        me = obj.data
                        bm = bmesh.from_edit_mesh(me)
                        for e in bm.edges:
                                if not e.smooth:
                                        e.select = True
                        bpy.ops.mesh.mark_seam(clear=False)
                        bmesh.update_edit_mesh(me, False)
 
                        bpy.ops.mesh.select_all(action = 'SELECT')
                        #area.type = 'IMAGE_EDITOR'
                        #bpy.ops.uv.pin(clear=True)
                        #area.type = old_type
                        bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=0.03)
                        bpy.ops.mesh.select_all(action = 'DESELECT')
                        bpy.ops.object.mode_set(mode = 'OBJECT')
 
                return {'FINISHED'}
        
#############################
#Skin Hose Experimental
#############################

#creates a skin mod hose / needs a vert count limit so it doesnt cause crashes
class skinhoseOperator(bpy.types.Operator):
    "Sets EndTime On Timeline Maybe start too someday"
    bl_idname = "skinhose.add"
    bl_label = "VertToSkinHose"
    
    def execute(self, context):
        bpy.ops.object.modifier_add(type='SUBSURF')
        bpy.ops.object.modifier_add(type='SKIN')
        bpy.ops.object.modifier_add(type='SUBSURF')
        bpy.context.object.modifiers["Subsurf"].show_expanded = False
        #bpy.context.object.modifiers["Skin"].show_expanded = False
        bpy.context.object.modifiers["Subsurf.001"].show_expanded = False
        bpy.context.object.modifiers["Subsurf"].show_in_editmode = False
        #bpy.context.object.modifiers["Skin"].show_in_editmode = False
        bpy.context.object.modifiers["Subsurf.001"].show_in_editmode = False
        #I need to add a query here but I'm tired right now. 
        return {'FINISHED'}


#Sets the final frame. Experimental
class endframeOperator(bpy.types.Operator):
    "Sets EndTime On Timeline Maybe start too someday"
    bl_idname = "setframe.end"
    bl_label = "Frame Range"
    bl_options = {'REGISTER', 'UNDO'}
    
    #this should be a property next to the option
       
    firstframe = IntProperty(name="StartFrame", description="SetStartFrame.", default=1, min = 1, max = 20000)
    lastframe = IntProperty(name="EndFrame", description="SetStartFrame.", default=100, min = 1, max = 20000)
    
    
    def execute(self, context):
        lastframe=self.lastframe #needed to get var involved
        firstframe=self.firstframe
        bpy.context.scene.frame_start = firstframe
        bpy.context.scene.frame_end = lastframe
        return {'FINISHED'}
    
    
#Sets Up The Render / As Always
class renset1Operator(bpy.types.Operator):
    "Typical Starter Render Settings"
    bl_idname = "render.setup"
    bl_label = "RenderSetup"
    
    def execute(self, context):
        bpy.context.scene.cycles.sample_clamp_indirect = 2
        bpy.context.scene.cycles.sample_clamp_direct = 2
        bpy.context.scene.cycles.use_square_samples = True
        bpy.context.scene.cycles.preview_samples = 20
        bpy.context.scene.cycles.samples = 20
        bpy.context.scene.cycles.min_bounces = 5
        bpy.context.scene.cycles.glossy_bounces = 16
        bpy.context.scene.cycles.diffuse_bounces = 16
        bpy.context.scene.cycles.blur_glossy = 0.8
        bpy.context.scene.world.cycles.sample_as_light = True
        bpy.context.scene.world.cycles.sample_map_resolution = 512
        return {'FINISHED'}

#############################
#FaceOps Start Here
#############################

#Sets Up Faces For Grating
class facegrateOperator(bpy.types.Operator):
    "Face Grate Setup"
    bl_idname = "fgrate.op"
    bl_label = "FaceGrate" 
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        bpy.context.space_data.pivot_point = 'INDIVIDUAL_ORIGINS'
        bpy.ops.mesh.poke()
        
        #Threshold is a tricky devil
        bpy.ops.mesh.tris_convert_to_quads(face_threshold=0.698132, shape_threshold=1.39626)        
        bpy.ops.mesh.inset(thickness=0.004, use_individual=True)   
        return {'FINISHED'}
    
#Sets Up Faces For Knurling
class faceknurlOperator(bpy.types.Operator):
    "Face Knurl Setup"
    bl_idname = "fknurl.op"
    bl_label = "FaceKnurl" 
    bl_options = {'REGISTER', 'UNDO'}
    
    knurlSubd = IntProperty(name="KnurlSubdivisions", description="Amount Of Divisions", default=0, min = 0, max = 5)
    
    def execute(self, context):
        #allows the knurl to be subdivided
        knurlSubd = self.knurlSubd
        bpy.ops.mesh.subdivide(number_cuts=knurlSubd, smoothness=0)
                
        bpy.ops.mesh.inset(thickness=0.024, use_individual=True)
        bpy.ops.mesh.poke()
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        bpy.ops.mesh.select_less()
        #bpy.ops.transform.shrink_fatten(value=0.2, use_even_offset=True, mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        return {'FINISHED'}


#############################
#Set UI Ops Start Here
#############################

#Return The UI Back To Normal
class reguiOperator(bpy.types.Operator):
    "Turns On Stuff I'd Turn Off"
    bl_idname = "ui.reg"
    bl_label = "regViewport"   
    
    def execute(self, context):
        bpy.context.space_data.show_floor = True
        bpy.context.space_data.show_relationship_lines = True
        bpy.context.space_data.show_only_render = False
        bpy.context.space_data.use_matcap = False
        return {'FINISHED'}

#Attempting To Clean Up UI For A Clean Workspace
class cleanuiOperator(bpy.types.Operator):
    "Turns Off Stuff I'd Turn Off"
    bl_idname = "ui.clean"
    bl_label = "cleanViewport"   
    
    def execute(self, context):
        bpy.context.space_data.show_floor = False
        bpy.context.space_data.show_relationship_lines = False
        bpy.context.space_data.show_only_render = True
        bpy.context.space_data.use_matcap = False
        return {'FINISHED'}
    
#ClassicBigRedMode
class redmodeOperator(bpy.types.Operator):
    "Cleans UI / Preps You With Red"
    bl_idname = "ui.red"
    bl_label = "redViewport"   
    
    def execute(self, context):
        bpy.context.space_data.show_floor = False
        bpy.context.space_data.show_relationship_lines = False
        bpy.context.space_data.show_only_render = True
        bpy.context.space_data.use_matcap = True
        bpy.context.space_data.matcap_icon = '12'
        return {'FINISHED'}
        
#############################
#OrginAndApply Operators Start Here
#############################

class cleanRecenter(bpy.types.Operator):
    "RemovesDoubles/RecenterOrgin/ResetGeometry"
    bl_idname = "clean.recenter"
    bl_label = "CleanRecenter"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        #maybe convert to mesh then recenter
        bpy.ops.object.modifier_remove(modifier="Bevel")
        #bpy.ops.object.modifier_remove(modifier="Solidify")
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.mesh.remove_doubles()
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
        bpy.ops.object.location_clear()
        return {'FINISHED'}

#apply all 2 except Loc at once and be done    
class stompObjectnoloc(bpy.types.Operator):
    "RemovesDoubles/ResetGeometry/NotLoc"
    bl_idname = "stomp2.object"
    bl_label = "stompObjectnoLoc"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
        #bpy.ops.object.location_clear()
        return {'FINISHED'}

#apply all 3 at once and be done
class stompObject(bpy.types.Operator):
    "Applies LocRotScale Finally"
    bl_idname = "stomp.object"
    bl_label = "stompObject"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.location_clear()
        return {'FINISHED'}

#############################
#AutoMirroring-X Operators Start Here
#############################

#half stomps in edit mode
class ehalfStomp(bpy.types.Operator):
    "Symmetrizes Based Off Of Right"
    bl_idname = "ehalfslap.object"
    bl_label = "ehalfslapObject"
    bl_options = {'REGISTER', 'UNDO'} 
    #mirrors on the X
    
    reverse = BoolProperty(default = False)
        
    def execute(self, context):
        #bpy.ops.object.editmode_toggle()
           
             
        if self.reverse:
            #bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='POSITIVE_X')
            bpy.ops.object.editmode_toggle()
        
        else:
            #bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='NEGATIVE_X')
            bpy.ops.object.editmode_toggle()
            
        return {'FINISHED'}

#half stomps in object mode
class halfStomp(bpy.types.Operator):
    "Symmetrizes Based Off Of Right"
    bl_idname = "halfslap.object"
    bl_label = "halfslapObject"
    bl_options = {'REGISTER', 'UNDO'}
    
    reverse = BoolProperty(default = True)
    
    def execute(self, context):
             
        if self.reverse:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='POSITIVE_X')
            bpy.ops.object.editmode_toggle()
        
        else:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='NEGATIVE_X')
            bpy.ops.object.editmode_toggle()
            
        return {'FINISHED'}
    
#half stomps in object mode
class yhalfStomp(bpy.types.Operator):
    "Symmetrizes Based Off Of Right"
    bl_idname = "yhalfslap.object"
    bl_label = "yhalfslapObject"
    bl_options = {'REGISTER', 'UNDO'}
    
    reverse = BoolProperty(default = False)
    
    def execute(self, context):
        
        if self.reverse:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='POSITIVE_Y')
            bpy.ops.object.editmode_toggle()
        
        else:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='NEGATIVE_Y')
            bpy.ops.object.editmode_toggle()
            
        return {'FINISHED'}

# Z
class zhalfStomp(bpy.types.Operator):
    "Symmetrizes Based Off Of Right"
    bl_idname = "zhalfslap.object"
    bl_label = "zhalfslapObject"
    bl_options = {'REGISTER', 'UNDO'}
    
    reverse = BoolProperty(default = False)
    
    def execute(self, context):
        
        if self.reverse:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='POSITIVE_Z')
            bpy.ops.object.editmode_toggle()
        
        else:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.symmetrize(direction='NEGATIVE_Z')
            bpy.ops.object.editmode_toggle()
            
        return {'FINISHED'}
    
    
class reactivateWire(bpy.types.Operator):
    '''Show Wire'''
    bl_idname = "showwire.objects"
    bl_label = "showWire"
    bl_options = {'REGISTER', 'UNDO'} 
    
    noexist = BoolProperty(default = False)
    
    realagain = BoolProperty(default = False)
    
    def draw(self, context):
        layout = self.layout

        box = layout.box()
        # DRAW YOUR PROPERTIES IN A BOX
        box.prop( self, 'noexist', text = "Unrenderable" )
        box.prop( self, 'realagain', text = "Make Real" )
    
    def execute(self, context):
        bpy.context.object.show_wire = True
        bpy.context.object.draw_type = 'WIRE'
        bpy.context.object.show_all_edges = True
        
        if self.noexist:
            bpy.context.object.cycles_visibility.camera = False
            bpy.context.object.cycles_visibility.diffuse = False
            bpy.context.object.cycles_visibility.glossy = False
            bpy.context.object.cycles_visibility.transmission = False
            bpy.context.object.cycles_visibility.scatter = False
            bpy.context.object.cycles_visibility.shadow = False
           
        if self.realagain:
            bpy.context.object.cycles_visibility.camera = True
            bpy.context.object.cycles_visibility.diffuse = True
            bpy.context.object.cycles_visibility.glossy = True
            bpy.context.object.cycles_visibility.transmission = True
            bpy.context.object.cycles_visibility.scatter = True
            bpy.context.object.cycles_visibility.shadow = True
            bpy.context.object.draw_type = 'WIRE'
            bpy.context.object.draw_type = 'TEXTURED'
            bpy.context.object.show_all_edges = False
            bpy.context.object.show_wire = False
        
        else:
            bpy.context.object.cycles_visibility.camera = False    
        
        return {'FINISHED'}

#############################
#Sharpen Operators Start Here
#############################

class xsharpenOperator(bpy.types.Operator):
    '''Sharpen Test'''
    bl_idname = "xsharpen.objects"
    bl_label = "XSharpen"
    bl_options = {'REGISTER', 'UNDO'} 
    
    ssharpangle = FloatProperty(name="SSharpening Angle", description="Set SSharp Angle", default= 30.0, min = 0.0, max = 180.0)
    
    angle = FloatProperty(name="AutoSmooth Angle", description="Set AutoSmooth angle", default= 60.0, min = 0.0, max = 180.0)
    
    bevelwidth = FloatProperty(name="Bevel Width Amount", description="Set Bevel Width", default= 0.0071, min = 0.002, max = .25)
      
    def execute(self, context):
        
        #convert angle
        ob = bpy.context.selected_objects
        angle = self.angle
        ssharpangle = self.ssharpangle
        angle = angle * (3.14159265359/180)
        #ssharpangle = self.ssharpangle
        ssharpangle = ssharpangle * (3.14159265359/180)
        
        #angle = bpy.context.object.data.auto_smooth_angle
        bevelwidth = self.bevelwidth
        
        #Sets the Bevel Width To The Orig Bevel Width
        #bevelwidth = bpy.context.object.modifiers["Bevel"].width

        #apply the scale to keep me sane
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        
        #remove modifiers 
        bpy.ops.object.modifier_remove(modifier="Bevel")
        bpy.ops.object.modifier_remove(modifier="Solidify")
        #so that the csharp doesnt mesh up the object
        
        #converts to mesh because it makes sense
        bpy.ops.object.convert(target='MESH')

        #Start In Edit Mode
        bpy.ops.object.mode_set(mode='EDIT')
       
        #Unhide all The Geo!
        bpy.ops.mesh.reveal()
        
        #Clear SSharps Then Redo It
        #bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        #bpy.ops.mesh.select_all(action='DESELECT')
        #bpy.ops.mesh.select_all(action='TOGGLE')
        
        #AR suggested using -1s instead of Zeroes
        #bpy.ops.transform.edge_bevelweight(value=-1)
        #bpy.ops.mesh.mark_sharp(clear=True)
        #bpy.ops.transform.edge_crease(value=-1)
        
        #then do the csharp operator stuff.
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.select_all(action='DESELECT')
        
        #Sharpening now using the ssharpangle parameter.
        bpy.ops.mesh.edges_select_sharp(sharpness=ssharpangle)
        
                
        bpy.ops.transform.edge_bevelweight(value=1)
        bpy.ops.transform.edge_crease(value=1)
        bpy.ops.mesh.mark_sharp()
        bpy.ops.object.editmode_toggle()     
        
        #keep the old here for now
        bpy.ops.object.modifier_add(type='BEVEL')
        context.object.modifiers["Bevel"].use_clamp_overlap = False
        context.object.modifiers["Bevel"].show_in_editmode = False
        context.object.modifiers["Bevel"].width = 0.0071
        context.object.modifiers["Bevel"].segments = 3
        context.object.modifiers["Bevel"].profile = 0.70
        context.object.modifiers["Bevel"].limit_method = 'WEIGHT'
        context.object.modifiers["Bevel"].show_in_editmode = True
        

        #Sets Bevel To Bevel Width
        context.object.modifiers["Bevel"].width = bevelwidth
        
        context.object.data.use_auto_smooth = True
        
        #now sets angle to Var angle.
        context.object.data.auto_smooth_angle = angle
        
        
        bpy.ops.object.shade_smooth()
        return {'FINISHED'}

class csharpenOperator(bpy.types.Operator): #now Csharp 2.0
    '''Sharpen With Modifiers and Bevelling'''
    bl_description = "Sharpens The Mesh And Adds Bevelling On Sharps"
    bl_idname = "csharpen.objects"
    bl_label = "CSharpen"
    bl_options = {'REGISTER', 'UNDO'} 
    
    items = [(x.identifier, x.name, x.description, x.icon) 
             for x in bpy.types.Modifier.bl_rna.properties['type'].enum_items]

    modtypes = EnumProperty(name="Modifier Types",
                           items=[(id, name, desc, icon, 2**i) for i, (id, name, desc, icon) in enumerate(items)
                                   if id in ['BOOLEAN', 'MIRROR', 'BEVEL', 'SOLIDIFY']],
                           description="Don't apply these",
                           default={'BEVEL', 'MIRROR'},
                           options={'ENUM_FLAG'})

    angle = FloatProperty(name="AutoSmooth Angle",
                          description="Set AutoSmooth angle",
                          default= radians(60.0),
                          min = 0.0,
                          max = radians(180.0),
                          subtype='ANGLE')

    bevelwidth = FloatProperty(name="Bevel Width Amount",
                               description="Set Bevel Width",
                               default=0.0200,
                               min =
                               0.002,
                               max =0.25)
                               
    ssharpangle = FloatProperty(name="SSharpening Angle", description="Set SSharp Angle", default= 30.0, min = 0.0, max = 180.0)

    togglesharpening = BoolProperty(default = True)
    
    apply_all = BoolProperty(default = True)

    original_bevel = FloatProperty()
      
    @classmethod
    def poll(cls, context):
        ob = context.object
        if ob is None:
            return False
        return (ob.type == 'MESH')

        #F6 MENU
    def draw(self, context):
        layout = self.layout
        box = layout.box()
        # DRAW YOUR PROPERTIES IN A BOX
        #box.prop( self, 'ssharpangle', text = "SsharpAngle")
        col = box.column()
        col.prop(self, "modtypes", expand=True)
        box.prop( self, 'angle', text = "SmoothingAngle" )
        box.prop( self, 'ssharpangle', text = "SSharp Angle")
        box.prop( self, 'bevelwidth', text = "BevelWidth")
        box.prop( self, 'apply_all', text = "ApplyAll")
        box.prop( self, 'togglesharpening', text = "ToggleSsharp")

    def execute(self, context):
        scene = context.scene
        ob = context.object  # soapbox call don't use bpy.context as context is passed
        obs = context.selected_objects
        angle = self.angle
        original_bevel = self.original_bevel
        bevelwidth = self.bevelwidth
        ssharpangle = self.ssharpangle
        ssharpangle = ssharpangle * (3.14159265359/180)
        global cstepmode
        #Sets Original Bevel To Initial Value
        #original_bevel = 0.2
       
        """
        obj.modifiers.get("Bevel")
        
        #Just Trying To Make It Work
        bpy.ops.object.modifier_remove(modifier="Bevel")
        bpy.ops.object.modifier_remove(modifier="Solidify")
        #so that the csharp doesnt mesh up the object
        
        #keep the old here for now
        bpy.ops.object.modifier_add(type='BEVEL')
        bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
        bpy.context.object.modifiers["Bevel"].show_in_editmode = False
        bpy.context.object.modifiers["Bevel"].width = bevelwidth
        bpy.context.object.modifiers["Bevel"].segments = 3
        bpy.context.object.modifiers["Bevel"].profile = 0.70
        bpy.context.object.modifiers["Bevel"].limit_method = 'WEIGHT'
        """
        
        mod_dic = {}
        if self.apply_all:
            #remove modifiers no one would want applied in this instance

            #bpy.ops.object.modifier_remove(modifier="Bevel")
            #bpy.ops.object.modifier_remove(modifier="Solidify")
            
            # replace with       
            mods = [m for m in ob.modifiers if m.type in self.modtypes]
            for mod in mods:

                mod_dic[mod.name] = {k:getattr(mod, k) for k in mod.bl_rna.properties.keys()
                                     if k not in ["rna_type"]}
                print(mod_dic)
                ob.modifiers.remove(mod)

            #convert to mesh for sanity
            #bpy.ops.object.convert(target='MESH')            
            #Object.to_mesh(scene, apply_modifiers, settings, calc_tessface=True, calc_undeformed=False)

            mesh_name = ob.data.name
            ob.data.name = 'XXXX'
            # remove the old mesh
            if not ob.data.users:
                bpy.data.meshes.remove(ob.data)               
            mesh = ob.to_mesh(scene, True, 'PREVIEW') # or 'RENDER'
            ob.modifiers.clear()
            mesh.name = mesh_name
            ob.data = mesh

            for name, settings in mod_dic.items():
                m = ob.modifiers.new(name, settings["type"])
                for s, v in settings.items():
                    if s == "type":
                        continue
                    setattr(m, s, v)
                    
            #Attempting to toggle Ssharpening on Csharp
            if self.togglesharpening:
                #Start In Edit Mode
                bpy.ops.object.mode_set(mode='EDIT')
               
                #Unhide all The Geo!
                bpy.ops.mesh.reveal()
                
                #then do the ssharp operator stuff.
                
                bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
                bpy.ops.mesh.select_all(action='DESELECT')
                
                #Sharpening now using the ssharpangle parameter.
                bpy.ops.mesh.edges_select_sharp(sharpness=ssharpangle)
                bpy.ops.transform.edge_bevelweight(value=1)
                bpy.ops.transform.edge_crease(value=1)
                bpy.ops.mesh.mark_sharp()
                bpy.ops.object.editmode_toggle()  
                
                bpy.context.object.data.auto_smooth_angle = angle
            
            else:
                bpy.context.object.data.auto_smooth_angle = angle
            
            try :
                context.object.modifiers["Bevel"]
            except:
                bpy.context.object.modifiers.new("Bevel", "BEVEL")
                #bpy.ops.object.modifier_add(type='BEVEL')
                bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
                bpy.context.object.modifiers["Bevel"].show_in_editmode = False
                bpy.context.object.modifiers["Bevel"].width = bevelwidth
                bpy.context.object.modifiers["Bevel"].segments = 3
                bpy.context.object.modifiers["Bevel"].profile = 0.70
                bpy.context.object.modifiers["Bevel"].limit_method = 'WEIGHT'
                bpy.context.object.modifiers["Bevel"].show_in_editmode = True

                print("Added bevel modifier")
                    
            bpy.context.object.modifiers["Bevel"].width = bevelwidth
            context.object.data.use_auto_smooth = True
            bpy.ops.object.shade_smooth()
            cstepmode = False        
        return {'FINISHED'}

#cstepmode = BoolProperty(default = False)


#SharpenMesh But Don't Bevel Edges AKA SSharpen (Now SSharp2.0)
class softsharpenOperator(bpy.types.Operator):
    '''Sharpen Without Modifiers'''
    bl_description = "Sharpens The Mesh And Without Bevelling On Sharps"
    bl_idname = "ssharpen.objects"
    bl_label = "softSharpen"
    bl_options = {'REGISTER', 'UNDO'} 

    items = [(x.identifier, x.name, x.description, x.icon) 
             for x in bpy.types.Modifier.bl_rna.properties['type'].enum_items]

    modtypes = EnumProperty(name="Modifier Types",
                           items=[(id, name, desc, icon, 2**i) for i, (id, name, desc, icon) in enumerate(items)
                                   if id in ['BOOLEAN', 'MIRROR', 'BEVEL']],
                           description="Don't apply these",
                           default={'BEVEL', 'MIRROR'},
                           options={'ENUM_FLAG'})

    angle = FloatProperty(name="AutoSmooth Angle",
                          description="Set AutoSmooth angle",
                          default= radians(60.0),
                          min = 0.0,
                          max = radians(180.0),
                          subtype='ANGLE')

    bevelwidth = FloatProperty(name="Bevel Width Amount",
                               description="Set Bevel Width",
                               default=0.0200,
                               min =
                               0.002,
                               max =0.25)

    togglesharpening = BoolProperty(default = True)
    
    apply_all = BoolProperty(default = True)

    original_bevel = FloatProperty()

    ssharpangle = FloatProperty(name="SSharpening Angle", description="Set SSharp Angle", default= 30.0, min = 0.0, max = 180.0)


    # ADD A BOOLEAN PROPERTY TO DISCERN BETWEEN THE TWO ALTERNATE MODES and cstep mode
    alternatemode = BoolProperty(default = True)
    cstepmode = BoolProperty(default = False)
    
    @classmethod
    def poll(cls, context):
        ob = context.object
        if ob is None:
            return False
        return (ob.type == 'MESH')

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        col = box.column()
        col.prop(self, "modtypes", expand=True)
        box.prop( self, 'ssharpangle', text = "SsharpAngle" )
        box.prop( self, 'angle', text = "SmoothingAngle" )
        box.prop( self, 'alternatemode', text = "Don't Recalculate")
        box.prop( self, 'cstepmode', text = "cStep fix")

    #If - Default Calculation / Else - Replacive Calculation
    def execute(self, context):
        
        scene = context.scene
        ob = context.object  # soapbox call don't use bpy.context as context is passed
        obs = context.selected_objects
        original_bevel = self.original_bevel
        bevelwidth = self.bevelwidth
        
        angle = self.angle

        ssharpangle = self.ssharpangle
        ssharpangle = ssharpangle * (3.14159265359/180)
        
        if self.cstepmode:

            mod_dic = {}
            if self.apply_all:
            #remove modifiers no one would want applied in this instance

            #bpy.ops.object.modifier_remove(modifier="Bevel")
            #bpy.ops.object.modifier_remove(modifier="Solidify")
            
            # replace with       
                mods = [m for m in ob.modifiers if m.type in self.modtypes]
                for mod in mods:

                    mod_dic[mod.name] = {k:getattr(mod, k) for k in mod.bl_rna.properties.keys()
                                     if k not in ["rna_type"]}
                    print(mod_dic)
                    ob.modifiers.remove(mod)

            #convert to mesh for sanity
            #bpy.ops.object.convert(target='MESH')            
            #Object.to_mesh(scene, apply_modifiers, settings, calc_tessface=True, calc_undeformed=False)

                mesh_name = ob.data.name
                ob.data.name = 'XXXX'
            # remove the old mesh
                if not ob.data.users:
                    bpy.data.meshes.remove(ob.data)               
                mesh = ob.to_mesh(scene, True, 'PREVIEW') # or 'RENDER'
                ob.modifiers.clear()
                mesh.name = mesh_name
                ob.data = mesh

                for name, settings in mod_dic.items():
                    m = ob.modifiers.new(name, settings["type"])
                    for s, v in settings.items():
                        if s == "type":
                            continue
                        setattr(m, s, v)
            #Start In Edit Mode
            bpy.ops.object.mode_set(mode='EDIT')

            #delete unwanted edges
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
            bpy.ops.mesh.select_all(action='INVERT')
            bpy.ops.mesh.dissolve_edges()
            bpy.ops.mesh.select_all(action='DESELECT')

            #Unhide all The Geo!

            #bpy.ops.mesh.reveal()

            #Now Sharpen It
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
            bpy.ops.mesh.select_all(action='DESELECT')

            #Selects Sharps From A Nothing Selection
            bpy.ops.mesh.edges_select_sharp(sharpness=ssharpangle)

            #And Then Adds Weight / Crease / Sharp        
            bpy.ops.transform.edge_bevelweight(value=1)
            bpy.ops.transform.edge_crease(value=1)
            bpy.ops.mesh.mark_sharp()

            #Comes Out Of Edit Mode
            bpy.ops.object.editmode_toggle()

            bpy.context.object.data.auto_smooth_angle = angle

        elif self.alternatemode:
            #Start In Edit Mode
            bpy.ops.object.mode_set(mode='EDIT')

            #Unhide all The Geo!
            bpy.ops.mesh.reveal()

            #Now Sharpen It
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
            bpy.ops.mesh.select_all(action='DESELECT')

            #Selects Sharps From A Nothing Selection
            bpy.ops.mesh.edges_select_sharp(sharpness=ssharpangle)

            #And Then Adds Weight / Crease / Sharp        
            bpy.ops.transform.edge_bevelweight(value=1)
            bpy.ops.transform.edge_crease(value=1)
            bpy.ops.mesh.mark_sharp()

            #Comes Out Of Edit Mode
            bpy.ops.object.editmode_toggle()
            bpy.context.object.data.auto_smooth_angle = angle
                
        else:
            #Start In Edit Mode
            bpy.ops.object.mode_set(mode='EDIT')

            #Unhide all The Geo!
            bpy.ops.mesh.reveal()
                
            #Clear SSharps Then Redo It
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
                
            #AR suggested using -1s instead of Zeroes
            bpy.ops.transform.edge_bevelweight(value=-1)
            bpy.ops.mesh.mark_sharp(clear=True)
            bpy.ops.transform.edge_crease(value=-1)

            #Now Sharpen It
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
            bpy.ops.mesh.select_all(action='DESELECT')

            #Selects Sharps From A Nothing Selection
            bpy.ops.mesh.edges_select_sharp(sharpness=ssharpangle)

            #And Then Adds Weight / Crease / Sharp        
            bpy.ops.transform.edge_bevelweight(value=1)
            bpy.ops.transform.edge_crease(value=1)
            bpy.ops.mesh.mark_sharp()

            #Comes Out Of Edit Mode
            bpy.ops.object.editmode_toggle()
            bpy.context.object.data.auto_smooth_angle = angle

        #Turns On Smoothing And Then Sorts It Out
            
        bpy.context.object.data.use_auto_smooth = True

        #now sets angle to Var angle.
        #bpy.context.object.data.auto_smooth_angle = angle

        bpy.ops.object.shade_smooth()
                

        return {'FINISHED'}    
#Solidify and Bevel Edges
class solidOperator(bpy.types.Operator):
    '''Solidify Mod And Bevel The Edges'''
    bl_description = "Sharpens The Mesh And Adds Thickness"
    bl_idname = "solidify.objects"
    bl_label = "EdgeSolidify"
    bl_options = {'REGISTER', 'UNDO'} 
    
    #Declare Some Variables Here
    tthick = FloatProperty(name="ThickeningAmount", description="Set Thickness Amount", default= .1, min = 0.001, max = 4.0)
          
    angle = FloatProperty(name="AutoSmooth Angle", description="Set AutoSmooth angle", default= 60.0, min = 0.0, max = 180.0)
    
    bevelwidth = FloatProperty(name="Bevel Width Amount", description="Set Bevel Width", default= 0.01, min = 0.002, max = .25)
    
    bevelmodiferon = BoolProperty(default = True)

    def draw(self, context):
       
        layout = self.layout

        box = layout.box()
        box.prop( self, 'tthick', text = "thicknes" )
        box.prop( self, 'bevelwidth', text = "bevel width" )
        box.prop( self, 'bevelmodiferon', text = "bevel ON/OFF")

    def execute(self, context):
        #convert angle
        bevelwidth = self.bevelwidth
        tthick = self.tthick
        ob = bpy.context.selected_objects
        angle = self.angle
        angle = angle * (3.14159265359/180)

        #bevelmodiferon = BoolProperty(default = True)
        
        
        #start off removing solidify and bevel to avoid issues later.
        bpy.ops.object.modifier_remove(modifier="Bevel")
        bpy.ops.object.modifier_remove(modifier="Solidify")
        
        #go into edit mode and select nothing then select all
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.reveal()
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
#        bpy.ops.mesh.edges_select_sharp()
        
        #convert to Loop and Mark Sharp + Beveling
        bpy.ops.mesh.region_to_loop()   
        bpy.ops.transform.edge_bevelweight(value=1)
        bpy.ops.mesh.mark_sharp()
        bpy.ops.object.editmode_toggle()

        if self.bevelmodiferon:    
            #add Bevel
            bpy.ops.object.modifier_add(type='BEVEL')
            bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
            bpy.context.object.modifiers["Bevel"].show_in_editmode = False
            bpy.context.object.modifiers["Bevel"].width = bevelwidth
            bpy.context.object.modifiers["Bevel"].segments = 3
            bpy.context.object.modifiers["Bevel"].profile = 0.734346
            bpy.context.object.modifiers["Bevel"].limit_method = 'ANGLE'
            bpy.context.object.modifiers["Bevel"].angle_limit = angle
            bpy.context.object.modifiers["Bevel"].show_in_editmode = True


        
        #add Solidify
        bpy.ops.object.modifier_add(type='SOLIDIFY')
        bpy.ops.object.modifier_move_up(modifier="Solidify")
        bpy.context.object.modifiers["Solidify"].thickness = tthick
        bpy.context.object.modifiers["Solidify"].offset = 0
        bpy.context.object.modifiers["Solidify"].use_even_offset = True
        bpy.context.object.modifiers["Solidify"].material_offset_rim = 1
        bpy.context.object.modifiers["Solidify"].material_offset = 2
        bpy.context.object.modifiers["Solidify"].show_in_editmode = False
       
        #set Smoothing
        bpy.context.object.data.use_auto_smooth = True
        bpy.context.object.data.auto_smooth_angle = angle
        bpy.ops.object.shade_smooth()

        return {'FINISHED'}

#Clean Off Bevel and Sharps In Object Mode (now with options to remove modifiers
class unsharpOperator(bpy.types.Operator):
    '''Clear Off Sharps And Bevels'''
    bl_idname = "clean.objects"
    bl_label = "UnsharpBevel"
    bl_options = {'REGISTER', 'UNDO'} 
    
    removeMods = BoolProperty(default = True)
    
    def draw(self, context):
        layout = self.layout

        box = layout.box()
        # DRAW YOUR PROPERTIES IN A BOX
        box.prop( self, 'removeMods', text = "RemoveModifiers?")
        
    def execute(self, context):
        bpy.ops.object.mode_set(mode='EDIT')
        
        #Unhide all The Geo!
        bpy.ops.mesh.reveal()        
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_all(action='TOGGLE')
        
        #AR suggested using -1s instead of Zeroes
        bpy.ops.transform.edge_bevelweight(value=-1)
        bpy.ops.mesh.mark_sharp(clear=True)
        bpy.ops.transform.edge_crease(value=-1)
        
        #Now Get Rid of Modifiers/SetSmooth
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.shade_flat()
        
        if self.removeMods:
            bpy.ops.object.modifier_remove(modifier="Bevel")
            bpy.ops.object.modifier_remove(modifier="Solidify")
            
        else:
            bpy.context.object.modifiers["Bevel"].limit_method = 'ANGLE'
            bpy.context.object.modifiers["Bevel"].angle_limit = 0.785398
            return {'FINISHED'}        
        
        return {'FINISHED'}

#Clean Off Bevel and Sharps In Edit Mode
class unsharpOperatorE(bpy.types.Operator):
    '''Clear Off Sharps And Bevels'''
    bl_idname = "clean1.objects"
    bl_label = "UnsharpBevelE"
    bl_options = {'REGISTER', 'UNDO'} 
        
    def execute(self, context):
        #bpy.ops.object.mode_set(mode='EDIT')
        #bpy.ops.mesh.select_all(action='DESELECT')
        #bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.transform.edge_bevelweight(value=-1)
        bpy.ops.mesh.mark_sharp(clear=True)
        bpy.ops.transform.edge_crease(value=-1)
        #bpy.ops.object.editmode_toggle()
        #bpy.ops.object.shade_flat()
        #bpy.ops.object.modifier_remove(modifier="Bevel")
        #bpy.ops.object.modifier_remove(modifier="Solidify")
        
        return {'FINISHED'}
    
#Bevel and Sharps In Edit Mode to Selection
class sharpandbevelOperatorE(bpy.types.Operator):
    '''Clear Off Sharps And Bevels'''
    bl_idname = "bevelandsharp1.objects"
    bl_label = "UnsharpBevelE"
        
    def execute(self, context):
        #bpy.ops.object.mode_set(mode='EDIT')
        #bpy.ops.mesh.select_all(action='DESELECT')
        #bpy.ops.mesh.select_all(action='TOGGLE')
        bpy.ops.transform.edge_bevelweight(value=1)
        bpy.ops.transform.edge_crease(value=1)
        bpy.ops.mesh.mark_sharp()
        #bpy.ops.object.editmode_toggle()
        #bpy.ops.object.shade_flat()
        #bpy.ops.object.modifier_remove(modifier="Bevel")
        #bpy.ops.object.modifier_remove(modifier="Solidify")
        
        return {'FINISHED'}
 
    

#############################
#Panelling Operators Start Here
#############################

#Panel From An Edge Ring Selection
#Scale Dependant for now.
class entrenchOperatorA(bpy.types.Operator):
    '''Entrench Those Edges!'''
    bl_idname = "entrench.selection"
    bl_label = "Entrench"
    
    def execute(self, context):
        bpy.context.space_data.pivot_point = 'MEDIAN_POINT'
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        bpy.ops.mesh.bevel(offset=0.0128461, vertex_only=False)
        bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"mirror":False}, TRANSFORM_OT_translate={"value":(0, 0, 0), "constraint_axis":(False, False, False), "constraint_orientation":'GLOBAL', "mirror":False, "proportional":'DISABLED', "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "snap":False, "snap_target":'CLOSEST', "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "texture_space":False, "remove_on_cancel":False, "release_confirm":False})
        bpy.ops.transform.shrink_fatten(value=0.04, use_even_offset=True, mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        bpy.ops.mesh.region_to_loop()
        bpy.ops.mesh.bevel(offset=0.00885385, vertex_only=False)
        bpy.ops.mesh.select_more()
        bpy.ops.mesh.region_to_loop()
        bpy.ops.transform.edge_bevelweight(value=1)
        bpy.ops.mesh.mark_sharp()
        bpy.ops.object.editmode_toggle()
        #its important to specify that its edge mode youre working from. Vert mode is a different game altogether for it. 
        return {'FINISHED'}

#Make A Panel Loop From Face Selection
#Scale Dependant for now.
class panelOperatorA(bpy.types.Operator):
    '''Create A Panel From A Face Selection'''
    bl_idname = "quick.panel"
    bl_label = "Sharpen"
    
    def execute(self, context):
        bpy.context.space_data.pivot_point = 'MEDIAN_POINT'
        bpy.ops.mesh.region_to_loop()
        bpy.ops.mesh.bevel(offset=0.00841237, segments=2, vertex_only=False)
        bpy.ops.mesh.select_less()
        bpy.ops.transform.shrink_fatten(value=0.0211908, use_even_offset=False, mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        bpy.ops.mesh.bevel(offset=0.00683826, vertex_only=False)
        return {'FINISHED'}

#############################
#Array Operators Start Here
#############################

#Array Twist
class arrayOperator(bpy.types.Operator):
    '''Array And Twist 360 Degrees'''
    bl_idname = "array.twist" #must be lowercase always
    bl_label = "ArrayTwist"
    bl_options = {'REGISTER', 'UNDO'} 
    
    arrayCount = IntProperty(name="ArrayCount", description="Amount Of Clones", default=8, min = 1, max = 100)
    
    destructive = BoolProperty(default = False)
    
    #xy = BoolProperty(default = False)

        # ADD A DRAW FUNCTION TO DISPLAY PROPERTIES ON THE F6 MENU
    def draw(self, context):
        layout = self.layout

        box = layout.box()
        # DRAW YOUR PROPERTIES IN A BOX
        box.prop( self, 'arrayCount', text = "ArrayCount" )
        box.prop( self, 'destructive', text = "Destructive/Non")
        #box.prop( self, 'xy', text = "Toggle X/Y")
      
        
    def execute(self, context):
        #Now Has A Custom Count
        arrayCount=self.arrayCount #sets array count
                
        if self.destructive:
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
            bpy.ops.object.modifier_add(type='ARRAY')
            bpy.context.object.modifiers["Array"].count = arrayCount
            bpy.ops.object.modifier_add(type='SIMPLE_DEFORM')
            bpy.context.object.modifiers["SimpleDeform"].deform_method = 'BEND'
            bpy.context.object.modifiers["SimpleDeform"].angle = 6.28319
            bpy.ops.object.convert(target='MESH')
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_all(action='TOGGLE')
            bpy.ops.mesh.remove_doubles()
            bpy.ops.object.editmode_toggle()
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
            bpy.ops.object.location_clear()
            """
            if self.xy:
                bpy.context.object.modifiers["Array"].relative_offset_displace[0] = 0
                bpy.context.object.modifiers["Array"].relative_offset_displace[1] = 1
            else:
                bpy.context.object.modifiers["Array"].relative_offset_displace[0] = 1
                bpy.context.object.modifiers["Array"].relative_offset_displace[1] = 0
                """
            
        else:
            #Now Has A Custom Count
            arrayCount=self.arrayCount #sets array count
            
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
            bpy.ops.object.modifier_add(type='ARRAY')
            bpy.context.object.modifiers["Array"].count = arrayCount
            bpy.ops.object.modifier_add(type='SIMPLE_DEFORM')
            bpy.context.object.modifiers["SimpleDeform"].deform_method = 'BEND'
            bpy.context.object.modifiers["SimpleDeform"].angle = 6.28319     
            
            """if self.xy:
                bpy.context.object.modifiers["Array"].relative_offset_displace[0] = 0
                bpy.context.object.modifiers["Array"].relative_offset_displace[1] = 1
            else:
                bpy.context.object.modifiers["Array"].relative_offset_displace[0] = 1
                bpy.context.object.modifiers["Array"].relative_offset_displace[1] = 0
                """   
        return {'FINISHED'}


###########################
#Circle Stuff Starts Here
###########################

#Creates a Circle With No Extrudes / Allows For Setup
class circleSetupOperator(bpy.types.Operator):
    "Creates a Clean Circle At The Vert"
    bl_idname = "circle.setup"
    bl_label = "SetCircle"
    bl_options = {'REGISTER', 'UNDO'} 
    
    circleSubdivs = IntProperty(name="Circle", description="Amount Of Divisions Per Circle", default=5, min = 2, max = 8)
    
    
    def execute(self, context):     
        #Now Has A Custom Count
        circleSubdivs=self.circleSubdivs #sets the subdivs on the circle.
           
        bpy.ops.mesh.bevel(offset=0.1, segments=circleSubdivs, vertex_only=True)
        bpy.ops.mesh.looptools_circle(custom_radius=False, fit='best', flatten=True, influence=100, lock_x=False, lock_y=False, lock_z=False, radius=1, regular=True)
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        
        
        bpy.ops.mesh.dissolve_mode()
        #sets Individual Scaling Of Newly Created Points.
        bpy.context.space_data.pivot_point = 'INDIVIDUAL_ORIGINS'
        return {'FINISHED'}


#Make A Circle At Each Vert - No Mercy
class circleOperator(bpy.types.Operator):
    '''Creates A Circle At Vert'''
    bl_idname = "area.circle"
    bl_label = "Encircle"
    
    def execute(self, context):
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        bpy.ops.mesh.bevel(offset=0.1, segments=4, vertex_only=True)
        bpy.ops.mesh.looptools_circle(custom_radius=False, fit='best', flatten=True, influence=100, lock_x=False, lock_y=False, lock_z=False, radius=1, regular=True)
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        bpy.ops.mesh.inset(thickness=0.0109504)
        bpy.ops.mesh.inset(thickness=0.0150383)
        bpy.ops.transform.shrink_fatten(value=0.0977827, use_even_offset=False, mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        bpy.ops.mesh.inset(thickness=0.0125973)
        bpy.ops.mesh.dissolve_mode()
        bpy.ops.mesh.dissolve_faces()
        return {'FINISHED'}

#Nth Circle Rings
class cicleRinger(bpy.types.Operator):
    '''Turns Every Nth Selection Into a Circle'''
    bl_idname = "nth.circle"
    bl_label = "Nthcircle"
    
    def execute(self, context):
        #massive hole punching
        #bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        #bpy.ops.mesh.inset(thickness=0.05)
        bpy.context.space_data.pivot_point = 'INDIVIDUAL_ORIGINS'    
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        bpy.ops.mesh.select_nth()
        bpy.ops.mesh.bevel(offset=0.03, segments=4, vertex_only=True)
        bpy.ops.mesh.looptools_circle(custom_radius=False, fit='best', flatten=True, influence=100, lock_x=False, lock_y=False, lock_z=False, radius=1, regular=True)
        #bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        #bpy.ops.mesh.inset(thickness=0.0109504)
        #bpy.ops.mesh.inset(thickness=0.0150383)
        #bpy.ops.transform.shrink_fatten(value=0.0977827, use_even_offset=False, mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        #bpy.ops.mesh.inset(thickness=0.0125973)
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        bpy.ops.mesh.dissolve_mode()
        return {'FINISHED'}

#Individual Circle Rings AKA Circle Selection
class cicleRings(bpy.types.Operator):
    '''Turns Every Vert Into a Circle'''
    bl_idname = "select.circle"
    bl_label = "Selectioncircle"
    
    def execute(self, context):
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        #these 2 lines might be a bad idea
        bpy.ops.mesh.inset(thickness=0.0705154)
        #bpy.ops.mesh.bevel(offset=0.065, segments=2, vertex_only=False) #the segments should offset because of the segments lower down
        #bpy.ops.mesh.select_less()
        #but lets find out!
        bpy.ops.mesh.bevel(offset=0.04, segments=4, vertex_only=True) #segments should be adjustable in an ideal world
        bpy.ops.mesh.looptools_circle(custom_radius=False, fit='best', flatten=True, influence=100, lock_x=False, lock_y=False, lock_z=False, radius=1, regular=True)
        bpy.context.space_data.pivot_point = 'INDIVIDUAL_ORIGINS'
        bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"mirror":False}, TRANSFORM_OT_translate={"value":(0, 0, 0), "constraint_axis":(False, False, False), "constraint_orientation":'GLOBAL', "mirror":False, "proportional":'DISABLED', "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "snap":False, "snap_target":'CLOSEST', "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "texture_space":False, "remove_on_cancel":False, "release_confirm":False})
        bpy.ops.transform.resize(value=(0.730115, 0.730115, 0.730115), constraint_axis=(False, False, False), constraint_orientation='GLOBAL', mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        bpy.ops.transform.shrink_fatten(value=0.0841381, use_even_offset=False, mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"mirror":False}, TRANSFORM_OT_translate={"value":(0, 0, -0.0705891), "constraint_axis":(False, False, True), "constraint_orientation":'GLOBAL', "mirror":False, "proportional":'DISABLED', "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "snap":False, "snap_target":'CLOSEST', "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "texture_space":False, "remove_on_cancel":False, "release_confirm":False})
        bpy.ops.mesh.select_more()
        bpy.ops.mesh.dissolve_faces()
        #ew N-gon I need a way to make this individally solve for the grid fill operation while also keeping them going the same directions and not be rampart
        return {'FINISHED'}

#Single Circle Rings AKA Circle Ring
class cicleRing(bpy.types.Operator):
    '''Turns Every Vert Into a Circle'''
    bl_idname = "circle.ring"
    bl_label = "CircleRing"
    
    def execute(self, context):
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        bpy.ops.mesh.bevel(offset=0.1, segments=4, vertex_only=True)
        bpy.ops.mesh.looptools_circle(custom_radius=False, fit='best', flatten=True, influence=100, lock_x=False, lock_y=False, lock_z=False, radius=1, regular=True)
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        bpy.ops.mesh.inset(thickness=0.0109504)
        bpy.ops.mesh.inset(thickness=0.0150383)
        bpy.ops.transform.shrink_fatten(value=0.0977827, use_even_offset=False, mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
        bpy.ops.mesh.inset(thickness=0.0125973)
        bpy.ops.mesh.dissolve_mode()
        #ew N-gon I need a way to make this individally solve for the grid fill operation while also keeping them going the same directions and not be rampart
        return {'FINISHED'}
