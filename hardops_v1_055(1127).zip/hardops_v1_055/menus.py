# -*- coding: utf-8 -*-

import bpy 
from bpy.types import Menu
from . icons.icons import load_icons

class HardOpsCustomMenu(bpy.types.Menu):
    bl_label = "HardOps v0055"
    bl_idname = "HardHops_CustomMenu"
    
    def draw(self, context):

        layout = self.layout
        icons = load_icons()
        
        if bpy.context.object.mode == "EDIT":
            #print("EDIT MODE!")
            
            
            MakeSharpE = icons.get("MakeSharpE")
            layout.operator("bevelandsharp1.objects", text = "Make SSharp", icon_value=MakeSharpE.icon_id)
            
            ClearSharps = icons.get("ClearSharps")
            layout.operator("clean1.objects", text = "Clean SSharps", icon_value=ClearSharps.icon_id)
            
            layout.separator()
            
            AdjustBevel = icons.get("AdjustBevel")
            layout.operator("bwidth.modal_operator", text = "(B)Width", icon_value=AdjustBevel.icon_id)
            
            layout.separator() 
            
            Diagonal = icons.get("Diagonal")
            layout.menu(eMeshtools.bl_idname, icon_value=Diagonal.icon_id)
            
            layout.separator()
            
            Xslap = icons.get("Xslap")
            layout.operator("ehalfslap.object", text = "(X+) Symmetrize", icon_value=Xslap.icon_id)
            
            layout.separator()
            
            if context.object.data.show_edge_crease == False:
                layout.operator("object.showoverlays", text="Show Overlays", icon='RESTRICT_VIEW_ON')  
            else :
                layout.operator("object.hide_overlays", text="Hide Overlays", icon='RESTRICT_VIEW_OFF')
            
            layout.prop(context.window_manager, "choose_primitive", text="", expand=False)    
                               
        else:
            #print("OBJECT/OTHER MODE!")
            
            CSharpen = icons.get("CSharpen")
            layout.menu(SharpSub.bl_idname, icon_value=CSharpen.icon_id)
            
            AdjustBevel = icons.get("AdjustBevel")
            layout.operator("bwidth.modal_operator", text = "(B)Width", icon_value=AdjustBevel.icon_id)
            
            #experimental tthick. Ugh.
            #mutil C?
            CSharpen = icons.get("CSharpen")
            layout.operator("multi.csharp", text = "(C)Multi", icon_value=CSharpen.icon_id)
            
            ReBool = icons.get("ReBool")
            layout.operator("reverse.boolean", text = "(Re)Bool", icon_value = ReBool.icon_id)  
            
            layout.separator()
                        
            Diagonal = icons.get("Diagonal")
            layout.menu(Meshtools.bl_idname, icon_value=Diagonal.icon_id)
            
            layout.separator()
            
            Gui = icons.get("Gui")
            layout.menu("vpmenu.submenu", text="Set", icon_value=Gui.icon_id)
            
            layout.separator()
            #layout.menu("INFO_MT_mesh_deesinserts_add", icon_value=Diagonal.icon_id)
            Diagonal = icons.get("Diagonal")
            layout.menu("INFO_MT_mesh_D3I_add", icon_value=Diagonal.icon_id)
            Diagonal = icons.get("Diagonal")
            layout.prop(context.window_manager, "choose_primitive", text="", expand=False, icon_value=Diagonal.icon_id) 
            layout.separator()
            layout.operator("make.link", text = "Make Link", icon='CONSTRAINT' )



#############################
#SubMenus
#############################

class SharpSub(bpy.types.Menu):
    bl_label = 'C/S/T Sharp'
    bl_idname = 'sharpmenu.submenu1'

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        Ssharpen = icons.get("Ssharpen")
        layout.operator("ssharpen.objects", text = "(S) Sharpen", icon_value=Ssharpen.icon_id)

        CSharpen = icons.get("CSharpen")
        layout.operator("csharpen.objects", text = "(C) Sharpen", icon_value=CSharpen.icon_id)

        """
        Ssharpen = icons.get("Ssharpen")
        layout.operator("ssharpen.objects", text = "(S) Sharpen", icon_value=Ssharpen.icon_id)
        
        #C sharpen normal
        is_bevel = False
        is_bool = False
        for mode in bpy.context.object.modifiers :
            if mode.type == 'BEVEL' :
                is_bevel = True
            if mode.type == 'BOOLEAN' :
                is_bool = True   
        
        #If I Have          
        if is_bevel == True and is_bool == False :
            CSharpen = icons.get("CSharpen")
            layout.operator("ssharpen.objects", text = "Update (C) Sharpen", icon_value=CSharpen.icon_id)
            
        elif is_bool and is_bevel == True :
            CSharpen = icons.get("CSharpen")
            layout.operator("csharpen.objects", text = "Update (C) Sharpen", icon_value=CSharpen.icon_id)   
        
        #If I don't have    
        else :
            CSharpen = icons.get("CSharpen")                
            layout.operator("csharpen.objects", text = "(C) Sharpen", icon_value=CSharpen.icon_id)
        
        #C sharpen smooth
        is_bevel = False
        is_bool = False
        for mode in bpy.context.object.modifiers :
            if mode.type == 'BEVEL' :
                is_bevel = True
            if mode.type == 'BOOLEAN' :
                is_bool = True   
        
        #If I Have          
        if is_bevel == True and is_bool == False :
            CSharpen = icons.get("CSharpen")
            layout.operator("ssharpen.objects", text = "Update (C) Sharpen Smooth", icon_value=CSharpen.icon_id)
            
        elif is_bool and is_bevel == True :
            CSharpen = icons.get("CSharpen")
            layout.operator("object.smoothsharp", text = "Update (C) Sharpen Smooth", icon_value=CSharpen.icon_id)   
        
        #If I don't have    
        else :
            CSharpen = icons.get("CSharpen")                
            layout.operator("object.smoothsharp", text = "(C) Sharpen Smooth", icon_value=CSharpen.icon_id)
        """
        
        Frame = icons.get("Frame")
        layout.operator("cstep.objects", text = "(C) Step", icon_value=Frame.icon_id)
        
        Tsharpen = icons.get("Tsharpen")
        layout.operator("solidify.objects", text = "(T) Sharpen", icon_value=Tsharpen.icon_id)
        
        ClearSharps = icons.get("ClearSharps")
        layout.operator("clean.objects", text = "Clear S/C/Sharps", icon_value=ClearSharps.icon_id)

class ButtonsVPSub(bpy.types.Menu):
    bl_label = 'GUI'
    bl_idname = 'vpmenu.submenu'

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        icons = load_icons()
        
        if context.object.draw_type == 'WIRE':
            layout.operator("object.solid_all", text="Solid Mode", icon='MESH_CUBE')
        else :
            layout.operator("showwire.objects", text = "Wire Mode", icon='OUTLINER_OB_LATTICE')
            
        layout.separator()
        
        NGui = icons.get("NGui")
        layout.operator("ui.reg", text = "Normal", icon_value=NGui.icon_id)
        
        RGui = icons.get("RGui")
        layout.operator("ui.red", text = "Matcap", icon_value=RGui.icon_id)
        
        QGui = icons.get("QGui")
        layout.operator("ui.clean", text = "Minimal", icon_value=QGui.icon_id)
        
        layout.separator()
        
        RenderSet1 = icons.get("RenderSet1")
        layout.operator("render.setup", text = "Render (1)", icon_value=RenderSet1.icon_id)
        
        SetFrame = icons.get("SetFrame")
        layout.operator("setframe.end", text =  "Frame Range", icon_value=SetFrame.icon_id)
        
        layout.separator()
        
        m_check = context.window_manager.m_check
        
        if bpy.context.object and bpy.context.object.type == 'MESH':

            
            if m_check.meshcheck_enabled:
                layout.operator("object.remove_materials", text="Hidde Ngons/Tris", icon='RESTRICT_VIEW_OFF')
            else:
                layout.operator("object.add_materials", text="Display Ngons/Tris", icon='COLOR') 
            
            layout.operator("data.facetype_select", text="Ngons Select").face_type = "5"
            layout.operator("data.facetype_select", text="Tris Select").face_type = "3"        

class ButtonsVPSub(bpy.types.Menu):
    bl_label = 'GUI'
    bl_idname = 'vpmenu.submenu1'

    def draw(self, context):
        layout = self.layout
        icons = load_icons()

        NGui = icons.get("NGui")
        layout.operator("ui.reg", text = "Normal", icon_value=NGui.icon_id)
        
        RGui = icons.get("RGui")
        layout.operator("ui.red", text = "Matcap", icon_value=RGui.icon_id)
        
        QGui = icons.get("QGui")
        layout.operator("ui.clean", text = "Minimal", icon_value=QGui.icon_id)
        
class ImpSettings(bpy.types.Menu):
    bl_label = 'Set'
    bl_idname = 'renplay.Submenu'

    def draw(self, context):
        layout = self.layout
        icons = load_icons()

        layout.separator()
        
        row = layout.split(align=True)
        if context.object.draw_type == 'WIRE':
            row.operator("object.solid_all", text="Solid Mode", icon='MESH_CUBE')
        else :
            row.operator("showwire.objects", text = "Wire Mode", icon='OUTLINER_OB_LATTICE')
            
        layout.separator()
        
        RenderSet1 = icons.get("RenderSet1")
        layout.operator("render.setup", text = "Render (1)", icon_value=RenderSet1.icon_id)
        
        SetFrame = icons.get("SetFrame")
        layout.operator("setframe.end", text =  "Frame Range", icon_value=SetFrame.icon_id)
        
class Meshtools(bpy.types.Menu):
    bl_label = 'Mesh Tools'
    bl_idname = 'view3d.mstool_submenu'

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        ATwist360 = icons.get("ATwist360")
        layout.operator("array.twist", text = "Twist 360", icon_value=ATwist360.icon_id)
        
        layout.separator()
        
        Xslap = icons.get("Xslap")
        layout.operator("halfslap.object", text = "(X) - Symmetrize", icon_value=Xslap.icon_id)
        
        Yslap = icons.get("Yslap")
        layout.operator("yhalfslap.object", text = "(Y) - Symmetrize", icon_value=Yslap.icon_id)
        
        Zslap = icons.get("Zslap")
        layout.operator("zhalfslap.object", text = "(Z) - Symmetrize", icon_value=Zslap.icon_id)
        
        layout.separator()
        
        PUnwrap = icons.get("PUnwrap")
        layout.operator("object.runwrap", text = "(P) Unwrap", icon_value=PUnwrap.icon_id)
        
        layout.separator()
        
        SCleanRecenter = icons.get("SCleanRecenter")
        layout.operator("clean.recenter", text = "(S) Clean Recenter", icon_value=SCleanRecenter.icon_id)
        
        Applyall = icons.get("Applyall")
        layout.operator("stomp2.object", text = "ApplyAll (-L)", icon_value=Applyall.icon_id)
        
        
class eMeshtools(bpy.types.Menu):
    bl_label = 'Mesh Tools'
    bl_idname = 'view3d.emstool_submenu'

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        CircleSetup = icons.get("CircleSetup")
        layout.operator("circle.setup", text = "Circle", icon_value=CircleSetup.icon_id)
        
        NthCircle = icons.get("NthCircle")
        layout.operator("nth.circle", text = "Circle (Nth)", icon_value=NthCircle.icon_id)
        
        FaceGrate = icons.get("FaceGrate")
        layout.operator("fgrate.op", text = "Grate (Face)", icon_value=FaceGrate.icon_id)
        
        FaceKnurl = icons.get("FaceKnurl")
        layout.operator("fknurl.op", text = "Knurl (Face)", icon_value=FaceKnurl.icon_id)
        
        EdgeRingPanel = icons.get("EdgeRingPanel")
        layout.operator("quick.panel", text = "Grate (Face)", icon_value=EdgeRingPanel.icon_id)
        
        FacePanel = icons.get("FacePanel")
        layout.operator("entrench.selection", text = "Panel (Edge)/(Face)", icon_value=FacePanel.icon_id)
        
        PUnwrap = icons.get("PUnwrap")
        layout.operator("object.runwrap", text = "(P) Unwrap", icon_value=PUnwrap.icon_id)

class INFO_MT_mesh_deesinserts_add(bpy.types.Menu):
    bl_idname = "INFO_MT_mesh_D3I_add"
    bl_label = "DeesInserts"

    def draw(self, context):
        layout = self.layout
        layout.operator("mesh.wing", text="Wing")
        layout.operator("mesh.tee", text="Tee")
        layout.operator("mesh.insertjam", text="InsertJam")
        layout.operator("mesh.hex_nut", text="Hex_Nut")
        layout.operator("mesh.flange_cap", text="Flange_Cap")
        layout.operator("mesh.flange", text="Flange")
        layout.operator("mesh.cap", text="Cap")
        layout.operator("mesh.torx", text="Torx")
        layout.operator("mesh.square", text="Square")
        layout.operator("mesh.span_head", text="Span_Head")
        layout.operator("mesh.phps_rnd_2", text="Phps_Rnd_2")
        layout.operator("mesh.phps_rnd", text="Phps_Rnd")
        layout.operator("mesh.phps_hex", text="Phps_Hex")
        layout.operator("mesh.phps_flat", text="Phps_Flat")
        layout.operator("mesh.phps_cntrsnk", text="Phps_CntrSnk")
        layout.operator("mesh.knurl_head", text="Knurl_Head")
        layout.operator("mesh.hex_socket", text="Hex_Socket")
        layout.operator("mesh.hex_raised", text="Hex_Raised")
        layout.operator("mesh.hex_flat", text="Hex_Flat")
        layout.operator("mesh.hex", text="Hex")
        layout.operator("mesh.flat_rnd", text="FLAT_RND")
        layout.operator("mesh.button", text="Button")